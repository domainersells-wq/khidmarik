
'use client';

import { AdminDashboardSidebar } from '@/components/admin/AdminDashboardSidebar';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { PanelLeft } from 'lucide-react';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation'; // For conceptual auth check

export default function AdminDashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const router = useRouter();

  useEffect(() => {
    // --- Conceptual Auth Check ---
    // In a real app, this would involve checking a token, session, or custom claim.
    // If not authenticated, redirect to /admin/login.
    // For this prototype, we assume if they reach here, they are "logged in" conceptually.
    // Example:
    // const isAdminAuthenticated = checkAdminAuthStatus(); // Your actual auth check function
    // if (!isAdminAuthenticated) {
    //   router.replace('/admin/login');
    // }
  }, [router]);

  return (
    <div className="flex min-h-screen bg-muted/40">
      <div className="hidden md:block">
        <AdminDashboardSidebar />
      </div>
      <div className="flex flex-col flex-1 md:ml-64">
        <header className="sticky top-0 z-30 flex h-14 items-center gap-4 border-b bg-background px-4 sm:static sm:h-auto sm:border-0 sm:bg-transparent sm:px-6 md:hidden">
          <Sheet open={isSidebarOpen} onOpenChange={setIsSidebarOpen}>
            <SheetTrigger asChild>
              <Button size="icon" variant="outline" className="sm:hidden">
                <PanelLeft className="h-5 w-5" />
                <span className="sr-only">Toggle Menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="sm:max-w-xs p-0">
              <AdminDashboardSidebar onLinkClick={() => setIsSidebarOpen(false)} />
            </SheetContent>
          </Sheet>
        </header>
        <main className="flex-1 p-4 sm:px-6 sm:py-0 md:gap-8">{children}</main>
      </div>
    </div>
  );
}
