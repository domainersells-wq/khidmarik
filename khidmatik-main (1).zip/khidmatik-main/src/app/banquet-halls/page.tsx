"use client";
import { useState, useEffect } from "react";
import { HallCard } from "@/components/banquet-halls/HallCard";
import { CircularProgress, Grid, Typography } from "@mui/material";

// Mock data for initial display
const mockHalls = [
  {
    id: "1",
    hallName: "The Grand Hall",
    location: "Sidi Bel Abbès",
    capacity: 200,
    price: 500,
    imageUrl: "/placeholder-image.jpg",
  },
  {
    id: "2",
    hallName: "The Crystal Ballroom",
    location: "Sidi Bel Abbès",
    capacity: 300,
    price: 750,
    imageUrl: "/placeholder-image.jpg",
  },
  {
    id: "3",
    hallName: "The Emerald Room",
    location: "Sidi Bel Abbès",
    capacity: 150,
    price: 400,
    imageUrl: "/placeholder-image.jpg",
  },
];

export default function BanquetHallsPage() {
  const [halls, setHalls] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate fetching data
    setTimeout(() => {
      setHalls(mockHalls);
      setIsLoading(false);
    }, 1500);
  }, []);

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <CircularProgress />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-4">
      <Typography variant="h4" gutterBottom>
        Available Banquet Halls
      </Typography>
      <Grid container spacing={4}>
        {halls.map((hall) => (
          <Grid item key={hall.id} xs={12} sm={6} md={4}>
            <HallCard hall={hall} />
          </Grid>
        ))}
      </Grid>
    </div>
  );
}