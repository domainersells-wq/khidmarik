
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Trash2, ShoppingCart, CreditCard, RefreshCw } from 'lucide-react';
import type { CartItem } from '@/types';
import { useToast } from '@/hooks/use-toast';

const CART_STORAGE_KEY = 'khidmatikCart';

export default function CartPage() {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    document.title = 'Shopping Cart | Khidmatik';
    loadCartFromStorage();
  }, []);

  const loadCartFromStorage = () => {
    try {
      const storedCart = localStorage.getItem(CART_STORAGE_KEY);
      if (storedCart) {
        setCartItems(JSON.parse(storedCart));
      } else {
        setCartItems([]);
      }
    } catch (error) {
      console.error("Error loading cart from storage:", error);
      setCartItems([]); // Fallback to empty cart on error
    }
  };

  const saveCartToStorage = (items: CartItem[]) => {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(items));
    } catch (error) {
      console.error("Error saving cart to storage:", error);
      toast({ title: "Storage Error", description: "Could not save cart changes.", variant: "destructive"});
    }
  };

  const handleQuantityChange = (itemId: string, newQuantity: number) => {
    if (newQuantity < 1) newQuantity = 1; // Minimum quantity is 1
    const updatedItems = cartItems.map(item =>
      item.id === itemId ? { ...item, quantity: newQuantity } : item
    );
    setCartItems(updatedItems);
    saveCartToStorage(updatedItems);
  };

  const handleRemoveItem = (itemId: string) => {
    const updatedItems = cartItems.filter(item => item.id !== itemId);
    setCartItems(updatedItems);
    saveCartToStorage(updatedItems);
    toast({
      title: "Item Removed",
      description: "The item has been removed from your cart.",
    });
  };

  const handleClearCart = () => {
    setCartItems([]);
    saveCartToStorage([]);
    toast({
      title: "Cart Cleared",
      description: "All items have been removed from your cart.",
    });
  };

  const subtotal = cartItems.reduce((acc, item) => acc + item.unitPrice * item.quantity, 0);
  const estimatedShipping = cartItems.length > 0 ? 500 : 0; // Mock shipping
  const total = subtotal + estimatedShipping;

  return (
    <div className="max-w-4xl mx-auto py-8 space-y-8">
      <header className="flex items-center justify-between">
        <h1 className="text-3xl font-bold font-headline flex items-center">
          <ShoppingCart className="mr-3 h-8 w-8 text-primary" /> Your Shopping Cart
        </h1>
        {cartItems.length > 0 && (
          <Button variant="outline" asChild>
            <Link href="/listings">Continue Shopping</Link>
          </Button>
        )}
      </header>

      {cartItems.length === 0 ? (
        <Card className="text-center py-12">
          <CardHeader>
            <CardTitle className="text-2xl">Your Cart is Empty</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-6">Looks like you haven't added anything to your cart yet.</p>
            <Button asChild className="bg-primary hover:bg-primary/90 text-primary-foreground">
              <Link href="/listings">Start Shopping</Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2 space-y-4">
            {cartItems.map(item => (
              <Card key={item.id} className="flex flex-col sm:flex-row items-start gap-4 p-4 shadow-sm">
                <div className="w-full sm:w-24 h-24 aspect-square bg-muted rounded-md overflow-hidden shrink-0">
                  <Image
                    src={item.lineItemImage || 'https://placehold.co/100x100.png'}
                    alt={item.productName}
                    width={100}
                    height={100}
                    className="object-cover w-full h-full"
                  />
                </div>
                <div className="flex-grow">
                  <h3 className="font-semibold text-lg">{item.productName}</h3>
                  {item.variantDescription && <p className="text-sm text-muted-foreground">{item.variantDescription}</p>}
                  <p className="text-sm text-primary">{item.unitPrice.toFixed(2)} DA</p>
                </div>
                <div className="flex flex-col items-end gap-2 mt-2 sm:mt-0">
                  <div className="flex items-center gap-2">
                    <Label htmlFor={`quantity-${item.id}`} className="sr-only">Quantity</Label>
                    <Input
                      id={`quantity-${item.id}`}
                      type="number"
                      min="1"
                      value={item.quantity}
                      onChange={(e) => handleQuantityChange(item.id, parseInt(e.target.value))}
                      className="w-20 h-9 text-center"
                    />
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => handleRemoveItem(item.id)} className="text-destructive hover:text-destructive/80">
                    <Trash2 className="mr-1 h-4 w-4" /> Remove
                  </Button>
                </div>
                <div className="w-full sm:w-auto text-right font-semibold text-lg pt-2 sm:pt-0">
                  {(item.unitPrice * item.quantity).toFixed(2)} DA
                </div>
              </Card>
            ))}
            <Button variant="outline" onClick={handleClearCart} className="w-full mt-4">
              <Trash2 className="mr-2 h-4 w-4" /> Clear Cart
            </Button>
          </div>

          <aside className="md:col-span-1">
            <Card className="sticky top-24 shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl">Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>{subtotal.toFixed(2)} DA</span>
                </div>
                <div className="flex justify-between">
                  <span>Estimated Shipping</span>
                  <span>{estimatedShipping.toFixed(2)} DA</span>
                </div>
                <Separator />
                <div className="flex justify-between font-bold text-lg">
                  <span>Total</span>
                  <span>{total.toFixed(2)} DA</span>
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground" asChild size="lg">
                  <Link href="/checkout">
                    <CreditCard className="mr-2 h-5 w-5" /> Proceed to Checkout
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          </aside>
        </div>
      )}
    </div>
  );
}
