
'use client';

import { useState, useEffect, type FormEvent } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Textarea } from '@/components/ui/textarea';
import { MapPin, Phone, User, Home, Package, CreditCard, AlertCircle, Truck, ArrowLeft } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { algerianWilayas } from '@/data/algerian-wilayas';
import type { CartItem, ShippingAddress } from '@/types';
import { logEvent } from '@/lib/firebase';

const CART_STORAGE_KEY = 'khidmatikCart';

// Updated to derive summary from cartItems state
interface OrderSummary {
  subtotal: number;
  shipping: number;
  total: number;
  items: Array<{ name: string; quantity: number; price: number }>;
}

export default function CheckoutPage() {
  const { toast } = useToast();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [orderSummary, setOrderSummary] = useState<OrderSummary>({
    subtotal: 0,
    shipping: 0,
    total: 0,
    items: [],
  });

  const [shippingAddress, setShippingAddress] = useState<Partial<ShippingAddress>>({
    fullName: '',
    phone: '',
    addressLine1: '',
    city: 'Sidi Bel Abbès',
    wilayaCode: '22',
  });
  const [shippingMethod, setShippingMethod] = useState<string>('standard');
  const [paymentMethod, setPaymentMethod] = useState<string>('escrow_wallet');

  useEffect(() => {
    document.title = 'Checkout | Khidmatik';
    loadCartAndCalculateSummary();
  }, []);

  useEffect(() => {
    // Recalculate summary when cart items or shipping method changes
    calculateOrderSummary(cartItems, shippingMethod);
  }, [cartItems, shippingMethod]);

  const loadCartAndCalculateSummary = () => {
    try {
      const storedCart = localStorage.getItem(CART_STORAGE_KEY);
      const loadedCartItems = storedCart ? JSON.parse(storedCart) : [];
      setCartItems(loadedCartItems);
      // Initial calculation happens in the useEffect above once cartItems are set
    } catch (error) {
      console.error("Error loading cart from storage:", error);
      setCartItems([]);
    }
  };

  const calculateOrderSummary = (currentCartItems: CartItem[], currentShippingMethod: string) => {
    const subtotal = currentCartItems.reduce((acc, item) => acc + item.unitPrice * item.quantity, 0);
    let shippingCost = currentCartItems.length > 0 ? 500 : 0; // Default shipping

    if (currentShippingMethod === 'app_partner') {
      shippingCost = currentCartItems.length > 0 ? 1200 : 0;
    } else if (currentShippingMethod === 'pickup') {
      shippingCost = 0;
    }
    // 'standard' uses the default 500 DA if items exist

    const total = subtotal + shippingCost;
    const summaryItems = currentCartItems.map(item => ({
      name: `${item.productName}${item.variantDescription ? ` (${item.variantDescription})` : ''}`,
      quantity: item.quantity,
      price: item.unitPrice,
    }));
    setOrderSummary({ subtotal, shipping: shippingCost, total, items: summaryItems });
  };


  const handleAddressChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setShippingAddress(prev => ({ ...prev, [e.target.id]: e.target.value }));
  };

  const handleWilayaChange = (value: string) => {
    setShippingAddress(prev => ({ ...prev, wilayaCode: value }));
  };
  
  const handleSubmitOrder = async (e: FormEvent) => {
    e.preventDefault();
    if (!shippingAddress.fullName || !shippingAddress.phone || !shippingAddress.addressLine1 || !shippingAddress.wilayaCode) {
        toast({ title: "Missing Address Info", description: "Please fill all required shipping address fields.", variant: "destructive" });
        return;
    }
    if(cartItems.length === 0){
        toast({ title: "Empty Cart", description: "Your cart is empty. Please add items before checking out.", variant: "destructive" });
        return;
    }
    
    // Conceptual order processing
    console.log("Order Submitted:", { shippingAddress, shippingMethod, paymentMethod, order: orderSummary });
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 300));
    
    // Log purchase event to Firebase Analytics (conceptual)
    logEvent('purchase', {
        value: orderSummary.total,
        currency: 'DZD',
        items: orderSummary.items.map(item => ({
            item_name: item.name,
            price: item.price,
            quantity: item.quantity,
        })),
    });

    toast({
      title: "Order Placed Successfully! (Conceptual)",
      description: "Your order has been received and an invoice has been automatically generated. Payment will be processed via Khidmatik Escrow Wallet. Your cart has been cleared.",
      duration: 7000,
    });

    // Clear cart from localStorage and state
    try {
        localStorage.removeItem(CART_STORAGE_KEY);
        setCartItems([]); // This will also trigger recalculation of order summary to zero
    } catch (error) {
        console.error("Error clearing cart:", error);
    }
    // Potentially redirect to an order confirmation page or back to homepage
  };

  return (
    <div className="max-w-4xl mx-auto py-8">
      <Link href="/cart" className="inline-flex items-center text-sm text-muted-foreground hover:text-primary mb-6">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Cart
      </Link>
      <h1 className="text-3xl font-bold font-headline mb-8 text-center">Checkout</h1>

      <form onSubmit={handleSubmitOrder} className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-6">
          {/* Shipping Address */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xl flex items-center"><MapPin className="mr-2 h-5 w-5 text-primary" /> Shipping Address</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="fullName">Full Name *</Label>
                <Input id="fullName" value={shippingAddress.fullName} onChange={handleAddressChange} placeholder="Enter your full name" required />
              </div>
              <div>
                <Label htmlFor="phone">Phone Number *</Label>
                <Input id="phone" type="tel" value={shippingAddress.phone} onChange={handleAddressChange} placeholder="e.g., 05xxxxxxxx" required />
              </div>
              <div>
                <Label htmlFor="addressLine1">Address Line 1 *</Label>
                <Input id="addressLine1" value={shippingAddress.addressLine1} onChange={handleAddressChange} placeholder="Street address, P.O. box, company name, c/o" required />
              </div>
              <div>
                <Label htmlFor="addressLine2">Address Line 2 (Optional)</Label>
                <Input id="addressLine2" value={shippingAddress.addressLine2 || ''} onChange={handleAddressChange} placeholder="Apartment, suite, unit, building, floor, etc." />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="city">City *</Label>
                  <Input id="city" value={shippingAddress.city} onChange={handleAddressChange} placeholder="e.g., Sidi Bel Abbès" required />
                </div>
                <div>
                  <Label htmlFor="wilayaCode">Wilaya (Province) *</Label>
                  <Select value={shippingAddress.wilayaCode} onValueChange={handleWilayaChange} required>
                    <SelectTrigger id="wilayaCode">
                      <SelectValue placeholder="Select your Wilaya" />
                    </SelectTrigger>
                    <SelectContent>
                      {algerianWilayas.map(wilaya => (
                        <SelectItem key={wilaya.code} value={wilaya.code}>
                          {wilaya.code} - {wilaya.name_fr} ({wilaya.name})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
               <div>
                <Label htmlFor="postalCode">Postal Code (Optional)</Label>
                <Input id="postalCode" value={shippingAddress.postalCode || ''} onChange={handleAddressChange} placeholder="e.g., 22000" />
              </div>
            </CardContent>
          </Card>

          {/* Shipping Method */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xl flex items-center"><Truck className="mr-2 h-5 w-5 text-primary" /> Shipping Method</CardTitle>
            </CardHeader>
            <CardContent>
              <RadioGroup value={shippingMethod} onValueChange={(value) => setShippingMethod(value)} className="space-y-2">
                <Label htmlFor="shipping-standard" className="flex items-center p-3 border rounded-md cursor-pointer hover:bg-muted/50 has-[:checked]:ring-2 has-[:checked]:ring-primary has-[:checked]:border-primary">
                  <RadioGroupItem value="standard" id="shipping-standard" className="mr-3" />
                  <div>
                    <span className="font-medium">Seller Standard Shipping</span> (5-7 days)
                    <p className="text-sm text-muted-foreground">Approx. {cartItems.length > 0 ? '500.00' : '0.00'} DA - Managed by Seller</p>
                  </div>
                </Label>
                <Label htmlFor="shipping-express" className="flex items-center p-3 border rounded-md cursor-pointer hover:bg-muted/50 has-[:checked]:ring-2 has-[:checked]:ring-primary has-[:checked]:border-primary">
                  <RadioGroupItem value="app_partner" id="shipping-express" className="mr-3" />
                  <div>
                    <span className="font-medium">App Partner Express</span> (2-3 days)
                    <p className="text-sm text-muted-foreground">Approx. {cartItems.length > 0 ? '1200.00' : '0.00'} DA - Via Yalidine/EMS (Conceptual)</p>
                  </div>
                </Label>
                 <Label htmlFor="shipping-pickup" className="flex items-center p-3 border rounded-md cursor-pointer hover:bg-muted/50 has-[:checked]:ring-2 has-[:checked]:ring-primary has-[:checked]:border-primary">
                  <RadioGroupItem value="pickup" id="shipping-pickup" className="mr-3" />
                  <div>
                    <span className="font-medium">Collect from Store/Seller</span>
                    <p className="text-sm text-muted-foreground">Free - Arrange pickup directly</p>
                  </div>
                </Label>
              </RadioGroup>
            </CardContent>
          </Card>
          
           {/* Payment Method */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xl flex items-center"><CreditCard className="mr-2 h-5 w-5 text-primary" /> Payment Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-md text-blue-700 text-sm flex items-start gap-2">
                    <AlertCircle className="h-5 w-5 mt-0.5 shrink-0" />
                    <div>
                        <span className="font-semibold">Secure Payment via Escrow Wallet:</span> All payments are held securely by Khidmatik until you confirm satisfactory receipt of your order.
                    </div>
                </div>
                <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
                    <Label htmlFor="payment-escrow" className="flex items-center p-3 border rounded-md cursor-pointer hover:bg-muted/50 has-[:checked]:ring-2 has-[:checked]:ring-primary has-[:checked]:border-primary">
                        <RadioGroupItem value="escrow_wallet" id="payment-escrow" className="mr-3"/>
                        Khidmatik Escrow Wallet (Balance: 500.00 DA)
                    </Label>
                </RadioGroup>
                 <p className="text-xs text-muted-foreground">Other payment methods like Cash on Delivery (COD) may be enabled by sellers for certain items/locations and will appear here if available.</p>
            </CardContent>
          </Card>
        </div>

        {/* Order Summary */}
        <aside className="md:col-span-1">
          <Card className="sticky top-24 shadow-lg">
            <CardHeader>
              <CardTitle className="text-xl">Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {orderSummary.items.length === 0 && <p className="text-sm text-muted-foreground">Your cart is empty.</p>}
              {orderSummary.items.map((item, index) => (
                <div key={index} className="flex justify-between text-sm">
                  <span>{item.name} x {item.quantity}</span>
                  <span>{(item.price * item.quantity).toFixed(2)} DA</span>
                </div>
              ))}
              {orderSummary.items.length > 0 && <Separator className="my-2" />}
              <div className="flex justify-between text-sm">
                <span>Subtotal</span>
                <span>{orderSummary.subtotal.toFixed(2)} DA</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Shipping</span>
                <span>{orderSummary.shipping.toFixed(2)} DA</span>
              </div>
              <Separator className="my-2"/>
              <div className="flex justify-between font-bold text-lg">
                <span>Total</span>
                <span>{orderSummary.total.toFixed(2)} DA</span>
              </div>
            </CardContent>
            <CardFooter>
              <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground" size="lg" disabled={cartItems.length === 0}>
                <Package className="mr-2 h-5 w-5" /> Place Order
              </Button>
            </CardFooter>
          </Card>
        </aside>
      </form>
    </div>
  );
}
