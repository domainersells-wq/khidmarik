
'use client';

import { useSearchParams } from 'next/navigation';
import { OverviewSection } from '@/components/dashboard/store/OverviewSection';
import { OrdersSection } from '@/components/dashboard/store/OrdersSection';
import { ProductsSection } from '@/components/dashboard/store/ProductsSection';
import { CustomersSection } from '@/components/dashboard/store/CustomersSection';
import { MarketingSection } from '@/components/dashboard/store/MarketingSection';
import { AnalyticsSection } from '@/components/dashboard/store/AnalyticsSection';
import { SettingsSection } from '@/components/dashboard/store/SettingsSection';
import { FinancialsSection } from '@/components/dashboard/store/FinancialsSection'; // New
import { AISellerAssistantSection } from '@/components/dashboard/store/AISellerAssistantSection'; // New
import { useEffect } from 'react';


export default function StoreDashboardPage() {
  const searchParams = useSearchParams();
  const currentSection = searchParams.get('section') || 'overview';

  useEffect(() => {
    let title = 'Store Dashboard';
    if (currentSection) {
        const sectionName = currentSection.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
        title = `${sectionName} | Store Dashboard`;
    }
    document.title = `${title} | Khidmatik`;
  }, [currentSection]);


  const renderSection = () => {
    switch (currentSection) {
      case 'overview':
        return <OverviewSection />;
      case 'orders':
        return <OrdersSection />;
      case 'products':
        return <ProductsSection />;
      case 'customers':
        return <CustomersSection />;
      case 'marketing':
        return <MarketingSection />;
      case 'financials': // New
        return <FinancialsSection />;
      case 'ai-assistant': // New
        return <AISellerAssistantSection />;
      case 'analytics':
        return <AnalyticsSection />;
      case 'settings':
        return <SettingsSection />;
      default:
        return <OverviewSection />;
    }
  };

  return <div className="py-4 space-y-6">{renderSection()}</div>;
}
