
'use client';

import Image from 'next/image';
import Link from 'next/link';
import { useState, useEffect, use } from 'react'; // Added 'use'
import { mockListings, getDigitalServiceCategoryBySlug } from '@/data/mock';
import type { FreelancerProfile, PortfolioItem, ServicePackage, Review as ReviewType } from '@/types';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { StarRating } from '@/components/listings/StarRating';
import { ReviewList } from '@/components/listings/ReviewList';
import { ReviewForm } from '@/components/listings/ReviewForm';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Briefcase, Mail, MessageSquare, Phone, Globe, Palette, CheckCircle, Award, Sparkles, Users, DollarSign, FileText, MapPin as MapPinIcon, Clock as ClockIcon, Tag as TagIcon, ArrowLeft } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

interface FreelancerDetailPageProps {
  params: Promise<{ id: string }>;
}

function PortfolioItemCardDisplay({ item }: { item: PortfolioItem }) {
  return (
    <Card className="overflow-hidden">
      {item.imageUrl && (
        <div className="aspect-video bg-muted">
          <Image
            src={item.imageUrl}
            alt={item.title}
            width={400}
            height={225}
            className="object-cover w-full h-full"
            data-ai-hint={item.dataAiHint || item.title.toLowerCase().split(" ").slice(0,2).join(" ")}
          />
        </div>
      )}
      <CardHeader>
        <CardTitle className="text-lg">{item.title}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground mb-2">{item.description}</p>
        {item.projectUrl && (
          <Button variant="link" asChild className="p-0 h-auto">
            <a href={item.projectUrl} target="_blank" rel="noopener noreferrer">View Project</a>
          </Button>
        )}
      </CardContent>
    </Card>
  );
}

function ServicePackageCardDisplay({ pkg }: { pkg: ServicePackage }) {
  return (
    <Card className="bg-muted/50">
      <CardHeader>
        <CardTitle className="text-lg">{pkg.name}</CardTitle>
        <p className="text-2xl font-bold text-primary">{pkg.price.toLocaleString()} DA</p>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground mb-3">{pkg.description}</p>
        <h4 className="font-semibold text-sm mb-1">Deliverables:</h4>
        <ul className="list-disc list-inside text-sm space-y-1">
          {pkg.deliverables.map((d, i) => <li key={i}>{d}</li>)}
        </ul>
      </CardContent>
      <CardFooter>
        <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground" disabled>
          <DollarSign className="mr-2 h-4 w-4" /> Request This Package (Conceptual)
        </Button>
      </CardFooter>
    </Card>
  );
}


export default function FreelancerDetailPage({ params: paramsPromise }: FreelancerDetailPageProps) {
  const rawParams = use(paramsPromise); 
  const params = { ...rawParams }; // Ensure it's a plain object
  const freelancerId = params.id;

  const { toast } = useToast();
  const [freelancer, setFreelancer] = useState<FreelancerProfile | null>(null);

  useEffect(() => {
    const found = mockListings.find(l => l.id === freelancerId && l.type === 'freelancer') as FreelancerProfile | undefined;
    setFreelancer(found || null);
    if (found) {
      document.title = `${found.name} | Digital Services | Khidmatik`;
    } else {
      document.title = 'Freelancer Not Found | Khidmatik';
    }
  }, [freelancerId]);

  if (!freelancer) {
    return (
      <div className="text-center py-10">
        <h1 className="text-2xl font-bold">Freelancer Not Found</h1>
        <p>The freelancer profile you are looking for does not exist or has been removed.</p>
        <Link href="/digital-services" passHref>
          <Button variant="link" className="mt-4">Back to Digital Services</Button>
        </Link>
      </div>
    );
  }

  const categoryDetails = getDigitalServiceCategoryBySlug(freelancer.digitalCategorySlug);
  const CategoryIcon = categoryDetails?.icon || Palette;

  const handleContact = async () => {
    await new Promise(resolve => setTimeout(resolve, 200));
    toast({
        title: `Contact ${freelancer.name} (Conceptual)`,
        description: "This would open in-app chat. Payments via Khidmatik Escrow Wallet.",
        duration: 3000,
    });
  };
  
  const handleStartProject = async () => {
    await new Promise(resolve => setTimeout(resolve, 200));
     toast({
        title: `Start Project with ${freelancer.name} (Conceptual)`,
        description: "This would initiate project discussion. Use Escrow Wallet for payments.",
        duration: 3000,
    });
  };


  return (
    <div className="max-w-5xl mx-auto space-y-8">
      <Link href="/digital-services" className="inline-flex items-center text-sm text-muted-foreground hover:text-primary mb-6">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Digital Services
      </Link>

      <header className="flex flex-col md:flex-row md:items-start gap-6 p-6 bg-card border rounded-lg shadow-lg">
        <Avatar className="h-32 w-32 border-4 border-primary shadow-md mx-auto md:mx-0">
          <AvatarImage src={freelancer.images[0] || `https://api.dicebear.com/7.x/initials/svg?seed=${freelancer.name}`} alt={freelancer.name} />
          <AvatarFallback>{freelancer.name.split(" ").map(n=>n[0]).join("")}</AvatarFallback>
        </Avatar>
        <div className="flex-1 text-center md:text-left">
          <h1 className="text-4xl font-bold font-headline mb-1">{freelancer.name}</h1>
          {freelancer.tagline && <p className="text-xl text-muted-foreground mb-2">{freelancer.tagline}</p>}
          <div className="flex items-center justify-center md:justify-start gap-2 text-primary mb-2">
            <CategoryIcon className="h-5 w-5" />
            <span>{categoryDetails?.name || freelancer.digitalCategorySlug}</span>
          </div>
          <div className="flex items-center justify-center md:justify-start gap-2 mb-3">
            <StarRating rating={freelancer.averageRating} size={20} />
            <span className="text-md text-muted-foreground">({freelancer.reviews.length} reviews)</span>
          </div>
          <div className="flex flex-wrap gap-2 justify-center md:justify-start mb-4">
            {freelancer.skills.slice(0, 5).map(skill => (
              <Badge key={skill} variant="secondary">{skill}</Badge>
            ))}
          </div>
           <div className="flex flex-col sm:flex-row gap-2 justify-center md:justify-start">
             <Button onClick={handleContact} className="bg-primary hover:bg-primary/90 text-primary-foreground">
                <MessageSquare className="mr-2 h-4 w-4"/> Contact {freelancer.name.split(' ')[0]}
             </Button>
             <Button onClick={handleStartProject} variant="outline">
                <FileText className="mr-2 h-4 w-4"/> Start a Project
             </Button>
           </div>
        </div>
      </header>

      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl font-semibold">About Me</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-foreground whitespace-pre-line leading-relaxed">{freelancer.description}</p>
            </CardContent>
          </Card>

          {freelancer.portfolio.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-xl font-semibold flex items-center">
                  <Briefcase className="mr-2 h-5 w-5 text-primary" /> My Portfolio
                </CardTitle>
              </CardHeader>
              <CardContent className="grid sm:grid-cols-2 gap-4">
                {freelancer.portfolio.map(item => (
                  <PortfolioItemCardDisplay key={item.id} item={item} />
                ))}
              </CardContent>
            </Card>
          )}

          {freelancer.servicePackages.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-xl font-semibold flex items-center">
                  <DollarSign className="mr-2 h-5 w-5 text-primary" /> Service Packages
                </CardTitle>
              </CardHeader>
              <CardContent className="grid sm:grid-cols-1 md:grid-cols-2 gap-4">
                {freelancer.servicePackages.map(pkg => (
                  <ServicePackageCardDisplay key={pkg.id} pkg={pkg} />
                ))}
              </CardContent>
            </Card>
          )}
          
          <Card>
            <CardHeader>
                <CardTitle className="text-xl font-semibold flex items-center">
                    <Users className="mr-2 h-5 w-5 text-primary" /> Project Management
                </CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-sm text-muted-foreground">
                    Simplified communication and project milestone tracking will be available here soon.
                    All project payments are securely handled via the Khidmatik Escrow Wallet.
                </p>
            </CardContent>
          </Card>


          <Separator />
          <section id="reviews" className="space-y-6">
            <ReviewList reviews={freelancer.reviews} />
            <ReviewForm listingId={freelancerId} onReviewSubmitSuccess={handleReviewSubmitSuccess} />
          </section>
        </div>

        <aside className="md:col-span-1 space-y-6">
          <Card className="sticky top-20 shadow-lg">
            <CardHeader>
              <CardTitle className="text-xl font-semibold">Contact & Info</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              {freelancer.location.city && (
                <div className="flex items-start">
                  <MapPinIcon className="h-5 w-5 mr-3 mt-1 text-primary shrink-0" />
                  <span>{freelancer.location.city} {freelancer.location.zipCode && `(${freelancer.location.zipCode})`} - Primarily Remote</span>
                </div>
              )}
              {freelancer.contact.email && (
                <div className="flex items-center">
                  <Mail className="h-5 w-5 mr-3 text-primary" />
                  <a href={`mailto:${freelancer.contact.email}`} className="hover:text-primary truncate">{freelancer.contact.email}</a>
                </div>
              )}
              {freelancer.contact.phone && (
                <div className="flex items-center">
                  <Phone className="h-5 w-5 mr-3 text-primary" />
                  <a href={`tel:${freelancer.contact.phone}`} className="hover:text-primary">{freelancer.contact.phone}</a>
                </div>
              )}
              {freelancer.contact.website && (
                <div className="flex items-center">
                  <Globe className="h-5 w-5 mr-3 text-primary" />
                  <a href={freelancer.contact.website} target="_blank" rel="noopener noreferrer" className="hover:text-primary truncate">
                    {freelancer.contact.website.replace(/^https?:\/\//, '')}
                  </a>
                </div>
              )}
              {freelancer.operatingHours && (
                <div className="flex items-start">
                  <ClockIcon className="h-5 w-5 mr-3 mt-1 text-primary shrink-0" />
                  <span className="whitespace-pre-line">{freelancer.operatingHours}</span>
                </div>
              )}
               {freelancer.pricing && (
                <div className="flex items-center">
                  <TagIcon className="h-5 w-5 mr-3 text-primary" />
                  <span>Typical Project Price: {freelancer.pricing}</span>
                </div>
              )}
            </CardContent>
          </Card>
        </aside>
      </div>
    </div>
  );
}

