
'use client';

import { useState, Suspense, useEffect, use } from 'react'; 
import { useRouter, useSearchParams } from 'next/navigation';
import { mockListings, digitalServiceCategories, getDigitalServiceCategoryBySlug } from '@/data/mock';
import type { FreelancerProfile, DigitalServiceCategory } from '@/types';
import { FreelancerCard } from '@/components/digital-services/FreelancerCard';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { AlertTriangle, Palette, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface DigitalServicesPageProps {
  searchParams: Promise<{ 
    q?: string;
    category?: string;
  }>;
}

const ALL_DIGITAL_CATEGORIES_SENTINEL_VALUE = "_all_digital_";

function DigitalServicesGrid({ freelancers }: { freelancers: FreelancerProfile[] }) {
  if (freelancers.length === 0) {
    return (
      <div className="text-center py-12">
        <AlertTriangle className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
        <h2 className="text-2xl font-semibold mb-2">No Digital Service Providers Found</h2>
        <p className="text-muted-foreground mb-6">
          We couldn't find any freelancers matching your criteria. Try adjusting your search or filters.
        </p>
        <Button variant="outline" asChild>
          <Link href="/digital-services">Clear Filters and Search Again</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
      {freelancers.map((freelancer) => (
        <FreelancerCard key={freelancer.id} freelancer={freelancer} />
      ))}
    </div>
  );
}

export default function DigitalServicesPage({ searchParams: initialSearchParamsPromise }: DigitalServicesPageProps) {
  const rawInitialSearchParams = use(initialSearchParamsPromise); 
  const initialSearchParams = { ...rawInitialSearchParams }; // Ensure it's a plain object
  const router = useRouter();
  const currentParams = useSearchParams();

  const [searchTerm, setSearchTerm] = useState(initialSearchParams.q || '');
  const [selectedCategorySlug, setSelectedCategorySlug] = useState(initialSearchParams.category || '');

  useEffect(() => {
    document.title = 'Digital Services | Khidmatik';
  }, []);


  let filteredFreelancers = mockListings.filter(
    (l): l is FreelancerProfile => l.type === 'freelancer'
  );

  if (searchTerm) {
    const termLower = searchTerm.toLowerCase();
    filteredFreelancers = filteredFreelancers.filter(
      (f) =>
        f.name.toLowerCase().includes(termLower) ||
        f.tagline?.toLowerCase().includes(termLower) ||
        f.description.toLowerCase().includes(termLower) ||
        f.skills.some(skill => skill.toLowerCase().includes(termLower))
    );
  }

  if (selectedCategorySlug) {
    filteredFreelancers = filteredFreelancers.filter(
      (f) => f.digitalCategorySlug === selectedCategorySlug
    );
  }

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams(currentParams.toString());
    if (searchTerm) params.set('q', searchTerm); else params.delete('q');
    if (selectedCategorySlug) params.set('category', selectedCategorySlug); else params.delete('category');
    router.push(`/digital-services?${params.toString()}`);
  };

  const handleCategoryChange = (value: string) => {
    if (value === ALL_DIGITAL_CATEGORIES_SENTINEL_VALUE) {
      setSelectedCategorySlug('');
    } else {
      setSelectedCategorySlug(value);
    }
  };

  const currentCategoryDetails = selectedCategorySlug ? getDigitalServiceCategoryBySlug(selectedCategorySlug) : null;
  const pageTitle = currentCategoryDetails ? `Digital Services: ${currentCategoryDetails.name}` : 'Explore Digital Services';

  return (
    <div className="space-y-8">
      <header className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold font-headline mb-2 flex items-center">
          <Palette className="mr-3 h-8 w-8 text-primary" /> {pageTitle}
        </h1>
        <p className="text-lg text-muted-foreground">
          Find local freelancers and digital service providers in Algérie.
        </p>
      </header>

      <form
        onSubmit={handleSearchSubmit}
        className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 mb-8 bg-card rounded-lg shadow-md border"
      >
        <Input
          type="text"
          placeholder="Search by name, skill, service..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="md:col-span-2 h-11"
        />
        <Select
          value={selectedCategorySlug === '' ? ALL_DIGITAL_CATEGORIES_SENTINEL_VALUE : selectedCategorySlug}
          onValueChange={handleCategoryChange}
        >
          <SelectTrigger className="h-11">
            <SelectValue placeholder="All Digital Categories" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL_DIGITAL_CATEGORIES_SENTINEL_VALUE}>All Digital Categories</SelectItem>
            {digitalServiceCategories.map((cat) => (
              <SelectItem key={cat.slug} value={cat.slug}>
                {cat.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button type="submit" className="w-full md:col-span-3 bg-primary hover:bg-primary/90 text-primary-foreground h-11">
          <Search className="mr-2 h-5 w-5" /> Search Digital Services
        </Button>
      </form>

      {!selectedCategorySlug && (
        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-4">Browse by Category</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {digitalServiceCategories.map(cat => {
              const CategoryIcon = cat.icon;
              return (
                <Link key={cat.id} href={`/digital-services?category=${cat.slug}`} passHref>
                  <Card className="text-center hover:shadow-lg transition-shadow duration-300 cursor-pointer p-4 h-full flex flex-col items-center justify-center border hover:border-accent">
                    <CategoryIcon className="h-10 w-10 text-accent mb-2" />
                    <CardTitle className="text-md font-semibold">{cat.name}</CardTitle>
                  </Card>
                </Link>
              );
            })}
          </div>
        </section>
      )}


      <section>
         <Suspense fallback={<div className="text-center p-8">Loading freelancers...</div>}>
            <DigitalServicesGrid freelancers={filteredFreelancers} />
         </Suspense>
      </section>
    </div>
  );
}

