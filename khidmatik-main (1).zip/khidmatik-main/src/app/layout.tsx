
'use client';

import type { Metadata } from 'next';
import Link from 'next/link';
import { Store, Briefcase, UserCircle, FileText, GitBranch, MapPinned, Cog, SearchCode, Palette, ShoppingCart, Languages, Bell, AlertCircle, CalendarDays, PlusCircle, LayoutDashboard, Moon, Sun, ShieldCheck, LogOut } from 'lucide-react';
import './globals.css';
import { Button } from '@/components/ui/button';
import { Toaster } from "@/components/ui/toaster";
import { AppLogo } from '@/components/layout/AppLogo';
import { Separator } from '@/components/ui/separator';
import { ThemeProvider } from 'next-themes';
import { ThemeToggleButton } from '@/components/layout/ThemeToggleButton';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuGroup,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { useToast } from "@/hooks/use-toast";
import type { NotificationItem, UserProfileData, Language } from '@/types';
import { formatDistanceToNow } from 'date-fns';
import { useState, useEffect } from 'react';
import { mockUserProfile } from '@/data/mock';
import { LanguageProvider, useLanguage } from '@/context/LanguageContext';

// Mock notifications data
const mockNotifications: NotificationItem[] = [
  {
    id: 'notif1',
    type: 'reservation',
    title: 'Appointment Confirmed: Dr. Fatima Zohra',
    message: 'Your appointment for tomorrow at 10:00 AM is confirmed. Ref ID: APT-DRF-12345.',
    timestamp: new Date(new Date().setDate(new Date().getDate() + 1)).toISOString(),
    icon: CalendarDays,
    isRead: false,
  },
  {
    id: 'notif2',
    type: 'purchase',
    title: 'Order Shipped: #ORD-XYZ-789',
    message: 'Your order for "Modern LED Chandelier" has been shipped and is on its way!',
    timestamp: new Date(new Date().setDate(new Date().getDate() - 1)).toISOString(),
    icon: ShoppingCart,
    isRead: false,
  },
  {
    id: 'notif3',
    type: 'alert',
    title: 'Low Stock Alert: Artisan Bread',
    message: 'Your product "Artisan Bread" has only 5 units left in stock.',
    timestamp: new Date().toISOString(),
    icon: AlertCircle,
    isRead: true,
  },
  {
    id: 'notif4',
    type: 'system',
    title: 'Welcome to Khidmatik v1.1!',
    message: 'We\'ve updated our services. Check out the new features on the app roadmap.',
    timestamp: new Date(new Date().setDate(new Date().getDate() - 3)).toISOString(),
    icon: Cog,
    isRead: true,
  },
];

interface HeaderProps {
  isStoreOwner: boolean;
  isFreelancer: boolean;
}

function Header({ isStoreOwner, isFreelancer }: HeaderProps) {
  const { toast } = useToast();
  const [notifications, setNotifications] = useState<NotificationItem[]>(mockNotifications);
  const { language, setLanguage, translate } = useLanguage();

  const handleLanguageChange = (lang: Language) => {
    setLanguage(lang);
    let langName = 'English';
    if (lang === 'ar') langName = 'العربية';
    if (lang === 'fr') langName = 'Français';
    toast({
      title: translate('languageSwitched', `Language Switched to ${langName}`),
      description: translate('languageSwitchedDesc', `App language set to ${langName}. Some text may update.`),
    });
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
  };

  return (
    <header className="bg-card border-b sticky top-0 z-50 shadow-sm">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 text-primary hover:opacity-80 transition-opacity">
          <AppLogo className="h-8 w-8" aria-label="Khidmatik Logo" />
          <h1 className="text-2xl font-headline font-bold">Khidmatik</h1>
        </Link>

        <nav className="flex items-center">
          {/* Page Navigation Links */}
          <div className="hidden md:flex items-center gap-4 mr-6">
            <Button variant="outline" size="sm" asChild className="active:scale-95 active:border-primary">
              <Link href="/listings?type=store" className="flex items-center gap-1">
                <Store className="h-4 w-4" />
                <span>{translate('stores','Stores')}</span>
              </Link>
            </Button>
            <Button variant="outline" size="sm" asChild className="active:scale-95 active:border-primary">
              <Link href="/listings?type=professional" className="flex items-center gap-1">
                <Briefcase className="h-4 w-4" />
                <span>{translate('services','Services')}</span>
              </Link>
            </Button>
            <Button variant="outline" size="sm" asChild className="active:scale-95 active:border-primary">
              <Link href="/digital-services" className="flex items-center gap-1">
                <Palette className="h-4 w-4" />
                <span>{translate('digital','Digital')}</span>
              </Link>
            </Button>
            <Button variant="outline" size="sm" asChild className="active:scale-95 active:border-primary">
              <Link href="/marketplace" className="flex items-center gap-1">
                <Cog className="h-4 w-4" />
                <span>{translate('marketplace','Marketplace')}</span>
              </Link>
            </Button>
          </div>

          {/* Action Icons Group */}
          <div className="flex items-center gap-1 sm:gap-2">
            <ThemeToggleButton />

            <Button variant="outline" size="icon" asChild className="ml-1">
              <Link href="/cart">
                <ShoppingCart className="h-5 w-5" />
                <span className="sr-only">Shopping Cart</span>
              </Link>
            </Button>

            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon" className="ml-1 relative">
                  <Bell className="h-5 w-5" />
                  {notifications.filter(n => !n.isRead).length > 0 && (
                    <span className="absolute top-0 right-0 -mt-1 -mr-1 flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
                    </span>
                  )}
                  <span className="sr-only">{translate('notifications', 'Notifications')}</span>
                </Button>
              </SheetTrigger>
              <SheetContent className="w-[350px] sm:w-[450px] flex flex-col p-0">
                <SheetHeader className="p-4 border-b">
                  <SheetTitle>{translate('notifications', 'Notifications')}</SheetTitle>
                  <SheetDescription>{translate('recentActivityAlertsUpdates', 'Recent activity, alerts, and updates.')}</SheetDescription>
                </SheetHeader>
                <div className="flex-1 overflow-y-auto p-4 space-y-3">
                  {notifications.length > 0 ? (
                    notifications.map(notification => {
                      const NotificationIcon = notification.icon || AlertCircle;
                      return (
                        <div
                          key={notification.id}
                          className={`p-3 rounded-md border flex items-start gap-3 transition-colors hover:bg-muted/50 ${notification.isRead ? 'bg-card' : 'bg-accent/10 border-accent/50'}`}
                          onClick={() => markNotificationAsRead(notification.id)}
                          role="button"
                          tabIndex={0}
                          onKeyDown={(e) => e.key === 'Enter' && markNotificationAsRead(notification.id)}
                        >
                          <NotificationIcon className={`h-5 w-5 mt-1 shrink-0 ${notification.type === 'alert' ? 'text-destructive' : notification.type === 'purchase' ? 'text-green-500' : notification.type === 'reservation' ? 'text-blue-500' : 'text-primary'}`} />
                          <div className="flex-1">
                            <p className={`font-semibold text-sm ${notification.isRead ? 'text-foreground' : 'text-primary'}`}>{notification.title}</p>
                            <p className="text-xs text-muted-foreground">{notification.message}</p>
                            <p className="text-xs text-muted-foreground/80 mt-1">
                              {formatDistanceToNow(new Date(notification.timestamp), { addSuffix: true })}
                            </p>
                          </div>
                          {!notification.isRead && <span className="h-2.5 w-2.5 bg-primary rounded-full mt-1.5 shrink-0" title="Unread"></span>}
                        </div>
                      );
                    })
                  ) : (
                    <p className="text-sm text-muted-foreground text-center py-10">No new notifications.</p>
                  )}
                </div>
                <div className="p-4 border-t">
                  <Button variant="link" size="sm" className="w-full text-muted-foreground" disabled>{translate('viewAllNotifications', 'View All Notifications')}</Button>
                </div>
              </SheetContent>
            </Sheet>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="icon" className="ml-1">
                  <Languages className="h-5 w-5" />
                  <span className="sr-only">{translate('selectLanguage', 'Change language')}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>{translate('selectLanguage', 'Select Language')}</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onSelect={() => handleLanguageChange('en')}>{translate('english', 'English')}</DropdownMenuItem>
                <DropdownMenuItem onSelect={() => handleLanguageChange('ar')}>{translate('arabic', 'العربية (Arabic)')}</DropdownMenuItem>
                <DropdownMenuItem onSelect={() => handleLanguageChange('fr')}>{translate('french', 'Français (French)')}</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button variant="outline" size="sm" asChild>
              <Link href="/login">
                {translate('logIn', 'Log In')}
              </Link>
            </Button>
            <Button variant="default" size="sm" asChild className="bg-primary hover:bg-primary/90 text-primary-foreground">
              <Link href="/register/choice">
                {translate('register', 'Register')}
              </Link>
            </Button>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="icon" className="ml-1">
                  <UserCircle className="h-5 w-5" />
                  <span className="sr-only">{translate('profileMenu', 'Profile Menu')}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>{translate('myAccount', 'My Account')}</DropdownMenuLabel>
                <DropdownMenuItem asChild>
                  <Link href="/profile">
                    <UserCircle className="mr-2 h-4 w-4" /> {translate('profile', 'Profile')}
                  </Link>
                </DropdownMenuItem>

                {(isStoreOwner || isFreelancer) && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuLabel>{translate('dashboards', 'Dashboards')}</DropdownMenuLabel>
                    {isStoreOwner && (
                      <DropdownMenuItem asChild>
                          <Link href="/dashboard/store">
                              <Store className="mr-2 h-4 w-4" /> {translate('myStoreDashboard', 'My Store Dashboard')}
                          </Link>
                      </DropdownMenuItem>
                    )}
                    {isFreelancer && (
                      <DropdownMenuItem asChild>
                          <Link href="/dashboard/professional-services">
                              <Briefcase className="mr-2 h-4 w-4" /> {translate('servicesAdminPanel', 'Services Admin Panel')}
                          </Link>
                      </DropdownMenuItem>
                    )}
                  </>
                )}

                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                    <Link href="/admin/login">
                        <ShieldCheck className="mr-2 h-4 w-4" /> {translate('platformSuperAdmin', 'Platform Super Admin')}
                    </Link>
                </DropdownMenuItem>

                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => toast({ title: "Logged Out (Conceptual)"})}>
                  <LogOut className="mr-2 h-4 w-4" /> {translate('logOut', 'Log Out')}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </nav>
      </div>
    </header>
  );
}

function Footer() {
  const { translate } = useLanguage();
  return (
    <footer className="bg-muted text-muted-foreground py-8 mt-auto">
      <div className="container mx-auto px-4 text-center">
        <p>&copy; {new Date().getFullYear()} {translate('footerRights', 'Khidmatik. All rights reserved.')}</p>
        <div className="text-sm mt-2 space-x-4 flex items-center justify-center flex-wrap">
            <Link href="/app-roadmap" className="hover:text-primary hover:underline flex items-center justify-center gap-1 my-1">
                <GitBranch className="h-4 w-4" /> {translate('appRoadmap', 'App Roadmap')}
            </Link>
            <Link href="/service-point" className="hover:text-primary hover:underline flex items-center justify-center gap-1 my-1">
                <MapPinned className="h-4 w-4" /> {translate('servicePoint', 'Service Point')}
            </Link>
        </div>
        <p className="text-sm mt-1">{translate('footerSlogan', 'Connecting communities in Algérie, one click at a time.')}</p>
      </div>
    </footer>
  );
}


export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {

  const isStoreOwner = mockUserProfile.isStoreOwner;
  const isFreelancer = mockUserProfile.isFreelancer;

  return (
    <LanguageProvider>
      <ClientRootLayoutContent isStoreOwner={isStoreOwner} isFreelancer={isFreelancer}>
        {children}
      </ClientRootLayoutContent>
    </LanguageProvider>
  );
}

// New component to consume language context properly
function ClientRootLayoutContent({
  children,
  isStoreOwner,
  isFreelancer
}: Readonly<{
  children: React.ReactNode;
  isStoreOwner: boolean;
  isFreelancer: boolean;
}>) {
  const { language } = useLanguage(); // Ensure context is used within provider

  return (
    <html lang={language} dir={language === 'ar' ? 'rtl' : 'ltr'} suppressHydrationWarning>
      <head>
        <title>Khidmatik - Your Super App for Algérie</title>
        <meta name="description" content="Khidmatik - Your Super App for Algérie! Discover stores, services, parts, and more. Connect with your community across Algérie." />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=PT+Sans:ital,wght@0,400;0,700;1,400;1,700&display=swap" rel="stylesheet" />
      </head>
      <body className="font-body antialiased flex flex-col min-h-screen">
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <Header isStoreOwner={isStoreOwner} isFreelancer={isFreelancer} />
          <main className="flex-grow container mx-auto px-4 py-8">
            {children}
          </main>
          <Footer />
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}

    