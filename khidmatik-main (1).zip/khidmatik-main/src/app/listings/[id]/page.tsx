
'use client';

import Image from 'next/image';
import Link from 'next/link';
import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import { getListingById, categories as allCategories, mockListings, getCategoryBySlug } from '@/data/mock';
import { StarRating } from '@/components/listings/StarRating';
import { ReviewList } from '@/components/listings/ReviewList';
import { ReviewForm } from '@/components/listings/ReviewForm';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription as DialogDesc, DialogFooter } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { MapPin, Phone, Globe, Mail, Clock, Tag, Building, Briefcase, CheckCircle, Award, ShieldCheck, Users, Cog, ShoppingBag, Sparkles, Warehouse, AlertTriangle, CalendarClock, MessageSquare } from 'lucide-react';
import type { Store, Professional, VerifiedBadge as VerifiedBadgeType, Listing, ProductItem, Category, Review, Appointment } from '@/types';
import { useToast } from "@/hooks/use-toast";
import { ProductItemCard } from '@/components/listings/ProductItemCard';
import { GroupOrderItemCard } from '@/components/listings/GroupOrderItemCard';
import { MadeInAlgeriaBadge } from '@/components/listings/MadeInAlgeriaBadge'; 
import { EmergencySOSDialog, type ServiceType } from '@/components/features/EmergencySOSDialog';
import { AppointmentBookingDialog } from '@/components/listings/AppointmentBookingDialog'; 

interface ListingDetailPageProps {
  // params: { id: string }; // Removed as we'll use useParams
}

const emergencyServiceCategorySlugs: string[] = ['plumbers', 'electricians', 'hvac-services', 'handyman'];
const categorySlugToServiceTypeMap: Record<string, ServiceType> = {
  'plumbers': 'plumbing',
  'electricians': 'electrical',
  'hvac-services': 'handyman',
  'handyman': 'handyman',
};

const VerifiedBadgeDisplay = ({ badge }: { badge: VerifiedBadgeType }) => {
  const BadgeIcon = badge.icon || CheckCircle;
  return (
    <TooltipProvider delayDuration={100}>
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge variant="secondary" className="flex items-center gap-1.5 py-1 px-2.5 border-green-600/50 bg-green-50 text-green-700 hover:bg-green-100">
            <BadgeIcon className="h-4 w-4" />
            <span className="text-xs font-medium">{badge.name}</span>
          </Badge>
        </TooltipTrigger>
        {badge.description && (
          <TooltipContent className="max-w-xs bg-popover text-popover-foreground">
            <p>{badge.description}</p>
          </TooltipContent>
        )}
      </Tooltip>
    </TooltipProvider>
  );
};

export default function ListingDetailPage({ }: ListingDetailPageProps) {
  const routeParams = useParams<{ id: string }>();
  const listingId = routeParams.id;
  
  const [listing, setListing] = useState<Listing | null | undefined>(undefined); 
  const { toast } = useToast();

  const [isTechnicianModalOpen, setIsTechnicianModalOpen] = useState(false);
  const [currentProductForInstallation, setCurrentProductForInstallation] = useState<ProductItem | null>(null);
  const [availableInstallers, setAvailableInstallers] = useState<Professional[]>([]);

  const [isSosDialogOpen, setIsSosDialogOpen] = useState(false);
  const [currentSosServiceType, setCurrentSosServiceType] = useState<ServiceType | undefined>(undefined);

  const [isAppointmentDialogOpen, setIsAppointmentDialogOpen] = useState(false); 

  useEffect(() => {
    const fetchedListing = getListingById(listingId);
    setListing(fetchedListing);
    if (fetchedListing) {
      document.title = `${fetchedListing.name} | Khidmatik`;
    } else {
      document.title = 'Listing Not Found | Khidmatik';
    }
  }, [listingId]);

  const handleReviewSubmitSuccess = (newReview: Review) => {
    if (!listing) return;

    const updatedReviews = [...listing.reviews, newReview];
    const totalRatingSum = updatedReviews.reduce((sum, r) => sum + r.rating, 0);
    const newAverageRating = updatedReviews.length > 0 ? totalRatingSum / updatedReviews.length : 0;

    setListing(prevListing => prevListing ? {
      ...prevListing,
      reviews: updatedReviews,
      averageRating: parseFloat(newAverageRating.toFixed(1)), 
    } : null);

    toast({
      title: "Review Submitted!",
      description: "Thank you for your feedback! The listing's average rating has been updated.",
      duration: 5000,
    });
  };

  if (listing === undefined) { 
    return <div className="text-center py-10">Loading listing details...</div>;
  }

  if (!listing) { 
    return (
      <div className="text-center py-10">
        <h1 className="text-2xl font-bold">Listing Not Found</h1>
        <p>The listing you are looking for does not exist or has been removed.</p>
        <Link href="/listings" passHref>
          <Button variant="link" className="mt-4">Go back to listings</Button>
        </Link>
      </div>
    );
  }
  
  const storeListing = listing.type === 'store' ? listing as Store : null;
  const professionalListing = listing.type === 'professional' ? listing as Professional : null;
  
  const categoryDetails = allCategories.find(c => c.name === listing.category);
  const CategoryIcon = categoryDetails?.icon;
  const categorySlug = categoryDetails?.slug;

  const isEmergencyCategory = professionalListing && categorySlug && emergencyServiceCategorySlugs.includes(categorySlug);
  const sosServiceTypeForCurrentCategory = categorySlug ? categorySlugToServiceTypeMap[categorySlug] : undefined;


  const handleContactForQuote = async (professionalName: string) => {
    await new Promise(resolve => setTimeout(resolve, 200));
    toast({
        title: "Contact for Quote",
        description: `Please contact ${professionalName} directly to inquire about their services and obtain a quote. You can use the contact details provided. In-app chat coming soon!`,
        duration: 6000,
    });
  };


  const handleAddWithInstallation = (product: ProductItem) => {
    if (!product.installationServiceCategory) {
        toast({ title: "Error", description: "Installation category not specified for this product.", variant: "destructive"});
        return;
    }
    const instCategorySlug = product.installationServiceCategory;
    const targetCategory = allCategories.find(c => c.slug === instCategorySlug);

    if (!targetCategory) {
        toast({ title: "Error", description: `No category found for slug: ${instCategorySlug}`, variant: "destructive"});
        return;
    }
    
    const installers = mockListings.filter(
      (l): l is Professional => 
        l.type === 'professional' && 
        l.category === targetCategory.name && 
        typeof l.standardInstallationPrice === 'number'
    );

    setCurrentProductForInstallation(product);
    setAvailableInstallers(installers);
    setIsTechnicianModalOpen(true);
  };

  const handleSelectTechnician = async (technician: Professional) => {
    if (!currentProductForInstallation || typeof technician.standardInstallationPrice !== 'number') return;
    
    const productPrice = currentProductForInstallation.variants && currentProductForInstallation.variants.length > 0 
                         ? (currentProductForInstallation.variants[0].price) 
                         : 0;

    const totalProjectCost = productPrice + technician.standardInstallationPrice;
    
    await new Promise(resolve => setTimeout(resolve, 200)); 

    toast({
      title: "Project Item Added!",
      description: `${currentProductForInstallation.name} and ${currentProductForInstallation.installationTaskName} by ${technician.name} added. Total: ${totalProjectCost.toFixed(2)} DA. Funds will be moved to Khidmatik Escrow Wallet.`,
      duration: 6000,
    });
    setIsTechnicianModalOpen(false);
    setCurrentProductForInstallation(null);
    setAvailableInstallers([]);
  };

  const handleEmergencySOS = () => {
    if (sosServiceTypeForCurrentCategory) {
        setCurrentSosServiceType(sosServiceTypeForCurrentCategory);
        setIsSosDialogOpen(true);
    } else {
        setCurrentSosServiceType(undefined);
        setIsSosDialogOpen(true);
        toast({ title: "Notice", description: "Please select the emergency type in the dialog.", variant: "default" });
    }
  };
  
  const handleNewAppointmentRequested = (newAppointment: Appointment) => {
    // In a real app, this might update global state or trigger a refetch
    // For now, just log and potentially update local listing state if needed (e.g., appointment count)
    console.log("New appointment requested from dialog:", newAppointment);
    toast({
      title: "Appointment Request Received by Page",
      description: `Your request for ${newAppointment.professionalName} is being processed by the page.`,
      duration: 3000
    });
  };


  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-fade-in">
      {storeListing?.bannerImageUrl && (
        <div className="w-full h-48 md:h-64 rounded-lg overflow-hidden shadow-lg mb-4 bg-muted">
          <Image
            src={storeListing.bannerImageUrl}
            alt={`${storeListing.name} banner`}
            width={1200}
            height={300}
            className="object-cover w-full h-full"
            data-ai-hint="store banner"
          />
        </div>
      )}
      <header className="mb-6">
        <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
          <div className="flex items-start gap-4">
            {(storeListing?.storeLogoUrl || professionalListing?.clinicLogoUrl) && (
              <Image
                src={storeListing?.storeLogoUrl || professionalListing?.clinicLogoUrl || 'https://placehold.co/80x80.png'}
                alt={`${listing.name} logo`}
                width={80}
                height={80}
                className="rounded-md border shadow-sm object-contain"
                data-ai-hint={storeListing ? "store logo" : professionalListing?.clinicLogoUrl ? "clinic logo" : "logo"}
              />
            )}
            <div>
                <h1 className="text-4xl font-bold font-headline mb-1">{listing.name}</h1>
                {storeListing?.isMadeInAlgeria && <MadeInAlgeriaBadge />}
                <div className="flex items-center gap-3 text-muted-foreground mb-2 mt-1">
                {CategoryIcon && <CategoryIcon className="h-5 w-5 text-primary" />}
                <span>{listing.category}</span>
                <span className="mx-1">·</span>
                <MapPin className="h-5 w-5 text-primary" />
                <span>{listing.location.city}</span>
                </div>
                 {professionalListing && professionalListing.verifiedBadges && (professionalListing.verifiedBadges?.length ?? 0) > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                    {professionalListing.verifiedBadges?.map((badge, idx) => (
                    <VerifiedBadgeDisplay key={idx} badge={badge} />
                    ))}
                </div>
                )}
            </div>
          </div>
          <div className="flex flex-col items-end gap-2 pt-2 md:pt-0 flex-shrink-0">
             <div className="flex items-center gap-2">
                <StarRating rating={listing.averageRating} size={24} />
                <span className="text-lg text-muted-foreground">({listing.reviews.length} reviews)</span>
             </div>
             {isEmergencyCategory && (
                <Button 
                    variant="destructive" 
                    onClick={handleEmergencySOS} 
                    className="mt-2 animate-pulse-subtle hover:animate-none"
                >
                    <AlertTriangle className="mr-2 h-4 w-4" />
                    SOS: Emergency {listing.category} Help
                </Button>
             )}
          </div>
        </div>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        {listing.images.slice(0, storeListing?.bannerImageUrl ? 1 : 2).map((src, index) => ( 
          <div key={index} className={`aspect-video rounded-lg overflow-hidden shadow-lg ${index === 0 && listing.images.length > 1 && !storeListing?.bannerImageUrl ? 'md:col-span-2' : ''}`}>
            <Image
              src={src || 'https://placehold.co/800x450.png'}
              alt={`${listing.name} - Image ${index + 1}`}
              width={800}
              height={450}
              className="object-cover w-full h-full hover:scale-105 transition-transform duration-300"
              data-ai-hint={listing.dataAiHint || `${listing.type} ${listing.category} interior`}
            />
          </div>
        ))}
      </section>

      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl font-semibold">About {listing.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-foreground leading-relaxed">{listing.description}</p>
              {professionalListing && professionalListing.servicePrice !== undefined && (
                <div className="mt-4 p-3 bg-muted/50 rounded-md">
                    <p className="font-semibold text-lg text-primary">Typical Service Price: {professionalListing.servicePrice.toFixed(2)} DA</p>
                    <p className="text-xs text-muted-foreground">(This is an indicative price. Please contact for a detailed quote or book an appointment if available.)</p>
                </div>
              )}
            </CardContent>
          </Card>
          
          {storeListing && (
            <Card>
                <CardHeader>
                    <CardTitle className="text-xl font-semibold flex items-center">
                        <Warehouse className="mr-2 h-5 w-5 text-primary" /> Store Management
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <Button variant="outline" asChild>
                      <Link href="/profile">
                        Go to My Store Dashboard
                      </Link>
                    </Button>
                    <p className="text-xs text-muted-foreground mt-2">
                        Store owners can manage products, subscriptions, and shipping via their profile dashboard.
                    </p>
                </CardContent>
            </Card>
          )}


          {storeListing?.products && (storeListing.products?.length ?? 0) > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-xl font-semibold flex items-center">
                  <ShoppingBag className="mr-2 h-5 w-5 text-primary" /> Products Available
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {storeListing.products?.map((product) => (
                    <ProductItemCard 
                      key={product.id} 
                      product={product} 
                      onAddWithInstallation={handleAddWithInstallation} 
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {storeListing?.groupOrderItems && (storeListing.groupOrderItems?.length ?? 0) > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-xl font-semibold flex items-center">
                  <Users className="mr-2 h-5 w-5 text-primary" /> Special Group Order Deals
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-6">
                  {storeListing.groupOrderItems?.map((item) => (
                    <GroupOrderItemCard key={item.id} item={item} />
                  ))}
                </div>
              </CardContent>
            </Card>
          )}


          {professionalListing && professionalListing.servicesOffered && (
            <Card>
              <CardHeader>
                <CardTitle className="text-xl font-semibold flex items-center">
                  <Briefcase className="mr-2 h-5 w-5 text-primary" /> Services Offered
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="list-disc list-inside space-y-1 text-foreground">
                  {professionalListing.servicesOffered.map((service, idx) => (
                    <li key={idx}>{service}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}
          
          {professionalListing && professionalListing.qualifications && (professionalListing.qualifications?.length ?? 0) > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-xl font-semibold flex items-center">
                  <Award className="mr-2 h-5 w-5 text-primary" /> Qualifications
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="list-disc list-inside space-y-1 text-foreground">
                  {professionalListing.qualifications?.map((qual, idx) => (
                    <li key={idx}>{qual}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}

          <Separator />

          <section id="reviews" className="space-y-6">
            <ReviewList reviews={listing.reviews} />
            <ReviewForm listingId={listing.id} onReviewSubmitSuccess={handleReviewSubmitSuccess} />
          </section>
        </div>

        <aside className="md:col-span-1 space-y-6">
          <Card className="sticky top-20 shadow-lg">
            <CardHeader>
              <CardTitle className="text-xl font-semibold">Contact & Info</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              {listing.location.fullAddress && (
                <div className="flex items-start">
                  <MapPin className="h-5 w-5 mr-3 mt-1 text-primary shrink-0" />
                  <span>{listing.location.fullAddress}, {listing.location.city}</span>
                </div>
              )}
              {listing.contact.phone && (
                <div className="flex items-center">
                  <Phone className="h-5 w-5 mr-3 text-primary" />
                  <a href={`tel:${listing.contact.phone}`} className="hover:text-primary">{listing.contact.phone}</a>
                </div>
              )}
              {listing.contact.email && (
                <div className="flex items-center">
                  <Mail className="h-5 w-5 mr-3 text-primary" />
                  <a href={`mailto:${listing.contact.email}`} className="hover:text-primary truncate">{listing.contact.email}</a>
                </div>
              )}
              {listing.contact.website && (
                <div className="flex items-center">
                  <Globe className="h-5 w-5 mr-3 text-primary" />
                  <a href={listing.contact.website} target="_blank" rel="noopener noreferrer" className="hover:text-primary truncate">
                    {listing.contact.website.replace(/^https?:\/\//, '')}
                  </a>
                </div>
              )}
              {listing.operatingHours && (
                <div className="flex items-start">
                  <Clock className="h-5 w-5 mr-3 mt-1 text-primary shrink-0" />
                  <span className="whitespace-pre-line">{listing.operatingHours}</span>
                </div>
              )}
              {listing.pricing && ( 
                <div className="flex items-center">
                  <Tag className="h-5 w-5 mr-3 text-primary" />
                  <span>Pricing Level: {listing.pricing}</span>
                </div>
              )}
              
              {professionalListing && professionalListing.supportsAppointments && professionalListing.appointmentConfig && (
                <Button 
                  onClick={() => setIsAppointmentDialogOpen(true)} 
                  className="w-full mt-4 bg-accent hover:bg-accent/90 text-accent-foreground"
                >
                  <CalendarClock className="mr-2 h-4 w-4" /> Book Appointment
                </Button>
              )}
              {professionalListing && !professionalListing.supportsAppointments && (
                <Button 
                  onClick={() => handleContactForQuote(listing.name)} 
                  className="w-full mt-4 bg-accent hover:bg-accent/90 text-accent-foreground"
                >
                  <MessageSquare className="mr-2 h-4 w-4" /> Contact for Quote
                </Button>
              )}
              <p className="text-xs text-muted-foreground text-center mt-2">
                Service fees and payment are handled directly with the professional/clinic.
              </p>
            </CardContent>
          </Card>
        </aside>
      </div>

      {currentProductForInstallation && (
        <Dialog open={isTechnicianModalOpen} onOpenChange={setIsTechnicianModalOpen}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle className="flex items-center">
                <Cog className="mr-2 h-5 w-5 text-primary" />
                Select Technician for {currentProductForInstallation.installationTaskName}
              </DialogTitle>
              <DialogDesc>
                Choose a professional to install your {currentProductForInstallation.name.toLowerCase()}. 
                Product price: {(currentProductForInstallation.variants?.[0]?.price ?? 0).toFixed(2)} DA.
              </DialogDesc>
            </DialogHeader>
            <ScrollArea className="max-h-[50vh] pr-4">
              {availableInstallers.length > 0 ? (
                <div className="space-y-3 py-2">
                  {availableInstallers.map((installer) => (
                    <Card key={installer.id} className="p-3 hover:shadow-md transition-shadow">
                      <div className="flex justify-between items-center">
                        <div>
                          <h4 className="font-semibold">{installer.name}</h4>
                          <div className="flex items-center text-sm text-muted-foreground">
                            <StarRating rating={installer.averageRating} size={16} />
                            <span className="ml-1.5">({installer.reviews.length} reviews)</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-lg text-primary">
                            {installer.standardInstallationPrice?.toFixed(2)} DA
                          </p>
                          <p className="text-xs text-muted-foreground">Installation Fee</p>
                        </div>
                      </div>
                      <Button 
                        onClick={() => handleSelectTechnician(installer)}
                        className="w-full mt-3"
                        size="sm"
                      >
                        Choose & Add to Project
                      </Button>
                    </Card>
                  ))}
                </div>
              ) : (
                <p className="py-4 text-center text-muted-foreground">
                  No technicians currently available for this specific installation service category.
                </p>
              )}
            </ScrollArea>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsTechnicianModalOpen(false)}>Cancel</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
      <EmergencySOSDialog 
        isOpen={isSosDialogOpen} 
        onOpenChange={setIsSosDialogOpen} 
        defaultServiceType={currentSosServiceType} 
      />
      {professionalListing && professionalListing.supportsAppointments && professionalListing.appointmentConfig && (
        <AppointmentBookingDialog
            isOpen={isAppointmentDialogOpen}
            onOpenChange={setIsAppointmentDialogOpen}
            professional={professionalListing}
            onAppointmentRequested={handleNewAppointmentRequested}
        />
      )}
    </div>
  );
}
