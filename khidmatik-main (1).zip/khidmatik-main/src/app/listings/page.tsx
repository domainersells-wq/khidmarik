
import { Suspense } from 'react';
import { ListingCard } from '@/components/listings/ListingCard';
import { SearchBar } from '@/components/listings/SearchBar';
import { AISearchRefinements } from '@/components/listings/AISearchRefinements';
import { mockListings, categories as allCategories, getCategoryBySlug } from '@/data/mock';
import type { Listing, Category, Professional } from '@/types';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { AlertTriangle, Search } from 'lucide-react';
import type { Metadata } from 'next';
import type { SuggestSearchRefinementsInput } from '@/ai/flows/suggest-search-refinements';

interface ListingsPageProps {
  searchParams: Promise<{ // Changed to Promise
    q?: string;
    category?: string;
    location?: string;
    type?: 'store' | 'professional' | '';
  }>;
}

export async function generateMetadata({ searchParams: searchParamsPromise }: ListingsPageProps): Promise<Metadata> {
  const searchParams = await searchParamsPromise; // Await the searchParams
  const { q, category, location, type } = searchParams;
  let title = 'Browse Listings';
  if (type === 'store') title = 'Browse Stores';
  if (type === 'professional') title = 'Browse Professionals';
  
  if (category) {
    const catDetails = getCategoryBySlug(category);
    if (catDetails) title = `Browse ${catDetails.name}`;
  }
  if (q) title = `Search results for "${q}"`;
  if (location) title = `${title} in ${location}`;


  return {
    title: `${title} | Khidmatik`,
    description: `Find local stores and professionals on Khidmatik. Search by keyword, category, and location. ${type ? `Showing ${type}s.` : ''}`,
  };
}


function ListingsGrid({ filteredListings, searchTerm, currentUserLocationQuery }: { filteredListings: Listing[], searchTerm?: string, currentUserLocationQuery?: string }) {
  if (filteredListings.length === 0) {
    return (
      <div className="text-center py-12">
        <AlertTriangle className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
        <h2 className="text-2xl font-semibold mb-2">No Listings Found</h2>
        <p className="text-muted-foreground mb-6">
          We couldn't find any listings matching your criteria. Try adjusting your search or filters.
        </p>
        <Button variant="outline" asChild>
          <Link href="/listings">Clear Filters and Search Again</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {filteredListings.map((listing) => (
        <ListingCard key={listing.id} listing={listing} currentUserLocationQuery={currentUserLocationQuery} />
      ))}
    </div>
  );
}


export default async function ListingsPage({ searchParams: searchParamsPromise }: ListingsPageProps) {
  const searchParams = await searchParamsPromise; // Await the searchParams
  const { q, category, location, type } = searchParams;

  let filteredListings = mockListings;

  if (type) {
    filteredListings = filteredListings.filter(listing => listing.type === type);
  }

  if (q) {
    const searchTermLower = q.toLowerCase();
    filteredListings = filteredListings.filter(
      (listing) =>
        listing.name.toLowerCase().includes(searchTermLower) ||
        listing.description.toLowerCase().includes(searchTermLower) ||
        listing.category.toLowerCase().includes(searchTermLower)
    );
  }

  if (category) {
    const catDetails = getCategoryBySlug(category);
    if (catDetails) {
       filteredListings = filteredListings.filter((listing) => listing.category === catDetails.name);
    }
  }

  if (location) {
    const searchLocationLower = location.toLowerCase();
    filteredListings = filteredListings.filter((listing) =>
      listing.location.city.toLowerCase().includes(searchLocationLower) ||
      listing.location.zipCode?.toLowerCase() === searchLocationLower
    );
  }
  
  // Prioritize neighborhood professionals if a location (zip) is specified
  const userSearchZip = location ? location.toLowerCase() : undefined;
  if (userSearchZip && (type === 'professional' || !type) ) { // Prioritize if searching professionals or all
    filteredListings.sort((a, b) => {
      const aIsNeighborhoodPro = a.type === 'professional' && (a as Professional).location.zipCode?.toLowerCase() === userSearchZip;
      const bIsNeighborhoodPro = b.type === 'professional' && (b as Professional).location.zipCode?.toLowerCase() === userSearchZip;

      if (aIsNeighborhoodPro && !bIsNeighborhoodPro) return -1; // a comes first
      if (!aIsNeighborhoodPro && bIsNeighborhoodPro) return 1;  // b comes first
      
      // Optional: further sort by rating if both are/aren't neighborhood pros
      // if (a.averageRating !== b.averageRating) {
      //   return b.averageRating - a.averageRating; 
      // }
      return 0; // Keep original order or sort by other criteria
    });
  }
  
  const pageTitle = type === 'store' ? 'Stores' : type === 'professional' ? 'Professionals' : 'All Listings';
  const currentCategory = category ? getCategoryBySlug(category)?.name : null;
  const locationContext = location ? ` in ${location}` : '';

  const initialReviewDataForAI: SuggestSearchRefinementsInput['reviewData'] = filteredListings
    .flatMap(listing => listing.reviews)
    .slice(0, 20) 
    .map(review => ({ rating: review.rating, comment: review.comment }));

  const firstListingForAI = filteredListings[0];
  const initialPricingForAI = firstListingForAI?.pricing || undefined;
  const initialPopularityForAI = firstListingForAI?.popularity || undefined;
  const hasListings = filteredListings.length > 0;

  return (
    <div className="space-y-8">
      <header className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold font-headline mb-2">
          {q ? `Search Results for "${q}"` : currentCategory ? `Explore ${currentCategory}` : `Explore ${pageTitle}`}
          {locationContext}
        </h1>
        <p className="text-lg text-muted-foreground">
            {filteredListings.length > 0 
              ? `Found ${filteredListings.length} matching listings. Use the filters below or AI suggestions to refine your search.`
              : `Use the search bar to find what you're looking for.`}
        </p>
      </header>
      
      <SearchBar />
      
      <Suspense fallback={<div className="text-center p-8">Loading AI suggestions...</div>}>
        <AISearchRefinements
          initialReviewData={initialReviewDataForAI.length > 0 ? initialReviewDataForAI : undefined}
          initialPricing={initialPricingForAI}
          initialPopularity={initialPopularityForAI}
          currentSearchTerm={q}
          hasListings={hasListings}
        />
      </Suspense>

      <section>
        <Suspense fallback={<div className="text-center p-8">Loading listings...</div>}>
          <ListingsGrid 
            filteredListings={filteredListings} 
            searchTerm={q} 
            currentUserLocationQuery={userSearchZip} 
          />
        </Suspense>
      </section>
    </div>
  );
}
