
'use client';

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { ListedPartCard } from "@/components/parts/ListedPartCard";
import { PartRequestCard } from "@/components/parts/PartRequestCard";
import { mockListedParts, mockPartRequests, partCategories } from "@/data/mock";
import { PackagePlus, Search, Filter, ListChecks, UserRoundSearch, Sparkles, AlertTriangle, PackageSearch, Building2, Cog, ShieldCheck } from "lucide-react";
import Link from "next/link";
import type { Metadata } from 'next';
import { useState } from "react";

// export const metadata: Metadata = { // Cannot be used in client component
//   title: 'The Parts Mine | Local Hub',
//   description: 'Find or list spare parts. AI-powered matching for your repair needs.',
// };

const ALL_FILTER_VALUE = "_all_"; // Sentinel value for "All" options

export default function PartsMinePage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedCondition, setSelectedCondition] = useState('');
  const [selectedProvince, setSelectedProvince] = useState('');

  // Set document title on client side
  if (typeof window !== 'undefined') {
    document.title = 'The Parts Mine | Local Hub';
  }
  
  const conditionOptions: {value: string, label: string}[] = [
    { value: 'used-working', label: 'Used - Working Well' },
    { value: 'used-good', label: 'Used - Good' },
    { value: 'used-fair-needs-inspection', label: 'Used - Fair (Needs Inspection)' },
    { value: 'for-parts-experts-only', label: 'For Parts/Experts Only' },
  ];

  // Placeholder for provinces in Algeria
  const provinceOptions = [
    { value: 'sidi-bel-abbes', label: 'Sidi Bel Abbès'},
    { value: 'oran', label: 'Oran'},
    { value: 'algiers', label: 'Algiers'},
    // Add more provinces as needed
  ];

  const filteredListedParts = mockListedParts.filter(part => {
    const searchTermLower = searchTerm.toLowerCase();
    const nameMatch = part.partName.toLowerCase().includes(searchTermLower);
    const deviceMatch = part.originalDeviceName?.toLowerCase().includes(searchTermLower);
    const categoryMatch = selectedCategory ? part.categorySlug === selectedCategory : true;
    const conditionMatch = selectedCondition ? part.condition === selectedCondition : true;
    const provinceMatch = selectedProvince ? part.location?.province?.toLowerCase().replace(/\s+/g, '-') === selectedProvince : true;

    return (nameMatch || deviceMatch) && categoryMatch && conditionMatch && provinceMatch;
  });


  return (
    <div className="space-y-10">
      <header className="text-center py-10 bg-gradient-to-br from-accent/15 via-background to-primary/15 rounded-lg shadow-inner">
        <div className="inline-block p-4 bg-primary rounded-full mb-4 shadow">
            <Cog className="h-12 w-12 text-primary-foreground" />
        </div>
        <h1 className="text-4xl md:text-5xl font-bold font-headline text-primary">Welcome to The Parts Mine</h1>
        <p className="text-lg md:text-xl text-foreground mt-3 max-w-3xl mx-auto">
          Your specialized marketplace for buying and selling new & used spare parts.
          Find what you need, or list what you have!
        </p>
      </header>

      {/* Action Buttons */}
      <div className="grid md:grid-cols-2 gap-6">
        <Link href="/parts-mine/list-new" passHref>
          <Button className="w-full py-8 text-lg bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg transition-transform hover:scale-105" size="lg">
            <PackagePlus className="mr-3 h-7 w-7" /> List a Part for Sale
          </Button>
        </Link>
        <Link href="/parts-mine/request/new" passHref>
          <Button className="w-full py-8 text-lg bg-accent hover:bg-accent/90 text-accent-foreground shadow-lg transition-transform hover:scale-105" size="lg">
            <UserRoundSearch className="mr-3 h-7 w-7" /> Request a Missing Part
          </Button>
        </Link>
      </div>

      {/* Search and Filters Bar */}
      <Card className="shadow-xl border-border">
        <CardHeader>
          <CardTitle className="text-2xl flex items-center font-headline">
            <Search className="mr-3 h-6 w-6 text-primary" /> Find Spare Parts
          </CardTitle>
          <CardDescription>Search by part name, device model, or use the filters below.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Input
            type="text"
            placeholder="Search for part name, device model (e.g., Samsung S10 screen, Renault Clio headlight)..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="h-12 text-md"
          />
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <Select 
              value={selectedCategory === '' ? ALL_FILTER_VALUE : selectedCategory} 
              onValueChange={(val) => setSelectedCategory(val === ALL_FILTER_VALUE ? '' : val)}
            >
              <SelectTrigger><SelectValue placeholder="Filter by Category..." /></SelectTrigger>
              <SelectContent>
                <SelectItem value={ALL_FILTER_VALUE}>All Categories</SelectItem>
                {partCategories.map(cat => (
                  <SelectItem key={cat.slug} value={cat.slug}>
                    <div className="flex items-center">
                      <cat.icon className="mr-2 h-4 w-4 text-muted-foreground" />
                      {cat.name}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select 
              value={selectedCondition === '' ? ALL_FILTER_VALUE : selectedCondition} 
              onValueChange={(val) => setSelectedCondition(val === ALL_FILTER_VALUE ? '' : val)}
            >
              <SelectTrigger><SelectValue placeholder="Filter by Condition..." /></SelectTrigger>
              <SelectContent>
                <SelectItem value={ALL_FILTER_VALUE}>All Conditions</SelectItem>
                {conditionOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select 
              value={selectedProvince === '' ? ALL_FILTER_VALUE : selectedProvince} 
              onValueChange={(val) => setSelectedProvince(val === ALL_FILTER_VALUE ? '' : val)}
            >
              <SelectTrigger><SelectValue placeholder="Filter by Province..." /></SelectTrigger>
              <SelectContent>
                <SelectItem value={ALL_FILTER_VALUE}>All Provinces</SelectItem>
                {provinceOptions.map(opt => <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
           <p className="text-xs text-muted-foreground">Advanced filters for brand and price range coming soon.</p>
        </CardContent>
      </Card>
      
      {/* Recently Listed Parts */}
      <section>
        <h2 className="text-3xl font-semibold font-headline mb-6 flex items-center">
          <ListChecks className="mr-3 h-7 w-7 text-primary" /> Recently Listed Parts
        </h2>
        {filteredListedParts.length > 0 ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filteredListedParts.map(part => (
              <ListedPartCard key={part.id} part={part} />
            ))}
          </div>
        ) : (
          <Card className="py-8 text-center bg-muted/50 border-dashed">
            <CardContent>
              <PackageSearch className="mx-auto h-12 w-12 text-muted-foreground mb-3" />
              <p className="text-muted-foreground">No parts match your current search/filters.</p>
              <p className="text-sm text-muted-foreground">Try adjusting your search or view all available parts.</p>
            </CardContent>
          </Card>
        )}
      </section>

      <Separator className="my-10"/>

      {/* AI-Powered Suggestions Placeholder */}
      <Card className="bg-accent/10 border-accent/30 shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl font-headline flex items-center">
            <Sparkles className="mr-3 h-6 w-6 text-accent" /> AI-Powered Discovery
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-foreground mb-2">
            Our AI helps you find what you need! 
          </p>
          <ul className="list-disc list-inside text-sm space-y-1">
            <li><strong className="text-accent">Smart Request Matching:</strong> When you request a part, our AI searches listings and notifies you of matches. Sellers may also be notified of your need.</li>
            <li><strong className="text-accent">Enhanced Search (Coming Soon):</strong> AI will suggest compatible or alternative parts and show listings based on your service history.</li>
          </ul>
          <div className="mt-4 p-3 bg-background/50 rounded-md border border-dashed">
            <p className="font-medium text-sm">Example AI Suggestion (Conceptual):</p>
            <p className="text-xs text-muted-foreground">"We noticed you recently requested a refrigerator technician. You might be interested in these common refrigerator parts: [Compressor Relay Listing], [Evaporator Fan Motor Listing]."</p>
          </div>
        </CardContent>
      </Card>

      <Separator className="my-10"/>
      
      {/* Active User Requests */}
      {mockPartRequests.length > 0 && (
        <section>
          <h2 className="text-3xl font-semibold font-headline mb-6 flex items-center">
            <UserRoundSearch className="mr-3 h-7 w-7 text-primary" /> My Active Part Requests
          </h2>
          <div className="grid gap-6 sm:grid-cols-1 md:grid-cols-2">
            {mockPartRequests.map(req => (
              <PartRequestCard key={req.id} request={req} />
            ))}
          </div>
        </section>
      )}
      
      <Separator className="my-10"/>

      {/* Secure Transactions Info */}
      <Card className="bg-blue-50 border-blue-200 text-blue-800 shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl font-headline flex items-center">
            <ShieldCheck className="mr-3 h-6 w-6 text-blue-600" /> Secure Transactions
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
            <p>
                All transactions within The Parts Mine are designed with your security in mind.
            </p>
            <ul className="list-disc list-inside space-y-1">
                <li><strong className="font-medium">In-App Communication:</strong> Chat securely with sellers/buyers to discuss details and arrange delivery (Chat feature coming soon).</li>
                <li><strong className="font-medium">Escrow Wallet Protection:</strong> Payments are processed exclusively through Local Hub's Escrow Wallet. Funds are held securely until you confirm the item is received as described.</li>
                <li><strong className="font-medium">Dispute Resolution:</strong> A simple mechanism for dispute resolution will be available to help with any issues (Coming soon).</li>
            </ul>
        </CardContent>
      </Card>
    </div>
  );
}

