
'use client';

import { useState, useEffect, type FormEvent } from 'react'; 
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Input } from '@/components/ui/input';
import { Label } from "@/components/ui/label";
import { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from "@/components/ui/dialog"; 
import { TopUpDialog } from "@/components/profile/TopUpDialog";
import { Badge } from "@/components/ui/badge";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"; 
import { Textarea } from "@/components/ui/textarea"; 

import { ShieldCheck, UserCircle, Edit3, Wallet, Landmark, CheckCircle, DollarSign, Gift, HeartHandshake, Briefcase, Warehouse, Sparkles as AiSparklesIcon, Cog, CreditCard, Truck, Link2, Link2Off, PhoneCall, CircleDollarSign, Package, History, MessageSquare, Lightbulb, UserRoundSearch, Loader2, ShoppingCart, CalendarDays, TicketIcon, Building2, BarChart3, LayoutDashboard, PlusCircle } from "lucide-react"; 
import Link from "next/link";
import type { UserProfileData, OngoingService, TopUpTransaction, LinkedAccountData, AssistantSuggestion, StoreSubscriptionPlan, Store, ProductItem, Appointment } from '@/types';
import { useToast } from "@/hooks/use-toast";
import { format, isToday, parseISO, formatDistanceToNow } from 'date-fns';
import { getProactiveSuggestions, type ProactiveAssistantInput } from '@/ai/flows/proactive-assistant-flow';
import * as LucideIcons from 'lucide-react';
import { mockListings, categories as allCategories, mockUserProfile as initialMockUserProfile } from '@/data/mock';

// Helper component to format date client-side
const FormattedServiceDate = ({ dateString }: { dateString: string }) => {
  const [formattedDate, setFormattedDate] = useState<string | null>(null);

  useEffect(() => {
    try {
      setFormattedDate(new Date(dateString).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' }));
    } catch (error) {
      console.error("Error formatting service date:", error);
      setFormattedDate("Invalid date");
    }
  }, [dateString]);

  return <>{formattedDate === null ? "Loading..." : formattedDate}</>;
};

const ClientFormattedDateTime = ({ dateString }: { dateString: string }) => {
  const [displayText, setDisplayText] = useState<string>("Processing date...");

  useEffect(() => {
    try {
      setDisplayText(format(new Date(dateString), "PPP p"));
    } catch (error) {
      console.error("Error formatting date-time:", error);
      setDisplayText("Invalid date-time");
    }
  }, [dateString]);

  return <>{displayText}</>;
};

const DynamicLucideIcon = ({ name, ...props }: { name?: keyof typeof LucideIcons } & LucideIcons.LucideProps) => {
  if (!name || !LucideIcons[name]) {
    return <Lightbulb {...props} />;
  }
  const IconComponent = LucideIcons[name] as LucideIcons.LucideIcon;
  return <IconComponent {...props} />;
};


export default function ProfilePage() {
  const { toast } = useToast();
  const [isTopUpDialogOpen, setIsTopUpDialogOpen] = useState(false);
  const [assistantSuggestions, setAssistantSuggestions] = useState<AssistantSuggestion[]>([]);
  const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(true);
  const [approvingTransactionId, setApprovingTransactionId] = useState<string | null>(null);
  
  const [isDigitalProjectsDialogOpen, setIsDigitalProjectsDialogOpen] = useState(false);
  const [user, setUser] = useState<UserProfileData>(initialMockUserProfile); 

  useEffect(() => {
    document.title = 'My Profile | Khidmatik';

    const fetchSuggestions = async () => {
      setIsLoadingSuggestions(true);
      try {
        const input: ProactiveAssistantInput = { userId: user.id, currentDate: new Date().toISOString().split('T')[0] };
        const result = await getProactiveSuggestions(input);
        setAssistantSuggestions(result.suggestions);
      } catch (error) {
        console.error("Error fetching proactive suggestions:", error);
        toast({ title: "Assistant Error", description: "Could not fetch suggestions.", variant: "destructive" });
      } finally {
        setIsLoadingSuggestions(false);
      }
    };

    if (user.id) fetchSuggestions();
  }, [user.id, toast]);


  const handleTopUpSuccess = (newTransaction: TopUpTransaction) => {
    setUser(prevUser => ({
      ...prevUser,
      topUpHistory: [...(prevUser.topUpHistory || []), newTransaction],
    }));
  };

  const simulateAdminApproval = async (transactionId: string) => {
    setApprovingTransactionId(transactionId);
    await new Promise(resolve => setTimeout(resolve, 300)); 

    const transaction = user.topUpHistory?.find(t => t.id === transactionId);
    if (!transaction || transaction.status !== 'pending-review') {
        setApprovingTransactionId(null);
        return;
    }

    const pointsEarned = Math.floor(transaction.amount / 10);
    setUser(prevUser => ({
      ...prevUser,
      walletBalance: prevUser.walletBalance + transaction.amount,
      loyaltyPoints: (prevUser.loyaltyPoints || 0) + pointsEarned,
      topUpHistory: prevUser.topUpHistory?.map(t =>
        t.id === transactionId ? { ...t, status: 'approved', processedAt: new Date().toISOString() } : t
      ),
    }));

    toast({
      title: "Top-up Approved!",
      description: `${transaction.amount.toFixed(2)} DA added. ${pointsEarned} points earned.`,
      duration: 4000,
    });
    setApprovingTransactionId(null);
  };

  const handleCompleteService = async (serviceId: string) => {
    const service = user.ongoingServices.find(s => s.id === serviceId);
    if (!service) return;
    
    await new Promise(resolve => setTimeout(resolve, 200));

    setUser(prevUser => ({
      ...prevUser,
      ongoingServices: prevUser.ongoingServices.filter(s => s.id !== serviceId),
      loyaltyPoints: (prevUser.loyaltyPoints || 0) + 50, 
    }));

    toast({
      title: "Service Completed!",
      description: `Funds for "${service.serviceName}" released. You and the provider have been notified. 50 loyalty points earned!`,
    });
  };

  const handleRedeemPoints = async (description: string) => {
    await new Promise(resolve => setTimeout(resolve, 200));
    toast({ title: "Points Redemption (Conceptual)", description: `Redeemed: ${description}.` });
  };

  const handleLinkAccount = async (platform: LinkedAccountData['platform']) => {
    await new Promise(resolve => setTimeout(resolve, 200));
    toast({ title: `Link ${platform} Account (Conceptual)`, description: `Initiating link for ${platform}.`});
    setUser(prev => ({ ...prev, linkedAccounts: prev.linkedAccounts?.map(acc => acc.platform === platform ? {...acc, isLinked: true, identifier: platform === 'Phone' ? 'New Linked Phone' : `linked@${platform.toLowerCase()}.com`} : acc) }));
  };

  const handleUnlinkAccount = async (platform: LinkedAccountData['platform']) => {
    await new Promise(resolve => setTimeout(resolve, 200));
    const linkedCount = user.linkedAccounts?.filter(acc => acc.isLinked).length || 0;
    if (linkedCount <= 1 && user.linkedAccounts?.find(acc => acc.platform === platform && acc.isLinked)) {
        toast({ title: `Cannot Unlink`, description: `Must have at least one login method.`, variant: "destructive" }); return;
    }
    toast({ title: `Unlink ${platform} (Conceptual)`, description: `Unlinking ${platform}.`, variant: "destructive" });
    setUser(prev => ({ ...prev, linkedAccounts: prev.linkedAccounts?.map(acc => acc.platform === platform ? {...acc, isLinked: false, identifier: 'Not Linked'} : acc)}));
  };

  const handleSuggestionAction = (suggestion: AssistantSuggestion) => {
    if (suggestion.actionLink && suggestion.actionType === 'navigate') {
      window.location.href = suggestion.actionLink;
    } else {
      toast({ title: "Assistant Action (Conceptual)", description: suggestion.actionText || suggestion.title });
    }
  };

  const handleViewAppointmentTicket = (reservationId: string) => {
    toast({
        title: "View Ticket (Conceptual)",
        description: `Ticket details for Reservation ID: ${reservationId} would be displayed here. PDF download option coming soon.`,
        duration: 5000,
    });
  };


  return (
    <div className="max-w-3xl mx-auto space-y-8">
      <header className="flex items-center justify-between">
        <h1 className="text-3xl font-bold font-headline">My Profile</h1>
        <Button variant="outline" size="sm" disabled>
          <Edit3 className="mr-2 h-4 w-4" /> Edit Profile (Soon)
        </Button>
      </header>

      <Card className="shadow-lg">
        <CardHeader className="flex flex-col sm:flex-row items-center gap-4 p-6 bg-muted/30">
          <Avatar className="h-24 w-24 border-2 border-primary">
            <AvatarImage src={user.avatarUrl} alt={user.name} />
            <AvatarFallback>{user.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
          </Avatar>
          <div className="text-center sm:text-left">
            <CardTitle className="text-2xl">{user.name}</CardTitle>
            <CardDescription className="text-muted-foreground">{user.email}</CardDescription>
            <p className="text-sm text-muted-foreground mt-1">Member since: {user.memberSince}</p>
            <p className="text-xs text-muted-foreground mt-0.5">User ID: {user.id}</p>
          </div>
        </CardHeader>
        <CardContent className="p-6 space-y-6">
          <div>
            <h3 className="font-semibold text-lg mb-2 flex items-center">
              <UserCircle className="mr-2 h-5 w-5 text-primary" /> Account Status
            </h3>
            {user.isVerified ? (
              <div className="flex items-center text-green-600 bg-green-50 p-3 rounded-md border border-green-200">
                <ShieldCheck className="mr-2 h-5 w-5" />
                <span>ID Verified - Your account is trusted and secure.</span>
              </div>
            ) : (
              <div className="flex items-center text-orange-600 bg-orange-50 p-3 rounded-md border border-orange-200">
                <ShieldCheck className="mr-2 h-5 w-5" />
                <span>ID Verification Pending - <Link href="/register-provider" className="underline hover:text-primary">Complete verification</Link></span>
              </div>
            )}
          </div>

          <Separator />

          <Card>
            <CardHeader>
                <CardTitle className="text-xl font-semibold flex items-center">
                    <AiSparklesIcon className="mr-2 h-6 w-6 text-primary" /> Khidmatik Assistant
                </CardTitle>
                <CardDescription>Personalized tips and reminders just for you.</CardDescription>
            </CardHeader>
            <CardContent>
                {isLoadingSuggestions ? (
                    <div className="space-y-3">
                        {[1, 2].map(i => (
                            <div key={i} className="flex items-start space-x-3 p-3 border rounded-md bg-muted/20">
                                <Loader2 className="h-6 w-6 text-primary animate-spin mt-1" />
                                <div className="flex-1 space-y-1">
                                    <div className="h-4 bg-muted rounded w-3/4"></div>
                                    <div className="h-3 bg-muted rounded w-full"></div>
                                    <div className="h-3 bg-muted rounded w-1/2"></div>
                                </div>
                            </div>
                        ))}
                    </div>
                ) : assistantSuggestions.length > 0 ? (
                    <div className="space-y-4">
                        {assistantSuggestions.map(suggestion => (
                            <div key={suggestion.id} className="p-4 border rounded-lg shadow-sm bg-card hover:shadow-md transition-shadow">
                                <div className="flex items-start gap-3 mb-2">
                                    <DynamicLucideIcon name={suggestion.iconName as keyof typeof LucideIcons} className="h-7 w-7 text-accent mt-1" />
                                    <div>
                                        <h4 className="font-semibold text-md">{suggestion.title}</h4>
                                        <p className="text-sm text-muted-foreground">{suggestion.message}</p>
                                    </div>
                                </div>
                                {suggestion.actionText && (
                                    <Button 
                                        variant="default" 
                                        size="sm" 
                                        className="w-full mt-3 bg-primary hover:bg-primary/90 text-primary-foreground"
                                        onClick={() => handleSuggestionAction(suggestion)}
                                    >
                                        {suggestion.actionText}
                                    </Button>
                                )}
                            </div>
                        ))}
                    </div>
                ) : (
                    <p className="text-sm text-muted-foreground text-center py-4">
                        Your assistant is learning your preferences. Check back later for personalized tips!
                    </p>
                )}
            </CardContent>
          </Card>

          <Separator />
          
          {user.appointments && user.appointments.length > 0 && (
            <Card>
                <CardHeader>
                    <CardTitle className="text-xl font-semibold flex items-center">
                        <CalendarDays className="mr-2 h-5 w-5 text-primary" /> My Appointments
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                    {user.appointments.map(appt => {
                        const appointmentDate = parseISO(appt.date);
                        const isAppointmentToday = isToday(appointmentDate);
                        let statusVariant: "default" | "secondary" | "destructive" | "outline" = "secondary";
                        if (appt.status === 'confirmed') statusVariant = 'default'; 
                        if (appt.status === 'pending_confirmation') statusVariant = 'secondary'; 
                        if (appt.status === 'cancelled') statusVariant = 'destructive';
                        if (appt.status === 'completed') statusVariant = 'outline';


                        return (
                            <div key={appt.reservationId} className={`p-3 border rounded-md ${isAppointmentToday && appt.status !== 'completed' && appt.status !== 'cancelled' ? 'bg-accent/20 border-accent shadow-lg' : 'bg-muted/50'}`}>
                                <div className="flex flex-col sm:flex-row justify-between items-start">
                                    <div className="mb-2 sm:mb-0">
                                        <p className="font-semibold text-md">{appt.professionalName} 
                                            {appt.professionalCategory && <span className="text-xs text-muted-foreground"> ({appt.professionalCategory})</span>}
                                        </p>
                                        <p className="text-sm">
                                            <span className="font-medium">Date:</span> {format(appointmentDate, "PPP")} 
                                            {appt.timeSlot && <span className="text-xs text-muted-foreground"> ({appt.timeSlot})</span>}
                                        </p>
                                        <p className="text-xs text-muted-foreground">Ref ID: {appt.reservationId}</p>
                                    </div>
                                    <Badge variant={statusVariant} className={appt.status === 'confirmed' ? 'bg-green-500 text-white' : ''}>
                                        {appt.status.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                                    </Badge>
                                </div>
                                {appt.reasonForVisit && <p className="text-xs mt-1">Reason: {appt.reasonForVisit}</p>}
                                {isAppointmentToday && appt.status === 'confirmed' && (
                                    <p className="text-xs font-bold text-primary mt-1">APPOINTMENT TODAY!</p>
                                )}
                                <Button variant="link" size="sm" className="p-0 h-auto mt-2 text-xs" onClick={() => handleViewAppointmentTicket(appt.reservationId)}>
                                    <TicketIcon className="mr-1 h-3 w-3" /> View Ticket (Conceptual)
                                </Button>
                            </div>
                        );
                    })}
                </CardContent>
            </Card>
          )}


          <Separator />

          <Card>
            <CardHeader>
              <CardTitle className="text-xl font-semibold flex items-center">
                <Cog className="mr-2 h-6 w-6 text-primary" /> Account & Security
              </CardTitle>
              <CardDescription>Manage your login methods and security settings.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <h4 className="font-medium text-muted-foreground mb-2">Linked Login Methods:</h4>
              {user.linkedAccounts?.map(account => {
                const AccountIcon = account.icon;
                return (
                  <div key={account.platform} className="flex items-center justify-between p-3 border rounded-md bg-muted/20">
                    <div className="flex items-center gap-3">
                      <AccountIcon className="h-5 w-5" />
                      <div>
                        <p className="font-medium">{account.platform}</p>
                        <p className={`text-xs ${account.isLinked ? 'text-green-600' : 'text-muted-foreground'}`}>
                          {account.isLinked ? `Linked: ${account.identifier}` : 'Not Linked'}
                        </p>
                      </div>
                    </div>
                    {account.isLinked ? (
                      <Button variant="link" size="sm" onClick={() => handleUnlinkAccount(account.platform)} className="text-destructive hover:text-destructive/80 text-xs">
                        <Link2Off className="mr-1 h-3 w-3"/> Unlink
                      </Button>
                    ) : (
                      <Button variant="link" size="sm" onClick={() => handleLinkAccount(account.platform)} className="text-primary text-xs">
                        <Link2 className="mr-1 h-3 w-3"/> Link Account
                      </Button>
                    )}
                  </div>
                );
              })}
              <p className="text-xs text-muted-foreground">
                Smart account unification will try to link accounts automatically if the same email is detected.
                You need at least one login method linked.
              </p>
               <Button variant="outline" size="sm" className="w-full mt-2" disabled>Change Password (Placeholder)</Button>
            </CardContent>
          </Card>

          <Separator />

          <Card>
            <CardHeader>
              <CardTitle className="text-xl font-semibold flex items-center">
                <Wallet className="mr-2 h-6 w-6 text-primary" /> My Escrow Wallet
              </CardTitle>
              <CardDescription>All payments for products and services on Khidmatik are securely processed here.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-3xl font-bold text-center">
                {user.walletBalance.toFixed(2)} <span className="text-lg font-normal text-muted-foreground">DA</span>
              </div>
              <Dialog open={isTopUpDialogOpen} onOpenChange={setIsTopUpDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground">
                    <CircleDollarSign className="mr-2 h-4 w-4" /> Top Up Balance
                  </Button>
                </DialogTrigger>
                <TopUpDialog
                    currentBalance={user.walletBalance}
                    onClose={() => setIsTopUpDialogOpen(false)}
                    onTopUpSuccess={handleTopUpSuccess}
                />
              </Dialog>
            </CardContent>
          </Card>

           {user.topUpHistory && user.topUpHistory.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-xl font-semibold flex items-center">
                  <History className="mr-2 h-5 w-5 text-primary" /> Top-up History
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {user.topUpHistory.map(transaction => (
                  <div key={transaction.id} className="p-3 border rounded-md bg-muted/50 text-sm">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">{transaction.amount.toFixed(2)} DA - <span className="text-xs text-muted-foreground">via {transaction.method.toUpperCase()}</span></p>
                        <p className="text-xs text-muted-foreground">Ref: {transaction.transactionCode}</p>
                        <p className="text-xs text-muted-foreground">Date: <ClientFormattedDateTime dateString={transaction.createdAt} /></p>
                      </div>
                      <Badge variant={transaction.status === 'approved' ? 'default' : transaction.status === 'pending-review' ? 'secondary' : 'destructive'}
                             className={transaction.status === 'approved' ? 'bg-green-500' : transaction.status === 'pending-review' ? 'bg-yellow-500' : ''}
                      >
                        {transaction.status.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                      </Badge>
                    </div>
                    {transaction.status === 'pending-review' && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => simulateAdminApproval(transaction.id)}
                        className="mt-2 w-full border-primary text-primary hover:bg-primary/10"
                        disabled={approvingTransactionId === transaction.id}
                      >
                        {approvingTransactionId === transaction.id ? (
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" /> 
                        ) : <CheckCircle className="mr-2 h-4 w-4" /> }
                        Simulate Admin Approval
                      </Button>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          <Separator />

          {user.loyaltyPoints !== undefined && (
            <Card>
              <CardHeader>
                <CardTitle className="text-xl font-semibold flex items-center">
                  <Gift className="mr-2 h-6 w-6 text-primary" /> My Loyalty Points (نقاطي)
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-3xl font-bold text-center text-primary">
                  {user.loyaltyPoints} <span className="text-lg font-normal text-muted-foreground">points</span>
                </div>
                <div>
                  <h4 className="font-medium mb-1 text-muted-foreground">How to Earn Points:</h4>
                  <ul className="list-disc list-inside text-sm space-y-1">
                    <li>Leave a helpful review (earn 25 points)</li>
                    <li>Invite a friend (earn 100 points)</li>
                    <li>Complete a service/order (earn points based on amount spent)</li>
                    <li>Top-up your wallet (e.g., 1 point per 10 DA)</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium mb-2 text-muted-foreground">Redeem Your Points:</h4>
                  <div className="space-y-2">
                    <Button variant="outline" className="w-full justify-start" onClick={() => handleRedeemPoints("500 DA off next service")} disabled>
                      500 DA off next service (500 points)
                    </Button>
                    <Button variant="outline" className="w-full justify-start" onClick={() => handleRedeemPoints("Free delivery")} disabled>
                      Free delivery on next order (300 points)
                    </Button>
                     <Button variant="outline" className="w-full justify-start items-center" onClick={() => handleRedeemPoints("Donate 200 points to charity")} disabled>
                        <HeartHandshake className="mr-2 h-4 w-4 text-red-500" />
                        Donate 200 points to 'Sidi Bel Abbès Charity'
                    </Button>
                    <p className="text-xs text-muted-foreground text-center">Partnering with local charities to give back to our community.</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <Separator />

          {user.ongoingServices.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-xl font-semibold">Ongoing Physical Services</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {user.ongoingServices.map(service => (
                  <div key={service.id} className="p-3 border rounded-md bg-muted/50">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-semibold">{service.serviceName}</p>
                        <p className="text-sm text-muted-foreground">With: {service.providerName}</p>
                        <p className="text-sm text-muted-foreground">Booked: <FormattedServiceDate dateString={service.dateBooked} /></p>
                      </div>
                       <div className="text-right">
                        <p className="font-semibold text-primary">{service.amountInEscrow.toFixed(2)} DA</p>
                         <p className="text-xs text-muted-foreground">In Escrow</p>
                       </div>
                    </div>
                    <Button
                      onClick={() => handleCompleteService(service.id)}
                      className="w-full mt-3"
                      variant="default"
                      size="sm"
                    >
                      <CheckCircle className="mr-2 h-4 w-4" /> Complete and Accept Service
                    </Button>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          <Separator />

          {(user.isStoreOwner || user.isFreelancer) && (
            <Card>
              <CardHeader>
                <CardTitle className="text-xl font-semibold flex items-center">
                    <LayoutDashboard className="mr-2 h-5 w-5 text-primary"/> My Dashboard
                </CardTitle>
                <CardDescription>Access tools to manage your business operations.</CardDescription>
              </CardHeader>
              <CardContent className="grid grid-cols-1 gap-4">
                {user.isStoreOwner && user.storeId && (
                  <Button asChild variant="default" className="w-full justify-start text-left h-auto py-3 bg-primary hover:bg-primary/90 text-primary-foreground">
                      <Link href="/dashboard/store">
                        <Warehouse className="mr-3 h-5 w-5" />
                        <div>
                          <span className="font-semibold">Go to My Store Dashboard</span><br/>
                          <span className="text-xs opacity-90">Manage products, orders, analytics & more.</span>
                        </div>
                      </Link>
                  </Button>
                )}
                {user.isFreelancer && (
                   <Dialog open={isDigitalProjectsDialogOpen} onOpenChange={setIsDigitalProjectsDialogOpen}>
                        <DialogTrigger asChild>
                            <Button variant="outline" className="w-full justify-start text-left h-auto py-3">
                                <Briefcase className="mr-3 h-5 w-5 text-primary" />
                                <div>
                                    <span className="font-semibold">Manage Digital Projects</span><br/>
                                    <span className="text-xs text-muted-foreground">Track milestones, chat with clients.</span>
                                </div>
                            </Button>
                        </DialogTrigger>
                        <DialogContent>
                             <DialogHeader>
                                <DialogTitle>Manage Digital Service Projects</DialogTitle>
                                <DialogDescription>Oversee your ongoing freelance projects.</DialogDescription>
                            </DialogHeader>
                            <div className="py-4 space-y-3 max-h-[60vh] overflow-y-auto">
                                {user.digitalProjects && user.digitalProjects.length > 0 ? user.digitalProjects.map(proj => (
                                    <Card key={proj.id} className="p-3">
                                        <div className="flex justify-between items-center">
                                            <p className="font-medium">{proj.name}</p>
                                            <Badge variant={proj.status === 'In Progress' ? 'secondary' : 'default'}>{proj.status}</Badge>
                                        </div>
                                        <Button variant="link" size="sm" className="p-0 h-auto mt-1" onClick={()=>toast({title: `Viewing ${proj.name} (Conceptual)`})}>View Details</Button>
                                    </Card>
                                )) : <p className="text-sm text-muted-foreground">No active digital projects.</p>}
                            </div>
                            <DialogFooter>
                                <Button variant="outline" onClick={()=>toast({title: "Creating New Proposal (Conceptual)"})}>Create New Proposal</Button>
                                <DialogClose asChild><Button>Close</Button></DialogClose>
                            </DialogFooter>
                        </DialogContent>
                   </Dialog>
                )}
                 <Button asChild variant="outline" className="w-full justify-start text-left h-auto py-3">
                    <Link href="/register-provider">
                        <PlusCircle className="mr-3 h-5 w-5 text-primary"/>
                        <div>
                          <span className="font-semibold">Create New Listing</span><br/>
                          <span className="text-xs text-muted-foreground">List another store or professional service.</span>
                        </div>
                    </Link>
                 </Button>
              </CardContent>
            </Card>
          )}
          
          {!user.isStoreOwner && !user.isFreelancer && (
             <div className="text-center py-4">
                <Link href="/register-provider">
                  <Button variant="default" className="w-auto bg-accent hover:bg-accent/80 text-accent-foreground">
                    + Become a Seller/Provider on Khidmatik
                  </Button>
                </Link>
             </div>
          )}


        </CardContent>
      </Card>
       <div className="text-center mt-6">
            <Button variant="destructive" disabled>Log Out (Placeholder)</Button>
       </div>
    </div>
  );
}
