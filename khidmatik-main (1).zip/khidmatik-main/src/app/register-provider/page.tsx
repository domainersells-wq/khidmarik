
'use client';

import { useState, type FormEvent, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { AlertCircle, UploadCloud, Briefcase, Store, Sparkles, Loader2, UserCheck, Users, CheckCircle, DollarSign, FileUp, BadgeCheck } from "lucide-react"; // Added FileUp, BadgeCheck
import Link from "next/link";
import { useToast } from "@/hooks/use-toast";
import { generateListingDescription, type GenerateListingDescriptionInput } from '@/ai/flows/generate-listing-description-flow';
import { categories as allCategories } from '@/data/mock';
import type { StoreSubscriptionPlan } from '@/types';

const categoriesRequiringSponsorship: string[] = ['plumbers', 'electricians', 'doctors'];

const subscriptionPlans = [
  {
    id: 'basic' as StoreSubscriptionPlan,
    name: 'Basic Plan',
    price: '1500 DA/month',
    features: ['List up to 20 products', 'Standard Storefront', 'Basic Analytics'],
    icon: Briefcase,
  },
  {
    id: 'pro' as StoreSubscriptionPlan,
    name: 'Pro Plan',
    price: '4500 DA/month',
    features: ['Unlimited Products', 'Customizable Storefront', 'Advanced Marketing Tools', 'Priority Support'],
    icon: Sparkles,
  }
];

export default function RegisterProviderPage() {
  const { toast } = useToast();

  const [contactName, setContactName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [listingType, setListingType] = useState<'store' | 'professional' | ''>('');
  const [businessName, setBusinessName] = useState('');
  const [categoryInput, setCategoryInput] = useState('');
  const [descriptionKeywords, setDescriptionKeywords] = useState('');
  const [listingDescription, setListingDescription] = useState('');
  const [selectedPlan, setSelectedPlan] = useState<StoreSubscriptionPlan | ''>('');
  const [sponsor1Id, setSponsor1Id] = useState('');
  const [sponsor2Id, setSponsor2Id] = useState('');

  const [idCardFile, setIdCardFile] = useState<File | null>(null);
  const [commercialRegisterFile, setCommercialRegisterFile] = useState<File | null>(null);


  const [isGeneratingDescription, setIsGeneratingDescription] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);


  useEffect(() => {
    document.title = 'Register Your Business or Profession | Khidmatik';
  }, []);


  const handleGenerateDescription = async () => {
    if (!businessName || !listingType || !categoryInput || !descriptionKeywords) {
      toast({
        title: "Missing Information",
        description: "Please fill in Business Name, Listing Type, Category, and Keywords before generating a description.",
        variant: "destructive",
      });
      return;
    }
    setIsGeneratingDescription(true);
    setListingDescription('');
    try {
      const input: GenerateListingDescriptionInput = { businessName, listingType, category: categoryInput, keywords: descriptionKeywords };
      const result = await generateListingDescription(input);
      setListingDescription(result.generatedDescription);
      toast({ title: "Description Generated!", description: "AI drafted a description." });
    } catch (error) {
      console.error("Error generating listing description:", error);
      toast({ title: "Error Generating Description", description: "Could not generate. Please try again or write your own.", variant: "destructive" });
    } finally {
      setIsGeneratingDescription(false);
    }
  };

  const validateForm = () => {
    if (!contactName.trim()) { toast({ title: "Validation Error", description: "Contact name is required.", variant: "destructive" }); return false; }
    if (!email.trim() || !/\S+@\S+\.\S+/.test(email)) { toast({ title: "Validation Error", description: "Valid email is required.", variant: "destructive" }); return false; }
    if (password.length < 6) { toast({ title: "Validation Error", description: "Password must be at least 6 characters.", variant: "destructive" }); return false; }
    if (password !== confirmPassword) { toast({ title: "Validation Error", description: "Passwords do not match.", variant: "destructive" }); return false; }
    if (!listingType) { toast({ title: "Validation Error", description: "Please select a listing type.", variant: "destructive" }); return false; }
    if (!businessName.trim()) { toast({ title: "Validation Error", description: "Business/Profession name is required.", variant: "destructive" }); return false; }
    if (!categoryInput.trim()) { toast({ title: "Validation Error", description: "Category is required.", variant: "destructive" }); return false; }
    if (!listingDescription.trim()) { toast({ title: "Validation Error", description: "Listing description is required.", variant: "destructive" }); return false; }
    if (listingType === 'store' && !selectedPlan) { toast({ title: "Validation Error", description: "Please select a store subscription plan.", variant: "destructive" }); return false; }
    
    // Conceptual validation for file uploads
    if (!idCardFile) { toast({ title: "Validation Error", description: "ID Card is required for verification.", variant: "destructive"}); return false; }
    if (listingType === 'store' && !commercialRegisterFile) { toast({ title: "Validation Error", description: "Commercial Register is required for store verification.", variant: "destructive"}); return false; }


    const selectedCategoryObject = allCategories.find(cat => cat.name.toLowerCase() === categoryInput.toLowerCase());
    const currentCategorySlug = selectedCategoryObject?.slug;
    const needsSponsorship = listingType === 'professional' && currentCategorySlug && categoriesRequiringSponsorship.includes(currentCategorySlug);
    if (needsSponsorship && (!sponsor1Id.trim() || !sponsor2Id.trim())) { toast({ title: "Validation Error", description: "Sponsor IDs are required for this category.", variant: "destructive" }); return false; }
    return true;
  };

  const resetForm = () => {
    setContactName(''); setEmail(''); setPassword(''); setConfirmPassword(''); setListingType('');
    setBusinessName(''); setCategoryInput(''); setDescriptionKeywords(''); setListingDescription('');
    setSelectedPlan(''); setSponsor1Id(''); setSponsor2Id('');
    setIdCardFile(null); setCommercialRegisterFile(null);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, setFileState: React.Dispatch<React.SetStateAction<File | null>>, documentType: string) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const allowedTypes = ['application/pdf', 'image/jpeg', 'image/jpg'];
      const maxSizeMB = 5;
      if (!allowedTypes.includes(file.type)) {
        toast({ title: "Invalid File Type", description: `Please upload a PDF or JPG for ${documentType}.`, variant: "destructive" });
        return;
      }
      if (file.size > maxSizeMB * 1024 * 1024) {
        toast({ title: "File Too Large", description: `${documentType} must be less than ${maxSizeMB}MB.`, variant: "destructive" });
        return;
      }
      setFileState(file);
      toast({ title: `${documentType} Selected`, description: `${file.name} (${(file.size / 1024).toFixed(1)}KB) ready for upload.`, variant: "default" });
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsSubmitting(true);
    await new Promise(resolve => setTimeout(resolve, 300));

    const formData = { contactName, email, listingType, businessName, categoryInput, listingDescription, descriptionKeywords, selectedPlan, sponsor1Id, sponsor2Id, idCardFileName: idCardFile?.name, commercialRegisterFileName: commercialRegisterFile?.name };
    console.log("Provider Registration Submitted (Conceptual):", formData);
    // In a real app, you'd upload idCardFile and commercialRegisterFile here to Firebase Storage.
    toast({
      title: "Registration Submitted!",
      description: "Your application and documents are pending verification. You'll be notified within 24-48 hours.",
      duration: 5000,
    });
    resetForm();
    setIsSubmitting(false);
  };

  const selectedCategoryObject = allCategories.find(cat => cat.name.toLowerCase() === categoryInput.toLowerCase());
  const currentCategorySlug = selectedCategoryObject?.slug;
  const showSponsorshipSection = listingType === 'professional' && currentCategorySlug && categoriesRequiringSponsorship.includes(currentCategorySlug);

  return (
    <div className="flex justify-center items-start py-8">
      <Card className="w-full max-w-lg shadow-xl">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-headline">List Your Service on Khidmatik</CardTitle>
          <CardDescription>Register to list your store or professional service. Document verification and potential sponsorship are required to ensure a trusted platform.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="contactName">Your Full Name (or Business Contact Person) *</Label>
              <Input id="contactName" type="text" placeholder="John Doe" required value={contactName} onChange={(e) => setContactName(e.target.value)} />
            </div>
            <div>
              <Label htmlFor="email">Email Address *</Label>
              <Input id="email" type="email" placeholder="you@example.com" required value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
            <div>
              <Label htmlFor="password">Password (min. 6 characters) *</Label>
              <Input id="password" type="password" placeholder="••••••••" required value={password} onChange={(e) => setPassword(e.target.value)} />
            </div>
            <div>
              <Label htmlFor="confirmPassword">Confirm Password *</Label>
              <Input id="confirmPassword" type="password" placeholder="••••••••" required value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />
            </div>

            <Separator className="my-6" />

            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Business/Profession Details</h3>
              <div>
                <Label htmlFor="listingType">I am registering a: *</Label>
                <Select value={listingType} onValueChange={(value: 'store' | 'professional' | '') => setListingType(value)} required>
                  <SelectTrigger id="listingType" className="mt-1"><SelectValue placeholder="Select type..." /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="store"><Store className="mr-2 h-4 w-4 inline-block" /> Store / Shop</SelectItem>
                    <SelectItem value="professional"><Briefcase className="mr-2 h-4 w-4 inline-block" /> Professional Service / Craft</SelectItem>
                  </SelectContent>
                </Select>
              </div>
               <div>
                <Label htmlFor="businessName">Business/Profession Name *</Label>
                <Input id="businessName" type="text" placeholder="e.g., Springfield Bakery or John Doe Plumbing" value={businessName} onChange={(e) => setBusinessName(e.target.value)} required />
              </div>
              <div>
                <Label htmlFor="category">Category *</Label>
                 <Input id="category" type="text" placeholder="e.g., Restaurant, Plumber (Type exact category name)" value={categoryInput} onChange={(e) => setCategoryInput(e.target.value)} required />
                <p className="text-xs text-muted-foreground mt-1">Hint: Available categories include {allCategories.map(c=>c.name).slice(0,5).join(', ')}... etc.</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="listingDescription">Listing Description *</Label>
                <Textarea id="listingDescription" placeholder="Describe your business or service..." rows={4} value={listingDescription} onChange={(e) => setListingDescription(e.target.value)} required />
              </div>
              <div className="space-y-2 p-4 border rounded-md bg-muted/30">
                <Label htmlFor="descriptionKeywords" className="flex items-center">
                  <Sparkles className="mr-2 h-4 w-4 text-primary" /> Keywords for AI Description (Helps AI generate better text)
                </Label>
                <Textarea id="descriptionKeywords" placeholder="e.g., family-friendly, authentic Italian OR 24/7 emergency, licensed" rows={2} value={descriptionKeywords} onChange={(e) => setDescriptionKeywords(e.target.value)} />
                <Button type="button" variant="outline" size="sm" onClick={handleGenerateDescription} disabled={isGeneratingDescription || !listingType || !businessName || !categoryInput || !descriptionKeywords} className="mt-2">
                  {isGeneratingDescription ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Sparkles className="mr-2 h-4 w-4" />} Generate with AI
                </Button>
                {(!listingType || !businessName || !categoryInput || !descriptionKeywords) && !isGeneratingDescription && (<p className="text-xs text-muted-foreground mt-1">Fill required fields above to enable AI.</p>)}
              </div>
            </div>

            {listingType === 'store' && (
              <>
                <Separator className="my-6" />
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold flex items-center"><DollarSign className="mr-2 h-5 w-5 text-primary"/>Choose Your Store Plan *</h3>
                  <p className="text-sm text-muted-foreground">Select a monthly subscription. Payments via Khidmatik Escrow Wallet.</p>
                  <div className="grid md:grid-cols-2 gap-4">
                    {subscriptionPlans.map((plan) => {
                      const PlanIcon = plan.icon;
                      return (
                        <Card key={plan.id} className={`cursor-pointer hover:shadow-lg transition-shadow p-1 ${selectedPlan === plan.id ? 'ring-2 ring-primary border-primary' : 'border-border'}`} onClick={() => setSelectedPlan(plan.id)}>
                          <CardHeader>
                            <div className="flex items-center justify-between">
                              <CardTitle className="text-xl flex items-center"><PlanIcon className="mr-2 h-5 w-5 text-muted-foreground"/>{plan.name}</CardTitle>
                              {selectedPlan === plan.id && <CheckCircle className="h-6 w-6 text-primary" />}
                            </div>
                            <CardDescription className="font-semibold text-lg text-primary">{plan.price}</CardDescription>
                          </CardHeader>
                          <CardContent><ul className="list-disc list-inside text-sm space-y-1 text-muted-foreground">{plan.features.map(feature => <li key={feature}>{feature}</li>)}</ul></CardContent>
                        </Card>
                      );
                    })}
                  </div>
                   {selectedPlan && (<p className="text-xs text-center text-muted-foreground">Selected: {subscriptionPlans.find(p=>p.id === selectedPlan)?.name}. Fee processed upon verification.</p>)}
                </div>
              </>
            )}

            <Separator className="my-6" />
            
            <div className="space-y-4">
                <h3 className="text-lg font-semibold flex items-center"><UserCheck className="mr-2 h-5 w-5 text-primary"/>Identity & Business Verification *</h3>
                
                {/* ID Card Upload */}
                <div className="p-4 border-2 border-dashed rounded-md bg-muted/50 space-y-2">
                    <Label htmlFor="idCardUpload" className="font-semibold flex items-center">
                        <FileUp className="mr-2 h-5 w-5 text-primary" /> ID Card (PDF or JPG, Max 5MB) *
                    </Label>
                    <Input 
                        id="idCardUpload" 
                        type="file" 
                        accept=".pdf,.jpg,.jpeg" 
                        onChange={(e) => handleFileChange(e, setIdCardFile, "ID Card")} 
                        className="text-sm file:mr-2 file:py-1.5 file:px-3 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20"
                    />
                    {idCardFile && <p className="text-xs text-green-600 flex items-center"><BadgeCheck className="h-4 w-4 mr-1"/>Selected: {idCardFile.name}</p>}
                </div>

                {/* Commercial Register Upload (Conditional) */}
                {listingType === 'store' && (
                    <div className="p-4 border-2 border-dashed rounded-md bg-muted/50 space-y-2">
                        <Label htmlFor="commercialRegisterUpload" className="font-semibold flex items-center">
                            <FileUp className="mr-2 h-5 w-5 text-primary" /> Commercial Register (PDF or JPG, Max 5MB) *
                        </Label>
                        <Input 
                            id="commercialRegisterUpload" 
                            type="file" 
                            accept=".pdf,.jpg,.jpeg" 
                            onChange={(e) => handleFileChange(e, setCommercialRegisterFile, "Commercial Register")}
                            className="text-sm file:mr-2 file:py-1.5 file:px-3 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-primary/10 file:text-primary hover:file:bg-primary/20"
                        />
                        {commercialRegisterFile && <p className="text-xs text-green-600 flex items-center"><BadgeCheck className="h-4 w-4 mr-1"/>Selected: {commercialRegisterFile.name}</p>}
                         <p className="text-xs text-muted-foreground">Required for store registrations to verify business legitimacy.</p>
                    </div>
                )}
                
                <div className="flex items-start space-x-2 p-3 bg-blue-50 border border-blue-200 rounded-md text-blue-700 mt-2">
                    <AlertCircle className="h-5 w-5 mt-0.5 shrink-0 text-blue-700" />
                    <div className="text-xs">
                        <p className="font-medium">Important: Verification</p>
                        <p>Documents are for verification only, handled securely. Approval typically takes 24-48 hours.</p>
                    </div>
                </div>
            </div>


            {showSponsorshipSection && (
              <>
                <Separator className="my-6" />
                <div className="space-y-4 p-4 border rounded-md bg-accent/10">
                  <h3 className="text-lg font-semibold flex items-center"><Users className="mr-2 h-5 w-5 text-primary"/>Sponsorship for {categoryInput} *</h3>
                  <p className="text-sm text-muted-foreground">For '{categoryInput}', endorsements from two Khidmatik pros (4.5+ stars) needed. (Conceptual)</p>
                  <div className="space-y-3">
                    <div>
                      <Label htmlFor="sponsor1Id">Sponsor 1 (Khidmatik ID/Email) *</Label>
                      <Input id="sponsor1Id" type="text" placeholder="Sponsor 1 ID/Email" value={sponsor1Id} onChange={(e) => setSponsor1Id(e.target.value)} className="mt-1" />
                    </div>
                    <div>
                      <Label htmlFor="sponsor2Id">Sponsor 2 (Khidmatik ID/Email) *</Label>
                      <Input id="sponsor2Id" type="text" placeholder="Sponsor 2 ID/Email" value={sponsor2Id} onChange={(e) => setSponsor2Id(e.target.value)} className="mt-1" />
                    </div>
                  </div>
                   <div className="flex items-start space-x-2 p-3 bg-blue-50 border border-blue-200 rounded-md text-blue-700 mt-2">
                    <AlertCircle className="h-5 w-5 mt-0.5 shrink-0 text-blue-700" />
                    <div className="text-xs">
                        <p className="font-medium">Sponsorship Process</p>
                        <p>Sponsors contacted to confirm endorsement. Maintains quality and trust.</p>
                    </div>
                  </div>
                </div>
              </>
            )}

            <Button type="submit" className="w-full mt-6 bg-primary hover:bg-primary/90 text-primary-foreground" disabled={isSubmitting}>
              {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              {isSubmitting ? 'Submitting...' : 'Register & Submit for Verification'}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex-col items-center space-y-2">
          <p className="text-sm text-muted-foreground">
            Already have an account?{' '}
            <Link href="/login" className="font-medium text-primary hover:underline">Log in</Link>
          </p>
          <p className="text-sm text-muted-foreground">
            Different registration?{' '}
            <Link href="/register/choice" className="font-medium text-primary hover:underline">See options</Link>
          </p>
        </CardFooter>
      </Card>
    </div>
  );
}

