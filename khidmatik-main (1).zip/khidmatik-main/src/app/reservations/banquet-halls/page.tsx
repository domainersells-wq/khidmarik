import BookingCalendar from '@/components/ui/BookingCalendar';
import SearchBar from '@/components/listings/SearchBar';

export default function Page() {
  return (
    <div>
      <h1>Banquet Halls Reservations</h1>
      <SearchBar />
      <BookingCalendar />
    </div>
  );
}