
'use client';

import Link from 'next/link';
import { usePathname, useSearchParams } from 'next/navigation';
import { cn } from '@/lib/utils';
import { Button, buttonVariants } from '@/components/ui/button';
import {
  ShieldCheck,
  Users,
  FileText,
  ChevronLeft,
  LogOut,
  Settings,
  Store,
  Briefcase,
  DollarSign,
  ListChecks,
  UserCog,
  UserCheck as VerificationIcon, // Renamed for clarity
  BarChart3,
  FileWarning,
  Sparkles,
  MessageSquareWarning,
  Activity,
  LayoutDashboard,
  Fingerprint, // For Security & Audit
  Bot, // For AI Assistant
  Server, // For Live Monitoring (conceptual)
  Award, // For Vendor Performance
  TestTube2, // For A/B Testing
  Lightbulb, // For Community Feedback & Ideas
  Headset, // For Support System Ticketing
  Building // For Reservation Management
} from 'lucide-react';
import { AppLogo } from '@/components/layout/AppLogo';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';

interface AdminDashboardSidebarProps {
  onLinkClick?: () => void;
}

const navItems = [
  { href: 'verification-queue', label: 'Verification Queue', icon: VerificationIcon },
  { href: 'user-management', label: 'User Management', icon: UserCog },
  { href: 'store-management', label: 'Store Management', icon: Store },
  { href: 'reservation-management', label: 'Reservation Management', icon: Building },
  { href: 'provider-management', label: 'Service Provider Mgmt', icon: Briefcase },
  { href: 'financial-management', label: 'Financial Management', icon: DollarSign },
  { href: 'platform-analytics', label: 'Platform Analytics', icon: BarChart3 },
  { href: 'content-moderation', label: 'Content Moderation', icon: FileWarning },
  { href: 'cms-site-content', label: 'CMS & Site Content', icon: FileText },
  { href: 'system-configuration', label: 'System Configuration', icon: Settings },
  { href: 'security-audit', label: 'Security & Audit', icon: Fingerprint },
  { href: 'ai-advanced-tools', label: 'AI & Advanced Tools', icon: Sparkles },
  { href: 'support-system', label: 'Support System', icon: Headset },
];

export function AdminDashboardSidebar({ onLinkClick }: AdminDashboardSidebarProps) {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const router = useRouter();
  const { toast } = useToast();
  const currentSection = searchParams.get('section') || 'verification-queue'; 

  const handleLogout = ()_> {
    toast({ title: "Admin Logout (Conceptual)", description: "You have been logged out." });
    router.push('/admin/login');
    if (onLinkClick) onLinkClick();
  };

  return (
    <aside className="fixed inset-y-0 left-0 z-10 flex h-full w-64 flex-col border-r bg-card text-card-foreground shadow-md">
      <div className="flex h-16 items-center border-b px-6">
        <Link href="/admin/dashboard" className="flex items-center gap-2 font-semibold" onClick={onLinkClick}>
          <ShieldCheck className="h-7 w-7 text-primary" />
          <span className="text-lg">Super Admin</span>
        </Link>
      </div>
      <nav className="flex-1 overflow-auto py-4 px-4 text-sm font-medium">
        <ul className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentSection === item.href;
            return (
              <li key={item.href}>
                <Link
                  href={`/admin/dashboard?section=${item.href}`}
                  className={cn(
                    buttonVariants({ variant: isActive ? 'default' : 'ghost', size: 'sm' }), // Using sm size for denser look
                    'w-full justify-start h-9', // explicit height
                    isActive && 'bg-primary text-primary-foreground hover:bg-primary/90 hover:text-primary-foreground'
                  )}
                  onClick={onLinkClick}
                >
                  <Icon className="mr-2 h-4 w-4" /> {/* smaller icon */}
                  {item.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
      <div className="mt-auto border-t p-4 space-y-2">
        <Button variant="outline" className="w-full justify-start" onClick={handleLogout}>
          <LogOut className="mr-2 h-4 w-4" /> Log Out
        </Button>
        <Button variant="ghost" className="w-full justify-start text-muted-foreground" asChild>
          <Link href="/">
            <ChevronLeft className="mr-2 h-4 w-4" /> Back to Main Site
          </Link>
        </Button>
      </div>
    </aside>
  );
}
