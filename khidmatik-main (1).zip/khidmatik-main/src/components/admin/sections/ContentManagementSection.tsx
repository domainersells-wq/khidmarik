
'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText, ListChecks, Info, ShieldAlert, PackageSearch, StarOff, MessageSquareWarning, Trash2, Edit, CheckCircle, Filter } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Input } from '@/components/ui/input'; // Added for search
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'; // Added for filters

// Mock data for reported items and reviews (conceptual)
const mockReportedItems = [
    { id: 'report1', type: 'Product', name: 'Suspicious "Antique" Vase', reporter: 'UserX', reason: 'Potentially fake item description.', date: '2024-07-15' },
    { id: 'report2', type: 'Service', name: 'Unlicensed "Doctor" Consultation', reporter: 'UserY', reason: 'Provider claims medical expertise without credentials.', date: '2024-07-14'},
    { id: 'report3', type: 'User Profile', name: 'SpamUser123', reporter: 'AI Flag', reason: 'Multiple spam comments posted.', date: '2024-07-16'},
];
const mockReviewsForModeration = [
    { id: 'rev_mod1', listingName: 'Pizza Algéroise', userName: 'ClientA', rating: 1, comment: 'This is unacceptable! Worst pizza ever, full of insults!', status: 'Pending' },
    { id: 'rev_mod2', listingName: 'Plomberie Express', userName: 'ClientB', rating: 5, comment: 'Excellent service, very professional.', status: 'Approved' },
];


export function ContentManagementSection() {
    const { toast } = useToast();

    const handleModerateItem = (itemId: string, action: 'Approve' | 'Reject' | 'Remove' | 'Edit') => {
        toast({
            title: `Content Moderation: ${action} (Conceptual)`,
            description: `Item ID ${itemId} would be ${action.toLowerCase()}d. This requires backend interaction.`,
        });
    };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold font-headline flex items-center">
          <ShieldAlert className="mr-3 h-8 w-8 text-primary" /> Platform Content Moderation
        </h1>
        <p className="text-muted-foreground">Oversee and moderate user-generated content across the platform to maintain quality and safety.</p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle>Reported Content Queue</CardTitle>
          <CardDescription>
            Review products, services, or user profiles flagged by users or AI.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
            <div className="flex items-center gap-2 mb-2">
                <Input placeholder="Search reported items..." className="max-w-xs" disabled />
                <Select disabled>
                    <SelectTrigger className="w-[180px]"><Filter className="mr-2 h-4 w-4"/><SelectValue placeholder="Filter by Type"/></SelectTrigger>
                    <SelectContent><SelectItem value="product">Product</SelectItem><SelectItem value="service">Service</SelectItem><SelectItem value="user">User Profile</SelectItem></SelectContent>
                </Select>
            </div>
            {mockReportedItems.map(item => (
                <Card key={item.id} className="p-3 bg-muted/50">
                    <p className="font-semibold">{item.type}: {item.name}</p>
                    <p className="text-xs text-muted-foreground">Reported by: {item.reporter} on {item.date}</p>
                    <p className="text-sm mt-1">Reason: {item.reason}</p>
                    <div className="flex gap-2 mt-2">
                        <Button size="sm" variant="outline" onClick={() => handleModerateItem(item.id, 'Approve')}><CheckCircle className="mr-1 h-4 w-4 text-green-500"/>Approve</Button>
                        <Button size="sm" variant="outline" onClick={() => handleModerateItem(item.id, 'Remove')}><Trash2 className="mr-1 h-4 w-4 text-destructive"/>Remove</Button>
                        <Button size="sm" variant="ghost" onClick={() => handleModerateItem(item.id, 'Edit')}><Edit className="mr-1 h-4 w-4"/>View/Edit</Button>
                    </div>
                </Card>
            ))}
             {mockReportedItems.length === 0 && <p className="text-sm text-center text-muted-foreground">No content currently in the reported queue.</p>}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Customer Review Moderation</CardTitle>
          <CardDescription>Moderate, approve, or delete customer reviews based on platform guidelines.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
            <div className="flex items-center gap-2 mb-2">
                <Input placeholder="Search reviews by listing or user..." className="max-w-xs" disabled />
                 <Select disabled>
                    <SelectTrigger className="w-[180px]"><Filter className="mr-2 h-4 w-4"/><SelectValue placeholder="Filter by Status"/></SelectTrigger>
                    <SelectContent><SelectItem value="pending">Pending</SelectItem><SelectItem value="approved">Approved</SelectItem><SelectItem value="rejected">Rejected</SelectItem></SelectContent>
                </Select>
            </div>
             {mockReviewsForModeration.map(review => (
                <Card key={review.id} className="p-3 bg-muted/50">
                    <p className="font-semibold">Review for "{review.listingName}" by {review.userName} ({review.rating} stars)</p>
                    <p className="text-sm italic mt-1">"{review.comment}"</p>
                    <p className="text-xs text-muted-foreground">Status: {review.status}</p>
                    <div className="flex gap-2 mt-2">
                        {review.status === 'Pending' && <Button size="sm" variant="outline" onClick={() => handleModerateItem(review.id, 'Approve')}><CheckCircle className="mr-1 h-4 w-4 text-green-500"/>Approve</Button>}
                        <Button size="sm" variant="outline" onClick={() => handleModerateItem(review.id, 'Reject')}><Trash2 className="mr-1 h-4 w-4 text-destructive"/>Reject/Delete</Button>
                    </div>
                </Card>
            ))}
            {mockReviewsForModeration.length === 0 && <p className="text-sm text-center text-muted-foreground">No reviews pending moderation.</p>}
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Chat & Message Moderation (Conceptual)</CardTitle>
           <CardDescription>Review flagged user-to-user or user-to-provider communications.</CardDescription>
        </CardHeader>
        <CardContent>
            <p className="text-sm text-muted-foreground">Conceptual: An interface for reviewing flagged messages, with options to warn users or suspend accounts for policy violations.</p>
        </CardContent>
      </Card>

      <Card className="bg-blue-50 border-dashed border-blue-200">
        <CardHeader>
          <CardTitle className="flex items-center text-blue-700"><Info className="mr-2 h-5 w-5"/>Content Moderation Workflow (Conceptual)</CardTitle>
        </CardHeader>
        <CardContent className="text-sm space-y-2 text-blue-600">
            <p>
                Effective content moderation is crucial for user trust and platform reputation. This involves:
            </p>
            <ul className="list-disc list-inside pl-4 space-y-1">
                <li>
                    <strong>Product/Service/User Moderation:</strong> Review items flagged by users or AI. Use tools to remove, request edits, or suspend accounts violating platform policies.
                </li>
                <li>
                    <strong>Review Management:</strong> Monitor customer reviews for authenticity and appropriateness. Delete fake, spam, or abusive reviews.
                </li>
                <li>
                    <strong>Automated Flags & Manual Review:</strong> AI tools (conceptually) flag problematic content, which appears in queues for manual review and action.
                </li>
                 <li>
                    <strong>Policy Enforcement:</strong> Regularly update and enforce content policies. Communicate changes to users, vendors and service providers.
                </li>
            </ul>
            <p className="mt-2 font-semibold">
                Direct database access (e.g., to Firestore) and robust logging are needed for these actions in a real system.
            </p>
        </CardContent>
      </Card>
    </div>
  );
}
