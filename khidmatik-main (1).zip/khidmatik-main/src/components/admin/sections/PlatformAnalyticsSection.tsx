
'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { BarChart3, LineChart, Users, DollarSign, ShoppingCart, MapPin, TrendingUp, TrendingDown, CalendarDays, Download, Filter, ListChecks } from 'lucide-react';
import Image from 'next/image';
import { useToast } from '@/hooks/use-toast';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Input } from '@/components/ui/input';

// Mock Data (Conceptual)
const mockPlatformKPIs = {
  totalOrders: { value: 1250, trend: 15, period: 'last 30 days' },
  totalUsers: { value: 8500, trend: 8, period: 'last 30 days' },
  totalEarnings: { value: '2.5M DA', trend: 12, period: 'last 30 days' },
  activeListings: { value: 3500, trend: 5, period: 'last 30 days' },
};

const mockTopServicesStores = [
  { id: 'item1', name: 'Tech Universe Algérie (Store)', type: 'Store', requests: 1500, earnings: '500K DA' },
  { id: 'item2', name: 'Rapid Rooter Plumbing (Service)', type: 'Service', requests: 1200, earnings: '300K DA' },
  { id: 'item3', name: 'The Gourmet Place (Store)', type: 'Store', requests: 1100, earnings: '250K DA' },
];

const mockGeoData = [
    { city: 'Algiers', value: 40, details: '40% of activity' },
    { city: 'Oran', value: 25, details: '25% of activity' },
    { city: 'Constantine', value: 15, details: '15% of activity' },
    { city: 'Sidi Bel Abbès', value: 10, details: '10% of activity' },
    { city: 'Other', value: 10, details: '10% from other regions' },
];


export function PlatformAnalyticsSection() {
  const { toast } = useToast();

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold font-headline flex items-center">
          <BarChart3 className="mr-3 h-8 w-8 text-primary" /> Platform Analytics & Insights
        </h1>
        <p className="text-muted-foreground">Monitor overall platform health, user growth, and financial performance.</p>
      </header>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Total Orders</CardTitle><ShoppingCart className="h-4 w-4 text-muted-foreground" /></CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockPlatformKPIs.totalOrders.value.toLocaleString()}</div>
            <p className={`text-xs flex items-center ${mockPlatformKPIs.totalOrders.trend >= 0 ? 'text-green-600' : 'text-destructive'}`}>
              {mockPlatformKPIs.totalOrders.trend >= 0 ? <TrendingUp className="h-3 w-3 mr-1"/> : <TrendingDown className="h-3 w-3 mr-1"/>}
              {mockPlatformKPIs.totalOrders.trend}% ({mockPlatformKPIs.totalOrders.period})
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Total Users</CardTitle><Users className="h-4 w-4 text-muted-foreground" /></CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockPlatformKPIs.totalUsers.value.toLocaleString()}</div>
             <p className={`text-xs flex items-center ${mockPlatformKPIs.totalUsers.trend >= 0 ? 'text-green-600' : 'text-destructive'}`}>
              {mockPlatformKPIs.totalUsers.trend >= 0 ? <TrendingUp className="h-3 w-3 mr-1"/> : <TrendingDown className="h-3 w-3 mr-1"/>}
              {mockPlatformKPIs.totalUsers.trend}% ({mockPlatformKPIs.totalUsers.period})
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Total Platform Earnings</CardTitle><DollarSign className="h-4 w-4 text-muted-foreground" /></CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockPlatformKPIs.totalEarnings.value}</div>
            <p className={`text-xs flex items-center ${mockPlatformKPIs.totalEarnings.trend >= 0 ? 'text-green-600' : 'text-destructive'}`}>
              {mockPlatformKPIs.totalEarnings.trend >= 0 ? <TrendingUp className="h-3 w-3 mr-1"/> : <TrendingDown className="h-3 w-3 mr-1"/>}
              {mockPlatformKPIs.totalEarnings.trend}% ({mockPlatformKPIs.totalEarnings.period})
            </p>
          </CardContent>
        </Card>
         <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Active Listings (Stores+Services)</CardTitle><ListChecks className="h-4 w-4 text-muted-foreground" /></CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockPlatformKPIs.activeListings.value.toLocaleString()}</div>
            <p className={`text-xs flex items-center ${mockPlatformKPIs.activeListings.trend >= 0 ? 'text-green-600' : 'text-destructive'}`}>
              {mockPlatformKPIs.activeListings.trend >= 0 ? <TrendingUp className="h-3 w-3 mr-1"/> : <TrendingDown className="h-3 w-3 mr-1"/>}
              {mockPlatformKPIs.activeListings.trend}% ({mockPlatformKPIs.activeListings.period})
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
              <CardTitle className="flex items-center"><LineChart className="mr-2 h-5 w-5 text-primary"/>Platform Growth Trend (Users/Orders)</CardTitle>
              <CardDescription>Visualize overall platform activity growth over time.</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px] flex items-center justify-center bg-muted/30 rounded-md">
              <Image src="https://placehold.co/500x300.png" alt="Platform Growth Chart" width={500} height={300} data-ai-hint="line chart growth users orders" className="opacity-70"/>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
              <CardTitle className="flex items-center"><MapPin className="mr-2 h-5 w-5 text-primary"/>Geographic Activity Heatmap</CardTitle>
              <CardDescription>Distribution of users, orders, or service requests by region.</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px] flex items-center justify-center bg-muted/30 rounded-md">
              <Image src="https://placehold.co/500x300.png" alt="Geographic Activity Heatmap" width={500} height={300} data-ai-hint="algeria map heatmap activity" className="opacity-70"/>
              {/* Conceptual: Could list top cities below or make map interactive */}
              <div className="text-xs text-center mt-2 text-muted-foreground">
                {mockGeoData.map(g => `${g.city}: ${g.value}%`).join(' | ')}
              </div>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><TrendingUp className="mr-2 h-5 w-5 text-primary"/>Top Requested Services & Stores</CardTitle>
          <CardDescription>Identify most popular services, products, or vendors on the platform.</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Type</TableHead>
                <TableHead className="text-right">Requests/Views</TableHead>
                <TableHead className="text-right">Est. Earnings (DA)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mockTopServicesStores.map(item => (
                <TableRow key={item.id}>
                  <TableCell className="font-medium">{item.name}</TableCell>
                  <TableCell><Badge variant={item.type === 'Store' ? 'secondary' : 'outline'}>{item.type}</Badge></TableCell>
                  <TableCell className="text-right">{item.requests.toLocaleString()}</TableCell>
                  <TableCell className="text-right">{item.earnings}</TableCell>
                </TableRow>
              ))}
               {mockTopServicesStores.length === 0 && (
                <TableRow><TableCell colSpan={4} className="text-center text-muted-foreground py-4">No data available yet.</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
         <CardFooter className="pt-4 flex justify-between items-center">
            <div className="flex gap-2">
                <Button variant="outline" size="sm" disabled><CalendarDays className="mr-2 h-4 w-4"/>Date Range</Button>
                <Select disabled>
                    <SelectTrigger className="h-9 text-xs w-[150px]"><Filter className="mr-2 h-3 w-3"/><SelectValue placeholder="Filter by Type"/></SelectTrigger>
                    <SelectContent><SelectItem value="all">All</SelectItem><SelectItem value="store">Stores</SelectItem><SelectItem value="service">Services</SelectItem></SelectContent>
                </Select>
            </div>
            <Button variant="outline" size="sm" disabled><Download className="mr-2 h-4 w-4"/>Export Report</Button>
        </CardFooter>
      </Card>
    </div>
  );
}
