
'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FileText, Palette, Globe, Image as ImageIcon, Video, UploadCloud, Edit3, Languages, PlusCircle, AlertTriangle, Trash2, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useState, useEffect } from 'react';
import Image from 'next/image';
import type { BannerItem } from '@/types';

const HOMEPAGE_BANNERS_STORAGE_KEY = 'khidmatikHomepageBanners';
const MAX_BANNER_FILE_SIZE_BYTES = 1 * 1024 * 1024; // 1MB

export function PlatformCMSection() {
  const { toast } = useToast();
  const [selectedPage, setSelectedPage] = useState('');
  const [pageContent, setPageContent] = useState('');
  
  const [bannerImageFile, setBannerImageFile] = useState<File | null>(null);
  const [bannerLink, setBannerLink] = useState('');
  const [bannerAltText, setBannerAltText] = useState('');
  const [uploadedBanners, setUploadedBanners] = useState<BannerItem[]>([]);
  const [isBannerSaving, setIsBannerSaving] = useState(false);

  useEffect(() => {
    try {
      const storedBannersJSON = localStorage.getItem(HOMEPAGE_BANNERS_STORAGE_KEY);
      if (storedBannersJSON) {
        const bannersData: BannerItem[] = JSON.parse(storedBannersJSON);
        if (Array.isArray(bannersData) && bannersData.every(b => typeof b.id === 'string' && typeof b.src === 'string' && typeof b.alt === 'string')) {
          setUploadedBanners(bannersData);
        } else {
          console.warn("Malformed banner data in localStorage, clearing it.");
          localStorage.removeItem(HOMEPAGE_BANNERS_STORAGE_KEY); // Clear malformed data
        }
      }
    } catch (error) {
      console.error("Error loading banners from localStorage:", error);
    }
  }, []);

  useEffect(() => {
    return () => {
      uploadedBanners.forEach(banner => {
        if (banner.src.startsWith('blob:') || banner.src.startsWith('data:')) {
          // For blob URLs specifically: URL.revokeObjectURL(banner.src);
          // Data URIs don't need explicit revocation like blob URLs,
          // but this effect hook is good practice for cleanup if blob URLs were used.
        }
      });
    };
  }, [uploadedBanners]);


  const handleEditPage = (pageSlug: string) => {
    setSelectedPage(pageSlug);
    setPageContent(`Content for ${pageSlug}... (Loaded from backend - conceptual)`);
    toast({ title: `Editing Page: ${pageSlug}`, description: "Conceptual: WYSIWYG editor would load content here." });
  };

  const handleSavePageContent = () => {
    if (!selectedPage || !pageContent.trim()) {
        toast({ title: "Error", description: "No page selected or content is empty.", variant: "destructive"});
        return;
    }
    toast({ title: "Page Content Saved (Conceptual)", description: `Content for ${selectedPage} updated.` });
  };
  
  const handleSaveBanner = async () => {
    if(!bannerImageFile) {
        toast({title: "Missing Image", description: "Please select a banner image.", variant: "destructive"});
        return;
    }
    if(!bannerAltText.trim()){
        toast({title: "Missing Alt Text", description: "Please provide alt text for the banner image for accessibility.", variant: "destructive"});
        return;
    }

    if (bannerImageFile.size > MAX_BANNER_FILE_SIZE_BYTES) {
        toast({
            title: "Image Too Large",
            description: `The selected image exceeds 1MB (${(bannerImageFile.size / (1024*1024)).toFixed(2)}MB). It might be too large to store in the browser. Please compress or choose a smaller image.`,
            variant: "destructive",
            duration: 7000,
        });
        return;
    }

    setIsBannerSaving(true);

    const reader = new FileReader();
    reader.readAsDataURL(bannerImageFile);
    reader.onloadend = () => {
      const base64Image = reader.result as string;

      const newBannerId = `banner-${Date.now()}`;
      const newBanner: BannerItem = {
        id: newBannerId,
        src: base64Image,
        alt: bannerAltText,
        link: bannerLink,
        dataAiHint: bannerAltText.toLowerCase().split(' ').slice(0,2).join(' '),
      };

      setUploadedBanners(prevBanners => {
          const updatedBanners = [...prevBanners, newBanner];
          try {
              localStorage.setItem(HOMEPAGE_BANNERS_STORAGE_KEY, JSON.stringify(updatedBanners));
              toast({title: "Banner Added & Saved Locally", description: `Banner "${bannerAltText}" added. Refresh homepage to see changes.`});
              
              // Clear form only on successful save to localStorage
              setBannerImageFile(null);
              setBannerLink('');
              setBannerAltText('');
              const fileInput = document.getElementById('banner-image-upload') as HTMLInputElement;
              if (fileInput) fileInput.value = '';
              
              return updatedBanners;
          } catch (error) {
              console.error("Error saving banners to localStorage:", error);
              let errorMessage = "Could not save banners to local storage.";
              if (error instanceof DOMException && error.name === 'QuotaExceededError') {
                  errorMessage = "Storage full. Could not save banner. Image might be too large or too many banners stored. Try removing some banners or using smaller images.";
              }
              toast({title: "Storage Error", description: errorMessage, variant: "destructive", duration: 7000});
              return prevBanners; // Don't update UI state if localStorage save failed
          }
      });
      
      setIsBannerSaving(false);
    };
    reader.onerror = (error) => {
        console.error("Error converting image to data URI:", error);
        toast({title: "Image Processing Error", description: "Could not process the image file.", variant: "destructive"});
        setIsBannerSaving(false);
    };
  };

  const handleDeleteBanner = (bannerId: string) => {
    setUploadedBanners(prevBanners => {
        const updatedBanners = prevBanners.filter(b => b.id !== bannerId);
        try {
            localStorage.setItem(HOMEPAGE_BANNERS_STORAGE_KEY, JSON.stringify(updatedBanners));
            toast({title: "Banner Removed (Locally)", description: "Banner has been removed from the list. Refresh homepage to see changes."});
        } catch (error) {
            console.error("Error updating banners in localStorage:", error);
            toast({title: "Storage Error", description: "Could not update banners in local storage.", variant: "destructive"});
            return prevBanners; // Revert if save fails
        }
        return updatedBanners;
    });
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold font-headline flex items-center">
          <FileText className="mr-3 h-8 w-8 text-primary" /> CMS & Site Content Management
        </h1>
        <p className="text-muted-foreground">Manage static pages, promotional banners, and content display settings.</p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><Edit3 className="mr-2 h-5 w-5"/>Static Page Editor</CardTitle>
          <CardDescription>Edit content for pages like "About Us", "Privacy Policy", "Terms of Service".</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
            <div className="flex items-end gap-2">
                <div className="flex-grow">
                    <Label htmlFor="page-select">Select Page to Edit</Label>
                    <Select value={selectedPage} onValueChange={handleEditPage}>
                        <SelectTrigger id="page-select"><SelectValue placeholder="Choose a page..." /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="about-us">About Us</SelectItem>
                            <SelectItem value="privacy-policy">Privacy Policy</SelectItem>
                            <SelectItem value="terms-of-service">Terms of Service</SelectItem>
                            <SelectItem value="faq">FAQ</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
            </div>
            {selectedPage && (
                <div className="mt-4 space-y-2">
                    <Label htmlFor="page-content-editor">Page Content (Conceptual WYSIWYG Editor)</Label>
                    <Textarea 
                        id="page-content-editor" 
                        value={pageContent} 
                        onChange={(e) => setPageContent(e.target.value)}
                        rows={10} 
                        placeholder={`Enter content for ${selectedPage}...`}
                    />
                     <p className="text-xs text-muted-foreground">
                        In a real CMS, this would be a rich text editor (WYSIWYG) allowing formatting, images, etc.
                    </p>
                    <Button onClick={handleSavePageContent}>Save Page Content</Button>
                </div>
            )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
            <CardTitle className="flex items-center"><ImageIcon className="mr-2 h-5 w-5"/>Homepage Promotional Banners</CardTitle>
            <CardDescription>Manage banners displayed on the platform's homepage. Uploaded images are stored in browser's local storage for this session.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
            <div>
                <Label htmlFor="banner-image-upload">Upload Banner Image (Max 1MB Recommended: PNG, JPG, WEBP) *</Label>
                <Input id="banner-image-upload" type="file" accept="image/png, image/jpeg, image/webp" onChange={(e) => setBannerImageFile(e.target.files?.[0] || null)} />
                {bannerImageFile && <p className="text-xs text-green-600 mt-1">Selected: {bannerImageFile.name} (${(bannerImageFile.size / (1024*1024)).toFixed(2)}MB)</p>}
            </div>
            <div>
                <Label htmlFor="banner-alt-text">Banner Alt Text * (for accessibility)</Label>
                <Input id="banner-alt-text" type="text" value={bannerAltText} onChange={(e) => setBannerAltText(e.target.value)} placeholder="e.g., Special offer on electronics" />
            </div>
            <div>
                <Label htmlFor="banner-link">Banner Link (Optional)</Label>
                <Input id="banner-link" type="url" value={bannerLink} onChange={(e) => setBannerLink(e.target.value)} placeholder="e.g., /listings?category=electronics" />
            </div>
            <Button onClick={handleSaveBanner} disabled={!bannerImageFile || !bannerAltText.trim() || isBannerSaving}>
                {isBannerSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UploadCloud className="mr-2 h-4 w-4" />}
                {isBannerSaving ? 'Saving...' : 'Add Banner to List'}
            </Button>
            
            <div className="mt-6">
                <h4 className="font-semibold text-md mb-2">Current Banners (Stored in Browser)</h4>
                {uploadedBanners.length > 0 ? (
                    <div className="space-y-3 max-h-96 overflow-y-auto border p-2 rounded-md">
                        {uploadedBanners.map((banner) => (
                            <Card key={banner.id} className="p-3 bg-muted/50">
                                <div className="flex gap-3 items-start">
                                    <Image src={banner.src} alt={banner.alt} width={160} height={50} className="rounded object-contain border bg-white" />
                                    <div className="flex-grow">
                                        <p className="text-sm font-medium truncate" title={banner.alt}>{banner.alt}</p>
                                        {banner.link && <a href={banner.link} target="_blank" rel="noopener noreferrer" className="text-xs text-primary hover:underline truncate block" title={banner.link}>{banner.link}</a>}
                                        {!banner.link && <p className="text-xs text-muted-foreground">No link provided.</p>}
                                    </div>
                                    <Button variant="ghost" size="icon" onClick={() => handleDeleteBanner(banner.id)} className="text-destructive hover:text-destructive/80 shrink-0">
                                        <Trash2 className="h-4 w-4"/>
                                    </Button>
                                </div>
                            </Card>
                        ))}
                    </div>
                ) : (
                    <p className="text-sm text-muted-foreground">No banners uploaded yet in this session.</p>
                )}
                 <p className="text-xs text-muted-foreground mt-2">
                    <AlertTriangle className="inline h-3 w-3 mr-1 text-amber-600"/> 
                    Banners are stored in your browser's local storage for this session. Refresh the homepage to see updated banners in the carousel. Very large images might exceed storage limits.
                </p>
            </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
            <CardTitle className="flex items-center"><Languages className="mr-2 h-5 w-5"/>Content Display Settings</CardTitle>
            <CardDescription>Control content visibility based on language or region (Conceptual).</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
            <p className="text-sm text-muted-foreground">
                Conceptual: Options to manage default language for content, enable/disable specific languages,
                and potentially tailor content or promotions based on user's detected region (Wilaya).
            </p>
            <Button variant="outline" disabled>Manage Language Settings</Button>
            <Button variant="outline" disabled className="ml-2">Manage Regional Content</Button>
        </CardContent>
         <CardFooter>
            <p className="text-xs text-muted-foreground">
                A robust CMS would support versioning, draft states, and scheduling for content publication.
            </p>
        </CardFooter>
      </Card>
    </div>
  );
}

