
'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { ShieldCheck, Fingerprint, Activity, UserX, PowerOff, DatabaseBackup, ServerCrash, Lock, AlertTriangle, MapPin } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useState } from 'react';
import { formatDistanceToNow } from 'date-fns';

// Mock Data (Conceptual)
const mockActivityLog = [
  { id: 'log1', timestamp: new Date(Date.now() - 10 * 60 * 1000).toISOString(), user: 'admin@khidmatik.dz', action: 'Changed default commission rate', ip: '192.168.1.10', location: 'Algiers, DZ' },
  { id: 'log2', timestamp: new Date(Date.now() - 30 * 60 * 1000).toISOString(), user: 'user_suspicious@example.com', action: 'Failed login attempt (x5)', ip: '103.45.67.89', location: 'Unknown' },
  { id: 'log3', timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), user: 'store_owner@example.com', action: 'Product "New Item" created', ip: '41.22.33.44', location: 'Oran, DZ' },
];

export function PlatformSecuritySection() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');

  const handleEmergencyAction = (actionName: string) => {
    toast({
      title: `Emergency Action: ${actionName} (Conceptual)`,
      description: `The "${actionName}" emergency control would be triggered. This is a critical action.`,
      variant: "destructive",
      duration: 7000,
    });
  };

  const handleBackupAction = (actionName: string) => {
     toast({ title: `Backup Action: ${actionName} (Conceptual)`, description: `The ${actionName.toLowerCase()} process would be initiated.` });
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold font-headline flex items-center">
          <Fingerprint className="mr-3 h-8 w-8 text-primary" /> Security & Audit Center
        </h1>
        <p className="text-muted-foreground">Monitor platform activity, manage security settings, and perform emergency actions.</p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><Activity className="mr-2 h-5 w-5"/>Comprehensive Activity Logs</CardTitle>
          <CardDescription>View logs for all users and admins to track changes and identify suspicious activity.</CardDescription>
        </CardHeader>
        <CardContent>
            <Input 
                placeholder="Search logs by user, action, or IP..." 
                value={searchTerm} 
                onChange={(e) => setSearchTerm(e.target.value)}
                className="mb-4"
            />
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Timestamp</TableHead>
                        <TableHead>User/System</TableHead>
                        <TableHead>Action</TableHead>
                        <TableHead>IP Address</TableHead>
                        <TableHead>Location (Est.)</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {mockActivityLog.filter(log => log.user.includes(searchTerm) || log.action.includes(searchTerm) || log.ip.includes(searchTerm)).map(log => (
                        <TableRow key={log.id} className={log.action.includes('Failed login') ? 'bg-destructive/10' : ''}>
                            <TableCell className="text-xs">{formatDistanceToNow(new Date(log.timestamp), { addSuffix: true })}</TableCell>
                            <TableCell className="text-xs font-medium">{log.user}</TableCell>
                            <TableCell className="text-xs">{log.action}</TableCell>
                            <TableCell className="text-xs">{log.ip}</TableCell>
                            <TableCell className="text-xs flex items-center">
                                {log.location !== 'Unknown' && <MapPin className="h-3 w-3 mr-1 text-muted-foreground"/>} {log.location}
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
            <p className="text-xs text-muted-foreground mt-2">Conceptual: Real-time logging with advanced filtering and export options.</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><Lock className="mr-2 h-5 w-5"/>Emergency Control Tools</CardTitle>
          <CardDescription>Critical tools for immediate platform response in case of security incidents.</CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button variant="destructive" className="w-full" onClick={() => handleEmergencyAction("Activate Maintenance Mode")}>
                <ServerCrash className="mr-2 h-4 w-4"/> Activate Maintenance Mode
            </Button>
             <Button variant="destructive" className="w-full" onClick={() => handleEmergencyAction("Disable Payments Globally")}>
                <PowerOff className="mr-2 h-4 w-4"/> Disable Payments Globally
            </Button>
            <Button variant="destructive" className="w-full" onClick={() => handleEmergencyAction("Force Logout All Users")}>
                <UserX className="mr-2 h-4 w-4"/> Force Logout All Users
            </Button>
            <Button variant="destructive" className="w-full" onClick={() => handleEmergencyAction("Disable New Registrations")}>
                <UserX className="mr-2 h-4 w-4"/> Disable New Registrations
            </Button>
        </CardContent>
        <CardFooter>
             <div className="p-3 bg-red-50 border border-red-200 rounded-md text-red-700 text-xs flex items-start gap-2 mt-2">
                <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0" />
                <span>
                    <strong>Warning:</strong> These actions are critical and should only be used in genuine emergencies. 
                    They can significantly impact user experience and platform operation.
                </span>
            </div>
        </CardFooter>
      </Card>
      
      <Card>
        <CardHeader>
            <CardTitle className="flex items-center"><DatabaseBackup className="mr-2 h-5 w-5"/>System Backups & Recovery</CardTitle>
            <CardDescription>Manage platform data backups and recovery processes.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
            <p className="text-sm text-muted-foreground">Conceptual: Last backup: {formatDistanceToNow(new Date(Date.now() - 23 * 60 * 60 * 1000), { addSuffix: true })}.</p>
            <Button variant="outline" onClick={() => handleBackupAction("Initiate Manual Backup")}>Initiate Manual Backup</Button>
            <Button variant="outline" className="ml-2" onClick={() => handleBackupAction("View Backup History")} disabled>View Backup History</Button>
            <Button variant="outline" className="ml-2" onClick={() => handleBackupAction("Configure Backup Schedule")} disabled>Configure Backup Schedule</Button>
        </CardContent>
      </Card>

    </div>
  );
}
