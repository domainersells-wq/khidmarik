
'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Settings, Globe, DollarSign, FileText, Edit3, UploadCloud, AlertTriangle, CheckCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useState } from 'react';

export function PlatformSettingsSection() {
  const { toast } = useToast();
  const [defaultCurrency, setDefaultCurrency] = useState('DZD');
  const [defaultLanguage, setDefaultLanguage] = useState('ar'); // Arabic as example
  const [defaultCountry, setDefaultCountry] = useState('DZ');
  const [registrationEnabled, setRegistrationEnabled] = useState(true);
  const [maxServiceDuration, setMaxServiceDuration] = useState(''); // e.g., "30 days"
  const [pdfPolicyFile, setPdfPolicyFile] = useState<File | null>(null);

  const handleSaveChanges = (section: string) => {
    // Conceptual save logic
    toast({ title: `${section} Settings Saved (Conceptual)`, description: "Changes would be persisted to the backend." });
  };

  const handlePolicyUpload = () => {
    if (!pdfPolicyFile) {
        toast({ title: "No File Selected", description: "Please select a PDF policy document to upload.", variant: "destructive"});
        return;
    }
    toast({title: "Policy Document Uploaded (Conceptual)", description: `${pdfPolicyFile.name} uploaded and would replace the existing policy.`});
    setPdfPolicyFile(null); // Reset file input
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold font-headline flex items-center">
          <Settings className="mr-3 h-8 w-8 text-primary" /> System Configuration
        </h1>
        <p className="text-muted-foreground">Manage core platform settings, registration, limits, and legal documents.</p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><Globe className="mr-2 h-5 w-5"/>General Platform Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
                <Label htmlFor="defaultCurrency">Default Currency</Label>
                <Input id="defaultCurrency" value={defaultCurrency} onChange={e => setDefaultCurrency(e.target.value.toUpperCase())} placeholder="e.g., DZD" />
            </div>
            <div>
                <Label htmlFor="defaultLanguage">Default Language</Label>
                <Input id="defaultLanguage" value={defaultLanguage} onChange={e => setDefaultLanguage(e.target.value.toLowerCase())} placeholder="e.g., ar, fr, en" />
            </div>
            <div>
                <Label htmlFor="defaultCountry">Default Country Code</Label>
                <Input id="defaultCountry" value={defaultCountry} onChange={e => setDefaultCountry(e.target.value.toUpperCase())} placeholder="e.g., DZ" />
            </div>
          </div>
          <div className="flex items-center space-x-2 pt-2">
            <Switch id="registration-enabled" checked={registrationEnabled} onCheckedChange={setRegistrationEnabled} />
            <Label htmlFor="registration-enabled">Enable New User/Provider Registration</Label>
          </div>
          <Button onClick={() => handleSaveChanges("General Platform")}>Save General Settings</Button>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><DollarSign className="mr-2 h-5 w-5"/>Service & Operational Limits</CardTitle>
          <CardDescription>Set limits for services, delivery durations, or other operational parameters.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
            <div>
                <Label htmlFor="maxServiceDuration">Maximum Service Listing Duration (Conceptual)</Label>
                <Input id="maxServiceDuration" value={maxServiceDuration} onChange={e => setMaxServiceDuration(e.target.value)} placeholder="e.g., 30 days, 6 months, empty for indefinite" />
                <p className="text-xs text-muted-foreground mt-1">Set how long a service listing remains active before needing renewal or review.</p>
            </div>
            {/* Conceptual: Add more limit settings here, e.g., max products per store on basic plan, file upload sizes etc. */}
            <Button onClick={() => handleSaveChanges("Operational Limits")} disabled>Save Limits</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
            <CardTitle className="flex items-center"><FileText className="mr-2 h-5 w-5"/>Policy & Legal Documents</CardTitle>
            <CardDescription>Upload and manage PDF documents for Terms of Service, Privacy Policy, etc.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
            <div>
                <Label htmlFor="policy-upload-terms">Upload Terms of Service (PDF)</Label>
                <div className="flex items-center gap-2 mt-1">
                    <Input id="policy-upload-terms" type="file" accept=".pdf" onChange={(e) => setPdfPolicyFile(e.target.files?.[0] || null)} className="flex-grow"/>
                    <Button onClick={handlePolicyUpload} disabled={!pdfPolicyFile}><UploadCloud className="mr-2 h-4 w-4"/>Upload</Button>
                </div>
                 {pdfPolicyFile && <p className="text-xs text-green-500 mt-1">Selected: {pdfPolicyFile.name}</p>}
            </div>
             <div>
                <Label htmlFor="policy-upload-privacy">Upload Privacy Policy (PDF)</Label>
                <div className="flex items-center gap-2 mt-1">
                    <Input id="policy-upload-privacy" type="file" accept=".pdf" onChange={(e) => setPdfPolicyFile(e.target.files?.[0] || null)} className="flex-grow"/>
                    <Button onClick={handlePolicyUpload} disabled={!pdfPolicyFile}><UploadCloud className="mr-2 h-4 w-4"/>Upload</Button>
                </div>
            </div>
            <p className="text-sm text-muted-foreground">
                Uploaded documents will replace existing ones and be accessible to users. Consider versioning for legal documents.
            </p>
        </CardContent>
      </Card>
      
       <Card className="bg-yellow-50 border-yellow-200 text-yellow-800">
            <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center"><AlertTriangle className="mr-2 h-5 w-5"/>Important Note</CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-sm">
                    Changes to system configuration can have wide-ranging effects on the platform. 
                    Proceed with caution and ensure thorough testing after any modifications. 
                    Some settings may require backend developer intervention.
                </p>
            </CardContent>
        </Card>

    </div>
  );
}
