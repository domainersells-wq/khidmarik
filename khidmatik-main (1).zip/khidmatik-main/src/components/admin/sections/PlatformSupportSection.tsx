
'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { MessageSquareWarning, Search, ListFilter, FilePlus2, LifeBuoy, BookOpen, Video, MessageCircle, Send, Archive, Users, MessageSquare } from 'lucide-react';
import { mockSupportTickets } from '@/data/mock'; 
import { formatDistanceToNow } from 'date-fns';
import { useToast } from '@/hooks/use-toast';
import { useState } from 'react';

export function PlatformSupportSection() {
  const { toast } = useToast();
  const [selectedTicket, setSelectedTicket] = useState<typeof mockSupportTickets[0] | null>(null);
  const [replyText, setReplyText] = useState('');

  const handleViewTicket = (ticket: typeof mockSupportTickets[0]) => {
    setSelectedTicket(ticket);
    setReplyText(''); // Clear reply on new ticket selection
  };
  
  const handleSendReply = () => {
    if (!selectedTicket || !replyText.trim()) {
        toast({title: "Cannot Send", description: "No ticket selected or reply is empty.", variant: "destructive"});
        return;
    }
    toast({ title: 'Reply Sent (Conceptual)', description: `Your reply to ticket ${selectedTicket.ticketNumber} has been sent to ${selectedTicket.professionalName}.` });
    setReplyText('');
    // Conceptually update ticket's lastUpdate and status if needed
  };
  
  const handleTicketStatusChange = (ticketId: string, newStatus: string) => {
    toast({ title: 'Ticket Status Changed (Conceptual)', description: `Ticket ${ticketId} status updated to ${newStatus}.` });
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold font-headline flex items-center"><LifeBuoy className="mr-3 h-8 w-8 text-primary" />Platform Support System</h1>
        <p className="text-muted-foreground">Manage support tickets from users/providers, access knowledge base, and send messages.</p>
      </header>

      <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-1">
            <Card>
                <CardHeader>
                <CardTitle className="flex items-center"><ListFilter className="mr-2 h-5 w-5"/>Support Tickets</CardTitle>
                <CardDescription>View and manage incoming support requests.</CardDescription>
                <div className="flex gap-1 mt-1">
                    <Input placeholder="Search tickets..." className="h-8" disabled/>
                    <Select disabled><SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Status"/></SelectTrigger><SelectContent><SelectItem value="open">Open</SelectItem></SelectContent></Select>
                </div>
                </CardHeader>
                <CardContent className="max-h-[60vh] overflow-y-auto p-2 space-y-1">
                {mockSupportTickets.map((ticket) => (
                    <div key={ticket.id} className={`p-2 rounded-md cursor-pointer hover:bg-muted/70 ${selectedTicket?.id === ticket.id ? 'bg-primary/10 border border-primary/30' : 'bg-muted/30'}`} onClick={() => handleViewTicket(ticket)}>
                        <p className="font-semibold text-sm truncate">{ticket.issueSummary}</p>
                        <p className="text-xs text-muted-foreground">From: {ticket.professionalName} (#{ticket.ticketNumber})</p>
                        <div className="flex justify-between items-center mt-1">
                            <Badge variant={ticket.status === 'Open' ? 'default' : 'secondary'} className="text-xs capitalize">{ticket.status}</Badge>
                            <p className="text-xs text-muted-foreground/80">{formatDistanceToNow(new Date(ticket.lastUpdate), { addSuffix: true })}</p>
                        </div>
                    </div>  
                ))}
                {mockSupportTickets.length === 0 && <p className="text-sm text-muted-foreground text-center py-4">No active support tickets.</p>}
                </CardContent>
            </Card>
          </div>
        
        <div className="md:col-span-2">
            <Card className="flex flex-col h-full">
                <CardHeader className="border-b">
                    <CardTitle className="flex items-center">
                        <MessageCircle className="mr-2 h-5 w-5"/> Conversation Thread
                    </CardTitle>
                    <CardDescription>
                        {selectedTicket ? `Ticket #${selectedTicket.ticketNumber} - ${selectedTicket.professionalName}` : "Select a ticket to view conversation."}
                    </CardDescription>
                </CardHeader>
                <CardContent className="flex-grow overflow-y-auto p-4 space-y-3 bg-background">
                    {selectedTicket ? (
                        <>
                            <div className="p-2 border rounded-md bg-muted">
                                <p className="font-semibold text-sm">Issue: {selectedTicket.issueSummary}</p>
                                <p className="text-xs text-muted-foreground">Category: {selectedTicket.category} | Priority: {selectedTicket.priority}</p>
                            </div>
                            {/* Conceptual messages */}
                            <div className="flex justify-start"><div className="bg-muted p-2 rounded-lg max-w-[80%] text-sm">Hello, I'm having an issue with... (Client message)</div></div>
                            <div className="flex justify-end"><div className="bg-primary text-primary-foreground p-2 rounded-lg max-w-[80%] text-sm">Thank you for reaching out. We are looking into this. (Admin reply)</div></div>
                        </>
                    ) : (
                        <p className="text-center text-muted-foreground py-10">No conversation selected.</p>
                    )}
                </CardContent>
                {selectedTicket && (
                    <CardFooter className="border-t p-3 space-y-2 flex-col items-stretch">
                        <Textarea 
                            placeholder="Type your reply here..." 
                            rows={3} 
                            value={replyText}
                            onChange={(e) => setReplyText(e.target.value)}
                            disabled={!selectedTicket}
                        />
                        <div className="flex justify-between items-center">
                            <div className="flex gap-2">
                                <Select onValueChange={(status) => handleTicketStatusChange(selectedTicket.id, status)} disabled={!selectedTicket}>
                                    <SelectTrigger className="h-9 text-xs w-[150px]"><SelectValue placeholder="Change Status..."/></SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="Open">Open</SelectItem>
                                        <SelectItem value="In Progress">In Progress</SelectItem>
                                        <SelectItem value="Closed">Closed</SelectItem>
                                        <SelectItem value="Resolved">Resolved</SelectItem>
                                    </SelectContent>
                                </Select>
                                <Button variant="outline" size="sm" disabled={!selectedTicket}><Archive className="mr-1 h-4 w-4"/>Archive</Button>
                            </div>
                            <Button onClick={handleSendReply} disabled={!selectedTicket || !replyText.trim()}><Send className="mr-2 h-4 w-4"/>Send Reply</Button>
                        </div>
                    </CardFooter>
                )}
            </Card>
        </div>
      </div>

      <Card>
        <CardHeader>
            <CardTitle className="flex items-center"><MessageSquare className="mr-2 h-5 w-5"/>Bulk Messaging</CardTitle>
            <CardDescription>Send custom or bulk messages to specific user groups (e.g., all store owners, service providers in a category).</CardDescription>
        </CardHeader>
        <CardContent>
            <p className="text-sm text-muted-foreground">Conceptual: Interface to select user groups (based on role, category, location) and compose messages. This would integrate with notification services.</p>
            <Button variant="outline" className="mt-2" disabled><Users className="mr-2 h-4 w-4"/>Compose Bulk Message</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
            <CardTitle className="flex items-center"><BookOpen className="mr-2 h-5 w-5"/>Knowledge Base & FAQs</CardTitle>
            <CardDescription>Manage FAQs and tutorial content for users and providers.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
            <Input placeholder="Search FAQs and tutorials..." className="mb-3" disabled/>
            <Button variant="outline" className="w-full justify-start" disabled><FilePlus2 className="mr-2 h-4 w-4"/> Add New FAQ/Article</Button>
            <Button variant="outline" className="w-full justify-start" disabled><Video className="mr-2 h-4 w-4"/> Upload Video Tutorial</Button>
        </CardContent>
        <CardFooter>
            <p className="text-xs text-muted-foreground">A live chat option for admins to directly assist users could also be integrated here.</p>
        </CardFooter>
      </Card>
    </div>
  );
}

