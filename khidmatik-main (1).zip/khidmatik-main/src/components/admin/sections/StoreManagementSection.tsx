
'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Store, Users, CalendarDays, Search, Filter, Settings, Eye, ToggleLeft, ToggleRight, Star, ShieldAlert, MoreVertical, Package, ShieldCheck as VerifiedBadgeIcon } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import type { PlatformStore, StoreSubscriptionPlan } from '@/types';
import { mockPlatformStores } from '@/data/mock';
import { formatDistanceToNow } from 'date-fns';

export function StoreManagementSection() {
  const { toast } = useToast();
  const [stores, setStores] = useState<PlatformStore[]>(mockPlatformStores);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'inactive' | 'pending_payment' | 'expired'>('all');
  const [filterFeatured, setFilterFeatured] = useState<'all' | 'yes' | 'no'>('all');

  const handleToggleActive = (storeId: string, currentIsActive: boolean) => {
    setStores(prev => prev.map(store => store.id === storeId ? { ...store, isActive: !currentIsActive } : store));
    toast({ title: "Store Status Updated (Conceptual)", description: `Store ID ${storeId} active status toggled. This would update Firestore.` });
  };

  const handleToggleFeatured = (storeId: string, currentIsFeatured: boolean) => {
     setStores(prev => prev.map(store => store.id === storeId ? { ...store, isFeatured: !currentIsFeatured } : store));
    toast({ title: "Store Feature Status Updated (Conceptual)", description: `Store ID ${storeId} featured status toggled. This would update Firestore.` });
  };
  
  const handleAssignBadge = (storeId: string, badgeType: 'Verified' | 'Featured') => {
    if (badgeType === 'Featured') {
        const store = stores.find(s => s.id === storeId);
        if (store) handleToggleFeatured(storeId, store.isFeatured);
    } else {
        toast({ title: `${badgeType} Badge Assigned (Conceptual)`, description: `Store ID ${storeId} assigned ${badgeType} badge. This would update Firestore.`});
    }
  };
  
  const handleViewProducts = (storeId: string, storeName: string) => {
    toast({ title: `View Products for ${storeName} (Conceptual)`, description: `Navigating to product list for store ID ${storeId}.`});
  };


  const filteredStores = stores.filter(store => {
    const matchesSearch = store.storeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          store.ownerName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || (filterStatus === 'active' && store.isActive) || (filterStatus === 'inactive' && !store.isActive) || store.subscriptionStatus === filterStatus;
    const matchesFeatured = filterFeatured === 'all' || (filterFeatured === 'yes' && store.isFeatured) || (filterFeatured === 'no' && !store.isFeatured);
    return matchesSearch && matchesStatus && matchesFeatured;
  });

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold font-headline flex items-center">
          <Store className="mr-3 h-8 w-8 text-primary" /> Store Management
        </h1>
        <p className="text-muted-foreground">Oversee all merchant stores, manage subscriptions, and control store status.</p>
      </header>

       <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Stores</CardTitle>
            <Store className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stores.length}</div>
            <p className="text-xs text-muted-foreground">+X from last month (conceptual)</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Active Subscriptions</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stores.filter(s => s.subscriptionStatus === 'active').length}</div>
            <p className="text-xs text-muted-foreground">Pro: Y, Basic: Z (conceptual)</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Pending Verifications</CardTitle>
             <ShieldAlert className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stores.filter(s => s.subscriptionStatus === 'pending_payment' && !s.isActive).length}</div>
            <p className="text-xs text-muted-foreground">Awaiting verification/payment</p>
          </CardContent>
        </Card>
         <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Featured Stores</CardTitle>
             <Star className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stores.filter(s => s.isFeatured).length}</div>
          </CardContent>
        </Card>
      </div>


      <Card>
        <CardHeader>
          <CardTitle>All Platform Stores</CardTitle>
          <CardDescription>View, manage, and moderate all registered stores. Table includes avg rating, activity status.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-2 mb-4">
            <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                    type="search"
                    placeholder="Search by store or owner name..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-8 w-full"
                />
            </div>
            <Select value={filterStatus} onValueChange={(value) => setFilterStatus(value as any)}>
                <SelectTrigger className="w-full sm:w-[180px]">
                    <Filter className="mr-2 h-4 w-4 text-muted-foreground" />
                    <SelectValue placeholder="Filter by Status" />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                    <SelectItem value="pending_payment">Pending Payment</SelectItem>
                    <SelectItem value="expired">Subscription Expired</SelectItem>
                </SelectContent>
            </Select>
            <Select value={filterFeatured} onValueChange={(value) => setFilterFeatured(value as any)}>
                <SelectTrigger className="w-full sm:w-[180px]">
                    <Star className="mr-2 h-4 w-4 text-muted-foreground" />
                    <SelectValue placeholder="Filter by Featured" />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="yes">Featured</SelectItem>
                    <SelectItem value="no">Not Featured</SelectItem>
                </SelectContent>
            </Select>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Store Name</TableHead>
                <TableHead>Owner</TableHead>
                <TableHead>City</TableHead>
                <TableHead className="text-center">Orders</TableHead>
                <TableHead className="text-center">Rating</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Featured</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredStores.map((store) => (
                <TableRow key={store.id}>
                  <TableCell className="font-medium">{store.storeName}</TableCell>
                  <TableCell>{store.ownerName}</TableCell>
                  <TableCell>{store.location?.city || 'N/A'}</TableCell>
                  <TableCell className="text-center">{store.totalSales ? (store.totalSales / (store.averageRating || 5000)).toFixed(0) : 0}</TableCell> {/* Mock orders */}
                  <TableCell className="text-center">{store.averageRating ? store.averageRating.toFixed(1) : 'N/A'}</TableCell>
                  <TableCell>
                    <Badge variant={store.isActive ? 'default' : 'destructive'} className={store.isActive ? 'bg-green-500' : ''}>
                      {store.isActive ? 'Active' : 'Inactive'}
                    </Badge>
                    {store.subscriptionStatus !== 'active' && (
                        <Badge variant="outline" className="ml-1 text-xs border-yellow-500 text-yellow-600 capitalize">{store.subscriptionStatus.replace('_', ' ')}</Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    <Badge variant={store.isFeatured ? 'default' : 'outline'} className={store.isFeatured ? 'bg-accent text-accent-foreground' : ''}>
                        {store.isFeatured ? 'Yes' : 'No'}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon"><MoreVertical className="h-4 w-4" /></Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => toast({title: "View Store Details (Conceptual)"})}> <Eye className="mr-2 h-4 w-4"/>View Details</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleViewProducts(store.id, store.storeName)}> <Package className="mr-2 h-4 w-4"/>View Products</DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => handleToggleActive(store.id, store.isActive)}>
                          {store.isActive ? <ToggleLeft className="mr-2 h-4 w-4"/> : <ToggleRight className="mr-2 h-4 w-4"/>}
                          {store.isActive ? 'Deactivate' : 'Activate'} Store
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleAssignBadge(store.id, 'Featured')}>
                          <Star className="mr-2 h-4 w-4"/>
                          {store.isFeatured ? 'Unfeature' : 'Feature'} Store
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleAssignBadge(store.id, 'Verified')}>
                           <VerifiedBadgeIcon className="mr-2 h-4 w-4"/> Assign "Verified" Badge
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => toast({title: `Manually Approving ${store.storeName} (Conceptual)`})}>Approve Store/Services</DropdownMenuItem>
                        {/* Conceptual: Subscription management moved to Financials */}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
           {filteredStores.length === 0 && <p className="text-center py-4 text-muted-foreground">No stores match your filters.</p>}
        </CardContent>
         <CardFooter className="pt-4">
            <p className="text-xs text-muted-foreground">
                Store management includes controlling subscription levels, visibility (active/inactive), and promotional featuring.
                These actions would typically update the 'stores' collection in Firestore.
            </p>
        </CardFooter>
      </Card>
    </div>
  );
}
