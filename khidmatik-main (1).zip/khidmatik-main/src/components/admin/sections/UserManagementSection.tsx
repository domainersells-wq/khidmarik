
'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Users, UserCog, Search, Filter, CalendarDays, MoreVertical, ShieldCheck, UserX, UserCheck, Edit3, ShieldX, Eye, MessageSquare, Activity } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator, DropdownMenuLabel } from '@/components/ui/dropdown-menu'; // Added DropdownMenuLabel
import { useToast } from '@/hooks/use-toast';
import type { PlatformUser, UserRole } from '@/types';
import { mockPlatformUsers } from '@/data/mock';
import { formatDistanceToNow } from 'date-fns';

export function UserManagementSection() {
  const { toast } = useToast();
  const [users, setUsers] = useState<PlatformUser[]>(mockPlatformUsers);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState<UserRole | 'all'>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'banned' | 'pending_verification'>('all');

  const handleToggleBanStatus = (userId: string, currentStatus: PlatformUser['status']) => {
    const newStatus: PlatformUser['status'] = currentStatus === 'banned' ? 'active' : 'banned';
    setUsers(prev => prev.map(user => user.id === userId ? { ...user, status: newStatus } : user));
    toast({ title: "User Status Updated (Conceptual)", description: `User ID ${userId} status changed to ${newStatus}. This would update Firestore and Firebase Auth state.` });
  };

  const handleChangeRole = (userId: string, newRole: UserRole) => {
    setUsers(prev => prev.map(user => user.id === userId ? { ...user, role: newRole } : user));
    toast({ title: "User Role Updated (Conceptual)", description: `User ID ${userId} role changed to ${newRole}. This would update Firebase Custom Claims & Firestore user document.` });
  };
  
  const handleSendMessage = (userId: string, userName: string) => {
    toast({ title: `Send Message to ${userName} (Conceptual)`, description: `A modal to compose and send a private message or platform alert to user ID ${userId} would open.` });
  };

  const handleViewActivityLog = (userId: string, userName: string) => {
     toast({ title: `View Activity Log for ${userName} (Conceptual)`, description: `Navigating to a detailed activity log page for user ID ${userId}.` });
  };
  
  const roles: {value: UserRole, label: string}[] = [
    {value: 'customer', label: 'Customer'},
    {value: 'vendor', label: 'Vendor'},
    {value: 'service_provider', label: 'Service Provider'},
    {value: 'superadmin', label: 'Super Admin'}
  ];

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = filterRole === 'all' || user.role === filterRole;
    const matchesStatus = filterStatus === 'all' || user.status === filterStatus;
    return matchesSearch && matchesRole && matchesStatus;
  });

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold font-headline flex items-center">
          <UserCog className="mr-3 h-8 w-8 text-primary" /> Platform User Management
        </h1>
        <p className="text-muted-foreground">Oversee all registered users, manage roles, and control account status.</p>
      </header>
      
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Total Users</CardTitle><Users className="h-4 w-4 text-muted-foreground" /></CardHeader>
          <CardContent><div className="text-2xl font-bold">{users.length}</div></CardContent>
        </Card>
         <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Vendors (Store Owners)</CardTitle><Users className="h-4 w-4 text-muted-foreground" /></CardHeader>
          <CardContent><div className="text-2xl font-bold">{users.filter(u => u.role === 'vendor').length}</div></CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Service Providers</CardTitle><Users className="h-4 w-4 text-muted-foreground" /></CardHeader>
          <CardContent><div className="text-2xl font-bold">{users.filter(u => u.role === 'service_provider').length}</div></CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Banned Users</CardTitle><UserX className="h-4 w-4 text-muted-foreground" /></CardHeader>
          <CardContent><div className="text-2xl font-bold">{users.filter(u => u.status === 'banned').length}</div></CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Platform Users</CardTitle>
          <CardDescription>View, manage roles, and ban/unban user accounts. Real system would have pagination.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-2 mb-4">
            <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                    type="search"
                    placeholder="Search by user name or email..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-8 w-full"
                />
            </div>
            <Select value={filterRole} onValueChange={(value) => setFilterRole(value as any)}>
                <SelectTrigger className="w-full sm:w-[180px]">
                    <Users className="mr-2 h-4 w-4 text-muted-foreground" />
                    <SelectValue placeholder="Filter by Role" />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="all">All Roles</SelectItem>
                    {roles.map(r => <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>)}
                </SelectContent>
            </Select>
            <Select value={filterStatus} onValueChange={(value) => setFilterStatus(value as any)}>
                <SelectTrigger className="w-full sm:w-[180px]">
                    <Filter className="mr-2 h-4 w-4 text-muted-foreground" />
                    <SelectValue placeholder="Filter by Status" />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="banned">Banned</SelectItem>
                    <SelectItem value="pending_verification">Pending Verification</SelectItem>
                </SelectContent>
            </Select>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Registered</TableHead>
                <TableHead>Last Login</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.map((user) => (
                <TableRow key={user.id}>
                  <TableCell className="font-medium">{user.userName}</TableCell>
                  <TableCell>{user.email}</TableCell>
                  <TableCell>
                    <Badge variant={user.role === 'superadmin' ? 'destructive' : user.role === 'vendor' ? 'secondary' : 'outline'} className="capitalize">
                      {user.role.replace('_', ' ')}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant={user.status === 'active' ? 'default' : user.status === 'banned' ? 'destructive' : 'secondary'}
                           className={`capitalize ${user.status === 'active' ? 'bg-green-500 text-white' : user.status === 'pending_verification' ? 'bg-yellow-500 text-white' : ''}`}>
                      {user.status.replace('_', ' ')}
                    </Badge>
                  </TableCell>
                  <TableCell>{formatDistanceToNow(new Date(user.registrationDate), { addSuffix: true })}</TableCell>
                  <TableCell>{user.lastLogin ? formatDistanceToNow(new Date(user.lastLogin), { addSuffix: true }) : 'N/A'}</TableCell>
                  <TableCell className="text-right">
                     <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon"><MoreVertical className="h-4 w-4" /></Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => toast({title: "View Details (Conceptual)"})}> <Eye className="mr-2 h-4 w-4"/>View Full Profile</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleSendMessage(user.id, user.userName)}> <MessageSquare className="mr-2 h-4 w-4"/>Send Message/Alert</DropdownMenuItem>
                         <DropdownMenuItem onClick={() => handleViewActivityLog(user.id, user.userName)}> <Activity className="mr-2 h-4 w-4"/>View User Activity</DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => handleToggleBanStatus(user.id, user.status)}>
                          {user.status === 'banned' ? <UserCheck className="mr-2 h-4 w-4"/> : <UserX className="mr-2 h-4 w-4"/>}
                          {user.status === 'banned' ? 'Unban User' : 'Ban User'}
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuLabel>Change Role To</DropdownMenuLabel>
                        {roles.filter(r => r.value !== user.role).map(roleOption => (
                             <DropdownMenuItem key={roleOption.value} onClick={() => handleChangeRole(user.id, roleOption.value)}>
                                <Edit3 className="mr-2 h-4 w-4"/> {roleOption.label}
                            </DropdownMenuItem>
                        ))}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {filteredUsers.length === 0 && <p className="text-center py-4 text-muted-foreground">No users match your filters.</p>}
        </CardContent>
         <CardFooter className="pt-4">
            <p className="text-xs text-muted-foreground">
                User role management is critical. Assigning 'superadmin' grants full platform control.
                Banning a user revokes their access. These actions would update Firestore 'users' collection and Firebase Auth (custom claims for roles, disable for ban).
            </p>
        </CardFooter>
      </Card>
    </div>
  );
}
