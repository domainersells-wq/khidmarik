
'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Users, CheckCircle, XCircle, Mail, CalendarDays, Search, Filter, Store, Briefcase, FileText, Link as LinkIcon, Phone, User, Cake, UserCheck as VerificationIcon, ShieldAlert } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { AdminVerificationRequestItem } from '@/types';
import { mockAdminVerificationQueue } from '@/data/mock';
import { format, formatDistanceToNow, parseISO } from 'date-fns';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogClose } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';

export function UserVerificationSection() {
  const { toast } = useToast();
  const [verificationQueue, setVerificationQueue] = useState<AdminVerificationRequestItem[]>(mockAdminVerificationQueue);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'Store' | 'Professional'>('all'); 
  const [selectedRequest, setSelectedRequest] = useState<AdminVerificationRequestItem | null>(null);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);

  const handleApprove = (requestId: string) => {
    setVerificationQueue(prev => prev.map(req => req.id === requestId ? { ...req, status: 'Approved' } : req));
    toast({ title: "Verification Approved (Conceptual)", description: `Request ID ${requestId} approved. Applicant notified. User role/status updated in Firestore/Auth.` });
  };

  const handleReject = (requestId: string) => {
    // Conceptual: Add a step to ask for rejection reason
    setVerificationQueue(prev => prev.map(req => req.id === requestId ? { ...req, status: 'Rejected' } : req));
    toast({ title: "Verification Rejected (Conceptual)", description: `Request ID ${requestId} rejected. Applicant notified.`, variant: "destructive" });
  };

  const handleViewDetails = (request: AdminVerificationRequestItem) => {
    setSelectedRequest(request);
    setIsDetailsModalOpen(true);
  };

  const filteredQueue = verificationQueue.filter(item => {
    const matchesSearch = item.applicantName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          item.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          (item.entityName && item.entityName.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesType = filterType === 'all' || item.requestType === filterType;
    return matchesSearch && matchesType;
  });

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold font-headline flex items-center">
          <VerificationIcon className="mr-3 h-8 w-8 text-primary" /> User & Business Verification Queue
        </h1>
        <p className="text-muted-foreground">Manage pending verification requests for new stores, service providers, and potentially high-value users.</p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle>Pending Applications & Verifications</CardTitle>
          <CardDescription>Review and process new applications or identity verification requests.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-2 mb-4">
            <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                type="search"
                placeholder="Search by name, email, or entity..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8 w-full"
                />
            </div>
            <Select value={filterType} onValueChange={(value) => setFilterType(value as 'all' | 'Store' | 'Professional')}>
                <SelectTrigger className="w-full sm:w-[200px]">
                    <Filter className="mr-2 h-4 w-4 text-muted-foreground" />
                    <SelectValue placeholder="Filter by Type" />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="all">All Application Types</SelectItem>
                    <SelectItem value="Store"><Store className="mr-2 h-4 w-4 inline-block"/> Store Applications</SelectItem>
                    <SelectItem value="Professional"><Briefcase className="mr-2 h-4 w-4 inline-block"/> Professional Applications</SelectItem>
                    {/* Conceptual: Add 'User Identity' for regular user KYC if implemented */}
                </SelectContent>
            </Select>
          </div>

          {filteredQueue.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Applicant/Entity Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Category/Plan</TableHead>
                  <TableHead>Submitted</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredQueue.map((req) => (
                  <TableRow key={req.id}>
                    <TableCell className="font-medium">{req.entityName || req.applicantName}</TableCell>
                    <TableCell>{req.email}</TableCell>
                    <TableCell>
                      <Badge variant={req.requestType === 'Store' ? 'secondary' : 'outline'} className="flex items-center gap-1">
                        {req.requestType === 'Store' ? <Store className="h-3 w-3" /> : <Briefcase className="h-3 w-3" />}
                        {req.requestType}
                      </Badge>
                    </TableCell>
                    <TableCell>{req.categoryOrPlan || 'N/A'}</TableCell>
                    <TableCell>{formatDistanceToNow(new Date(req.submissionDate), { addSuffix: true })}</TableCell>
                    <TableCell>
                        <Badge variant={
                            req.status === 'Pending' ? 'default' :
                            req.status === 'Approved' ? 'outline' : 
                            'destructive'
                        } className={`capitalize ${req.status === 'Pending' ? 'bg-yellow-500 text-white' : req.status === 'Approved' ? 'bg-green-500 text-white' : ''}`}>
                            {req.status}
                        </Badge>
                    </TableCell>
                    <TableCell className="text-right space-x-1">
                      <Button variant="link" size="sm" onClick={() => handleViewDetails(req)}>Details</Button>
                      {req.status === 'Pending' && (
                        <>
                          <Button variant="ghost" size="icon" className="text-green-600 hover:text-green-700" onClick={() => handleApprove(req.id)} title="Approve">
                            <CheckCircle className="h-4 w-4" /> <span className="sr-only">Approve</span>
                          </Button>
                          <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive/80" onClick={() => handleReject(req.id)} title="Reject">
                            <XCircle className="h-4 w-4" /> <span className="sr-only">Reject</span>
                          </Button>
                        </>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-muted-foreground text-center py-4">No pending verification requests matching your criteria.</p>
          )}
        </CardContent>
      </Card>

      {selectedRequest && (
        <Dialog open={isDetailsModalOpen} onOpenChange={setIsDetailsModalOpen}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>Applicant Details: {selectedRequest.entityName || selectedRequest.applicantName}</DialogTitle>
              <DialogDescription>Review the applicant's information and documents. (Conceptual: Document viewer would be here)</DialogDescription>
            </DialogHeader>
            <div className="py-4 space-y-3 max-h-[60vh] overflow-y-auto pr-2">
              <h4 className="font-semibold text-md">Personal Information</h4>
              <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
                <div className="flex items-center"><User className="h-4 w-4 mr-2 text-muted-foreground"/><strong>Name:</strong></div> <div>{selectedRequest.applicantName}</div>
                <div className="flex items-center"><User className="h-4 w-4 mr-2 text-muted-foreground"/><strong>Surname:</strong></div><div> {selectedRequest.surname || 'N/A'}</div>
                <div className="flex items-center"><Cake className="h-4 w-4 mr-2 text-muted-foreground"/><strong>Date of Birth:</strong></div><div> {selectedRequest.dateOfBirth ? format(parseISO(selectedRequest.dateOfBirth), 'PPP') : 'N/A'}</div>
                <div className="flex items-center"><Mail className="h-4 w-4 mr-2 text-muted-foreground"/><strong>Email:</strong></div><div> {selectedRequest.email}</div>
                <div className="flex items-center"><Phone className="h-4 w-4 mr-2 text-muted-foreground"/><strong>Phone:</strong></div><div> {selectedRequest.phone || 'N/A'}</div>
              </div>
              <Separator />
              <h4 className="font-semibold text-md">Application Details</h4>
               <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
                <div><strong>Type:</strong></div> <div>{selectedRequest.requestType}</div>
                {selectedRequest.entityName && <><div><strong>Entity Name:</strong></div> <div>{selectedRequest.entityName}</div></>}
                <div><strong>Category/Plan:</strong></div> <div>{selectedRequest.categoryOrPlan}</div>
                <div><strong>Submitted:</strong></div> <div>{formatDistanceToNow(new Date(selectedRequest.submissionDate), { addSuffix: true })}</div>
                <div><strong>Status:</strong></div> <div><Badge variant={selectedRequest.status === 'Pending' ? 'default' : selectedRequest.status === 'Approved' ? 'outline' : 'destructive'} className={`capitalize ${selectedRequest.status === 'Pending' ? 'bg-yellow-500 text-white' : selectedRequest.status === 'Approved' ? 'bg-green-500 text-white' : ''}`}>{selectedRequest.status}</Badge></div>
              </div>
              <Separator />
              <h4 className="font-semibold text-md">Uploaded Documents (Conceptual Links)</h4>
              <div className="space-y-2 text-sm">
                {selectedRequest.idCardUrl ? (
                  <p><LinkIcon className="h-4 w-4 mr-1 inline-block text-primary"/> <a href={selectedRequest.idCardUrl} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">View ID Card ({selectedRequest.idCardUrl.split('.').pop()?.toUpperCase()})</a></p>
                ) : (
                  <p className="text-muted-foreground">ID Card: Not Provided</p>
                )}
                {selectedRequest.commercialRegisterUrl ? (
                  <p><FileText className="h-4 w-4 mr-1 inline-block text-primary"/> <a href={selectedRequest.commercialRegisterUrl} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">View Commercial Register ({selectedRequest.commercialRegisterUrl.split('.').pop()?.toUpperCase()})</a></p>
                ) : (
                  <p className="text-muted-foreground">Commercial Register: {selectedRequest.requestType === 'Store' ? 'Not Provided' : 'N/A for Professionals'}</p>
                )}
                 {/* Placeholder for other documents like qualifications */}
                 {selectedRequest.requestType === 'Professional' && <p className="text-muted-foreground">Qualifications/Other Docs: (Conceptual links)</p>}
              </div>
            </div>
            <DialogFooter>
              {selectedRequest.status === 'Pending' && (
                  <>
                    <Button variant="outline" className="border-destructive text-destructive hover:bg-destructive/10" onClick={() => {handleReject(selectedRequest.id); setIsDetailsModalOpen(false);}}>
                        <XCircle className="mr-2 h-4 w-4"/> Reject Application
                    </Button>
                    <Button className="bg-green-600 hover:bg-green-700 text-white" onClick={() => {handleApprove(selectedRequest.id); setIsDetailsModalOpen(false);}}>
                        <CheckCircle className="mr-2 h-4 w-4"/> Approve Application
                    </Button>
                  </>
              )}
              <DialogClose asChild>
                <Button type="button" variant="secondary">Close</Button>
              </DialogClose>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      <Card className="bg-blue-50 border-blue-200 text-blue-600">
        <CardHeader>
            <CardTitle className="text-lg flex items-center"><ShieldAlert className="mr-2 h-5 w-5"/>Verification Process Notes</CardTitle>
        </CardHeader>
        <CardContent className="text-sm space-y-2">
            <p><strong>Application Review:</strong> Review applications from merchants and professionals. Click "Details" to see submitted information and document links (conceptual).</p>
            <p><strong>Store Verification:</strong> Check business documents (Commercial Register, NIF), owner ID, and subscription plan.</p>
            <p><strong>Professional Verification:</strong> Check ID, qualifications, and potential sponsorship for critical professions.</p>
            <p><strong>Firebase Integration (Conceptual):</strong> Approval updates Firestore (e.g., 'stores', 'service_providers' collections) and Firebase Auth custom claims (e.g., `role: 'vendor'`). Rejection sends a notification.</p>
        </CardContent>
      </Card>
    </div>
  );
}
