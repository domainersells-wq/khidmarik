"use client";
import { useState } from "react";
import { TextField, Button, Grid } from "@mui/material";

export const BasicInfoStep = ({ onNext }) => {
  const [hallName, setHallName] = useState("");
  const [location, setLocation] = useState("");
  const [capacity, setCapacity] = useState("");
  const [price, setPrice] = useState("");

  const handleNext = () => {
    onNext({ hallName, location, capacity, price });
  };

  return (
    <Grid container spacing={2}>
      <Grid item xs={12}>
        <TextField
          label="Hall Name"
          fullWidth
          value={hallName}
          onChange={(e) => setHallName(e.target.value)}
        />
      </Grid>
      <Grid item xs={12}>
        <TextField
          label="Location"
          fullWidth
          value={location}
          onChange={(e) => setLocation(e.target.value)}
        />
      </Grid>
      <Grid item xs={12} sm={6}>
        <TextField
          label="Capacity"
          type="number"
          fullWidth
          value={capacity}
          onChange={(e) => setCapacity(e.target.value)}
        />
      </Grid>
      <Grid item xs={12} sm={6}>
        <TextField
          label="Price per Day"
          type="number"
          fullWidth
          value={price}
          onChange={(e) => setPrice(e.target.value)}
        />
      </Grid>
      <Grid item xs={12}>
        <Button variant="contained" color="primary" onClick={handleNext}>
          Next
        </Button>
      </Grid>
    </Grid>
  );
};