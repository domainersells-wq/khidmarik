"use client";
import { Button, Grid, Typography, Paper } from "@mui/material";

export const ConfirmationStep = ({ formData, onBack, onSubmit }) => {
  return (
    <Paper elevation={3} className="p-4">
      <Typography variant="h6" gutterBottom>
        Confirm Your Details
      </Typography>
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <Typography variant="subtitle1">
            <strong>Hall Name:</strong> {formData.hallName}
          </Typography>
        </Grid>
        <Grid item xs={12}>
          <Typography variant="subtitle1">
            <strong>Location:</strong> {formData.location}
          </Typography>
        </Grid>
        <Grid item xs={12} sm={6}>
          <Typography variant="subtitle1">
            <strong>Capacity:</strong> {formData.capacity}
          </Typography>
        </Grid>
        <Grid item xs={12} sm={6}>
          <Typography variant="subtitle1">
            <strong>Price per Day:</strong> ${formData.price}
          </Typography>
        </Grid>
        <Grid item xs={12}>
          <Typography variant="subtitle1">
            <strong>Description:</strong> {formData.description}
          </Typography>
        </Grid>
        <Grid item xs={12}>
          <Typography variant="subtitle1">
            <strong>Equipment:</strong> {formData.equipment?.join(", ")}
          </Typography>
        </Grid>
        <Grid item xs={12}>
          <Typography variant="subtitle1">
            <strong>Photos:</strong> {formData.photos?.map((p) => p.name).join(", ")}
          </Typography>
        </Grid>
        <Grid item xs={12}>
          <Typography variant="subtitle1">
            <strong>360 View URL:</strong> {formData.panoUrl}
          </Typography>
        </Grid>
      </Grid>
      <Grid container spacing={2} className="mt-4">
        <Grid item xs={6}>
          <Button fullWidth variant="contained" onClick={onBack}>
            Back
          </Button>
        </Grid>
        <Grid item xs={6}>
          <Button fullWidth variant="contained" color="primary" onClick={onSubmit}>
            Submit
          </Button>
        </Grid>
      </Grid>
    </Paper>
  );
};