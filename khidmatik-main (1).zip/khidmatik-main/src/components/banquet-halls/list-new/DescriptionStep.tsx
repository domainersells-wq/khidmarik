"use client";
import { useState } from "react";
import { TextField, Button, Grid } from "@mui/material";

export const DescriptionStep = ({ onNext, onBack }) => {
  const [description, setDescription] = useState("");

  const handleNext = () => {
    onNext({ description });
  };

  return (
    <Grid container spacing={2}>
      <Grid item xs={12}>
        <TextField
          label="Detailed Description"
          multiline
          rows={6}
          fullWidth
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
      </Grid>
      <Grid item xs={12} className="flex justify-between">
        <Button variant="contained" onClick={onBack}>
          Back
        </Button>
        <Button variant="contained" color="primary" onClick={handleNext}>
          Next
        </Button>
      </Grid>
    </Grid>
  );
};