"use client";
import { useState } from "react";
import {
  FormControl,
  FormLabel,
  FormGroup,
  FormControlLabel,
  Checkbox,
  Button,
  Grid,
} from "@mui/material";

const equipmentOptions = [
  "Sound System",
  "Projector",
  "Stage",
  "Dance Floor",
  "Kitchen Facilities",
  "Air Conditioning",
  "Heating",
  "Wi-Fi",
  "Parking",
];

export const EquipmentStep = ({ onNext, onBack }) => {
  const [equipment, setEquipment] = useState([]);

  const handleCheckboxChange = (event) => {
    const { name, checked } = event.target;
    if (checked) {
      setEquipment((prev) => [...prev, name]);
    } else {
      setEquipment((prev) => prev.filter((item) => item !== name));
    }
  };

  const handleNext = () => {
    onNext({ equipment });
  };

  return (
    <Grid container spacing={2}>
      <Grid item xs={12}>
        <FormControl component="fieldset">
          <FormLabel component="legend">
            Select Available Equipment and Amenities
          </FormLabel>
          <FormGroup>
            {equipmentOptions.map((option) => (
              <FormControlLabel
                key={option}
                control={
                  <Checkbox
                    checked={equipment.includes(option)}
                    onChange={handleCheckboxChange}
                    name={option}
                  />
                }
                label={option}
              />
            ))}
          </FormGroup>
        </FormControl>
      </Grid>
      <Grid item xs={12} className="flex justify-between">
        <Button variant="contained" onClick={onBack}>
          Back
        </Button>
        <Button variant="contained" color="primary" onClick={handleNext}>
          Next
        </Button>
      </Grid>
    </Grid>
  );
};