"use client";
import { useState } from "react";
import { Button, Grid, TextField, Input } from "@mui/material";

export const MultimediaStep = ({ onNext, onBack }) => {
  const [photos, setPhotos] = useState([]);
  const [panoUrl, setPanoUrl] = useState("");

  const handlePhotoChange = (event) => {
    setPhotos([...event.target.files]);
  };

  const handleNext = () => {
    onNext({ photos, panoUrl });
  };

  return (
    <Grid container spacing={2}>
      <Grid item xs={12}>
        <label htmlFor="photo-upload">
          <Input
            id="photo-upload"
            type="file"
            multiple
            onChange={handlePhotoChange}
            style={{ display: "none" }}
          />
          <Button variant="contained" component="span">
            Upload Photos
          </Button>
        </label>
        {photos.length > 0 && (
          <div className="mt-2">
            {photos.map((photo, index) => (
              <p key={index}>{photo.name}</p>
            ))}
          </div>
        )}
      </Grid>
      <Grid item xs={12}>
        <TextField
          label="360-Degree Panoramic View URL"
          fullWidth
          value={panoUrl}
          onChange={(e) => setPanoUrl(e.target.value)}
        />
      </Grid>
      <Grid item xs={12} className="flex justify-between">
        <Button variant="contained" onClick={onBack}>
          Back
        </Button>
        <Button variant="contained" color="primary" onClick={handleNext}>
          Next
        </Button>
      </Grid>
    </Grid>
  );
};