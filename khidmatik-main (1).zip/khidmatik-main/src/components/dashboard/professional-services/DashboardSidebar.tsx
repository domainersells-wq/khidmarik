
'use client';

import Link from 'next/link';
import { usePathname, useSearchParams } from 'next/navigation';
import { cn } from '@/lib/utils';
import { Button, buttonVariants } from '@/components/ui/button';
import {
  LayoutDashboard,
  UserCheck,
  ClipboardList,
  Users,
  MessageSquareWarning,
  ChevronLeft,
  ShieldCheck,
  UserCircle,
  CalendarClock,
  Briefcase,
  DollarSign,
  Megaphone,
  LineChart,
  Settings,
  MessagesSquare, // For Communication
} from 'lucide-react';
import { AppLogo } from '@/components/layout/AppLogo';

interface ProfessionalServicesDashboardSidebarProps {
  onLinkClick?: () => void;
}

const navItems = [
  { href: 'profile-modules', label: 'Public Profile', icon: UserCircle },
  { href: 'verification', label: 'Verification & Badges', icon: UserCheck },
  { href: 'service-management', label: 'Service Management', icon: Briefcase },
  { href: 'bookings-calendar', label: 'Bookings & Calendar', icon: CalendarClock },
  { href: 'project-management', label: 'Projects & Orders', icon: ClipboardList },
  { href: 'marketing-promotions', label: 'Marketing & Promotions', icon: Megaphone },
  { href: 'earnings-payouts', label: 'Earnings & Payouts', icon: DollarSign },
  { href: 'client-communication', label: 'Client Communication', icon: MessagesSquare },
  { href: 'analytics', label: 'Performance Analytics', icon: LineChart },
  { href: 'settings-integrations', label: 'Settings & Integrations', icon: Settings },
  { href: 'support', label: 'Help & Support', icon: MessageSquareWarning },
];

export function ProfessionalServicesDashboardSidebar({ onLinkClick }: ProfessionalServicesDashboardSidebarProps) {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const currentSection = searchParams.get('section') || 'profile-modules'; // Default to profile

  return (
    <aside className="fixed inset-y-0 left-0 z-10 flex h-full w-64 flex-col border-r bg-card text-card-foreground shadow-md">
      <div className="flex h-16 items-center border-b px-6">
        <Link href="/dashboard/professional-services" className="flex items-center gap-2 font-semibold" onClick={onLinkClick}>
          <ShieldCheck className="h-7 w-7 text-primary" />
          <span className="text-lg">Services Admin</span>
        </Link>
      </div>
      <nav className="flex-1 overflow-auto py-4 px-4 text-sm font-medium">
        <ul className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentSection === item.href;
            return (
              <li key={item.href}>
                <Link
                  href={`/dashboard/professional-services?section=${item.href}`}
                  className={cn(
                    buttonVariants({ variant: isActive ? 'default' : 'ghost', size: 'sm' }), // smaller size
                    'w-full justify-start h-9', // explicit height
                    isActive && 'bg-primary text-primary-foreground hover:bg-primary/90 hover:text-primary-foreground'
                  )}
                  onClick={onLinkClick}
                >
                  <Icon className="mr-2 h-4 w-4" /> {/* smaller icon */}
                  {item.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
      <div className="mt-auto border-t p-4">
        <Button variant="outline" className="w-full justify-start" asChild>
          <Link href="/">
            <ChevronLeft className="mr-2 h-4 w-4" /> Back to Main Site
          </Link>
        </Button>
      </div>
    </aside>
  );
}
