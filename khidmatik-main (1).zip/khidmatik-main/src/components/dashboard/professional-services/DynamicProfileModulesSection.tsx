
'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { UserCircle, Briefcase, Image as ImageIcon, Video, FileText as FileTextIcon, Star, Link2, Edit3, UploadCloud, Eye, Award } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export function DynamicProfileModulesSection() {
  const { toast } = useToast();

  const handleGenericAction = (actionName: string) => {
    toast({
      title: `${actionName} (Conceptual)`,
      description: `This action would open an interface to manage ${actionName.toLowerCase()}.`,
    });
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold font-headline flex items-center">
          <UserCircle className="mr-3 h-8 w-8 text-primary" /> My Public Profile
        </h1>
        <p className="text-muted-foreground">Manage and customize how clients see your professional profile.</p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><Briefcase className="mr-2 h-5 w-5 text-primary"/> Profile Information</CardTitle>
          <CardDescription>Update core details displayed on your public profile. This is how clients find you.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="fullName">Full Name (As Displayed)</Label>
            <Input id="fullName" placeholder="e.g., Dr. Amine Khelifa / Artisanat Algérie Moderne" disabled defaultValue="My Professional Name"/>
          </div>
          <div>
            <Label htmlFor="professionalTitle">Professional Title / Tagline</Label>
            <Input id="professionalTitle" placeholder="e.g., Expert Plumber / Award-Winning Designer" disabled defaultValue="Specialized Service Provider"/>
          </div>
          <div>
            <Label htmlFor="specialization">Industry / Specialization Field</Label>
            <Input id="specialization" placeholder="e.g., Residential Plumbing / Logo & Brand Identity Design" disabled defaultValue="My Specialization"/>
          </div>
           <div>
            <Label htmlFor="profileBio">Short Bio / About Me</Label>
            <Textarea id="profileBio" placeholder="Describe your experience, skills, and what makes your service unique." rows={4} disabled defaultValue="Passionate professional with 10+ years of experience..."/>
          </div>
        </CardContent>
        <CardFooter>
            <Button onClick={() => handleGenericAction('Profile Information')}>
                <Edit3 className="mr-2 h-4 w-4" /> Edit Profile Info
            </Button>
        </CardFooter>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><ImageIcon className="mr-2 h-5 w-5 text-primary"/> Profile Photo & Branding</CardTitle>
          <CardDescription>Manage profile picture and optional cover image for your profile page.</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col sm:flex-row gap-4">
            <Button onClick={() => handleGenericAction('Profile Photo')} variant="outline" className="flex-1" disabled>
                <UploadCloud className="mr-2 h-4 w-4" /> Upload/Change Profile Photo
            </Button>
            <Button onClick={() => handleGenericAction('Cover Image')} variant="outline" className="flex-1" disabled>
                <UploadCloud className="mr-2 h-4 w-4" /> Upload/Change Cover Image
            </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><Award className="mr-2 h-5 w-5 text-primary"/> My Badges</CardTitle>
          <CardDescription>View badges earned on the platform (e.g., Verified, Top Rated). Some badges are automatically assigned based on verification and performance.</CardDescription>
        </CardHeader>
        <CardContent>
            <p className="text-sm text-muted-foreground mb-3">
                Conceptual: Your earned badges like "ID Verified", "Top Rated Professional", or "Quick Responder" would be displayed here.
            </p>
        </CardContent>
      </Card>


      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><FileTextIcon className="mr-2 h-5 w-5 text-primary"/> Portfolio Management</CardTitle>
          <CardDescription>Showcase your work through images, videos, and PDF case studies. High-quality portfolio items attract more clients.</CardDescription>
        </CardHeader>
        <CardContent>
            <p className="text-sm text-muted-foreground mb-3">
                Upload and manage items in your portfolio. Include titles, descriptions, and relevant media.
            </p>
           <ul className="list-disc list-inside text-sm space-y-1 text-muted-foreground mb-3">
                <li>Supports images (JPG, PNG), videos (MP4, YouTube/Vimeo links), and PDFs.</li>
                <li>Categorize portfolio items for easier browsing.</li>
            </ul>
        </CardContent>
         <CardFooter>
            <Button onClick={() => handleGenericAction('Portfolio Items')} disabled>
                <Edit3 className="mr-2 h-4 w-4" /> Manage Portfolio Items
            </Button>
        </CardFooter>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><Star className="mr-2 h-5 w-5 text-primary"/> My Public Reviews & Ratings</CardTitle>
          <CardDescription>View client feedback and manage your public reputation. Respond to reviews to engage with clients.</CardDescription>
        </CardHeader>
        <CardContent>
            <p className="text-sm text-muted-foreground mb-3">
                View all public reviews for your services. You can respond to reviews (feature coming soon). Inappropriate reviews can be flagged for admin moderation.
            </p>
        </CardContent>
        <CardFooter>
            <Button onClick={() => handleGenericAction('Reviews & Ratings')} disabled>
                <Eye className="mr-2 h-4 w-4" /> View & Respond to My Reviews
            </Button>
        </CardFooter>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><Link2 className="mr-2 h-5 w-5 text-primary"/> External Links</CardTitle>
          <CardDescription>Manage links to your personal website and professional social media profiles (e.g., LinkedIn, Behance).</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
            <div>
                <Label htmlFor="personalWebsite">Personal Website / Portfolio URL</Label>
                <Input id="personalWebsite" placeholder="https://www.example.com" disabled />
            </div>
            <div>
                <Label htmlFor="linkedinProfile">LinkedIn Profile URL</Label>
                <Input id="linkedinProfile" placeholder="https://www.linkedin.com/in/username" disabled />
            </div>
            <div>
                <Label htmlFor="otherPortfolio">Behance / Dribbble / Other Portfolio URL</Label>
                <Input id="otherPortfolio" placeholder="https://www.behance.net/username" disabled />
            </div>
        </CardContent>
         <CardFooter>
            <Button onClick={() => handleGenericAction('External Links')} disabled>
                <Edit3 className="mr-2 h-4 w-4" /> Update External Links
            </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
