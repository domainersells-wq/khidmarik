
'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Eye, BarChart3, Users, ShoppingCart, TrendingUp, TrendingDown, CalendarDays, Download, Star } from 'lucide-react';
import Image from 'next/image'; // For chart placeholders
import { useToast } from '@/hooks/use-toast';

// Mock Data (Conceptual)
const mockAnalyticsSummary = {
  profileViews: { value: 1250, trend: 15, period: 'last 30 days' },
  serviceViews: { value: 3480, trend: -5, period: 'last 30 days' },
  contactRequests: { value: 85, trend: 20, period: 'last 30 days' },
  conversionRate: { value: 12.5, unit: '%', trend: 2, period: 'last 30 days' }, // e.g. contact requests / profile views
};

const mockPopularServices = [
  { id: 'svc1', name: 'Emergency Plumbing Repair', views: 800, bookings: 40 },
  { id: 'svc2', name: 'Custom Logo Design Package', views: 650, bookings: 25 },
  { id: 'svc_other', name: 'General Consultation', views: 500, bookings: 15 },
];

export function ProviderAnalyticsSection() {
  const { toast } = useToast();

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold font-headline flex items-center">
          <BarChart3 className="mr-3 h-8 w-8 text-primary" /> My Performance Analytics
        </h1>
        <p className="text-muted-foreground">Track visits, engagement, and the popularity of your services.</p>
      </header>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Profile Views</CardTitle><Eye className="h-4 w-4 text-muted-foreground" /></CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockAnalyticsSummary.profileViews.value.toLocaleString()}</div>
            <p className={`text-xs flex items-center ${mockAnalyticsSummary.profileViews.trend >= 0 ? 'text-green-600' : 'text-destructive'}`}>
              {mockAnalyticsSummary.profileViews.trend >= 0 ? <TrendingUp className="h-3 w-3 mr-1"/> : <TrendingDown className="h-3 w-3 mr-1"/>}
              {mockAnalyticsSummary.profileViews.trend}% ({mockAnalyticsSummary.profileViews.period})
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Total Service Views</CardTitle><Eye className="h-4 w-4 text-muted-foreground" /></CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockAnalyticsSummary.serviceViews.value.toLocaleString()}</div>
             <p className={`text-xs flex items-center ${mockAnalyticsSummary.serviceViews.trend >= 0 ? 'text-green-600' : 'text-destructive'}`}>
              {mockAnalyticsSummary.serviceViews.trend >= 0 ? <TrendingUp className="h-3 w-3 mr-1"/> : <TrendingDown className="h-3 w-3 mr-1"/>}
              {mockAnalyticsSummary.serviceViews.trend}% ({mockAnalyticsSummary.serviceViews.period})
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Contact/Booking Requests</CardTitle><Users className="h-4 w-4 text-muted-foreground" /></CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockAnalyticsSummary.contactRequests.value}</div>
            <p className={`text-xs flex items-center ${mockAnalyticsSummary.contactRequests.trend >= 0 ? 'text-green-600' : 'text-destructive'}`}>
              {mockAnalyticsSummary.contactRequests.trend >= 0 ? <TrendingUp className="h-3 w-3 mr-1"/> : <TrendingDown className="h-3 w-3 mr-1"/>}
              {mockAnalyticsSummary.contactRequests.trend}% ({mockAnalyticsSummary.contactRequests.period})
            </p>
          </CardContent>
        </Card>
         <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Conversion Rate</CardTitle><Star className="h-4 w-4 text-muted-foreground" /></CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockAnalyticsSummary.conversionRate.value.toFixed(1)}{mockAnalyticsSummary.conversionRate.unit}</div>
            <p className={`text-xs flex items-center ${mockAnalyticsSummary.conversionRate.trend >= 0 ? 'text-green-600' : 'text-destructive'}`}>
              {mockAnalyticsSummary.conversionRate.trend >= 0 ? <TrendingUp className="h-3 w-3 mr-1"/> : <TrendingDown className="h-3 w-3 mr-1"/>}
              {mockAnalyticsSummary.conversionRate.trend}% ({mockAnalyticsSummary.conversionRate.period})
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
            <CardTitle className="flex items-center"><TrendingUp className="mr-2 h-5 w-5 text-primary"/>Profile & Service View Trends</CardTitle>
            <CardDescription>Visualize how your profile and service views have changed over time.</CardDescription>
        </CardHeader>
        <CardContent className="h-[300px] flex items-center justify-center bg-muted/30 rounded-md">
             <Image src="https://placehold.co/600x300.png" alt="Profile Views Chart" width={600} height={300} data-ai-hint="line chart views" className="opacity-70"/>
        </CardContent>
         <CardFooter className="pt-4 flex justify-between items-center">
            <div className="flex gap-2">
                <Button variant="outline" size="sm" disabled><CalendarDays className="mr-2 h-4 w-4"/>Date Range</Button>
            </div>
            <Button variant="outline" size="sm" disabled><Download className="mr-2 h-4 w-4"/>Export Data</Button>
        </CardFooter>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><ShoppingCart className="mr-2 h-5 w-5 text-primary"/>Most Popular Services</CardTitle>
          <CardDescription>Identify which of your services are attracting the most attention and bookings.</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Service Name</TableHead>
                <TableHead className="text-right">Views</TableHead>
                <TableHead className="text-right">Bookings/Leads</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mockPopularServices.map(service => (
                <TableRow key={service.id}>
                  <TableCell className="font-medium">{service.name}</TableCell>
                  <TableCell className="text-right">{service.views.toLocaleString()}</TableCell>
                  <TableCell className="text-right">{service.bookings.toLocaleString()}</TableCell>
                </TableRow>
              ))}
               {mockPopularServices.length === 0 && (
                <TableRow><TableCell colSpan={3} className="text-center text-muted-foreground py-4">No service data available yet.</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
