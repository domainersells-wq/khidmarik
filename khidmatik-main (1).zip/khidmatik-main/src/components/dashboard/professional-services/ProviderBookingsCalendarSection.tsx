
'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar'; // ShadCN Calendar
import { useState } from 'react';
import { CalendarClock, Settings, AlertTriangle, CheckCircle, XCircle, Eye } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { format, addDays, setHours, setMinutes } from 'date-fns';

// Mock conceptual appointments
const mockAppointments = [
  { id: 'app1', clientName: 'Amina B.', service: 'Consultation Call', date: setMinutes(setHours(addDays(new Date(), 1), 10),0), status: 'Confirmed', notes: 'Discuss project scope.' },
  { id: 'app2', clientName: 'Karim L.', service: 'On-site Visit', date: setMinutes(setHours(addDays(new Date(), 2), 14),30), status: 'Pending Client Confirmation', notes: 'Site assessment.' },
  { id: 'app3', clientName: 'Yasmine D.', service: 'Digital Audit Review', date: setMinutes(setHours(addDays(new Date(), 3), 9),0), status: 'Confirmed', notes: '' },
];


export function ProviderBookingsCalendarSection() {
  const { toast } = useToast();
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());

  const handleDateSelect = (date: Date | undefined) => {
    setSelectedDate(date);
    // Conceptual: Fetch appointments for this date
    toast({ title: "Date Selected (Conceptual)", description: `Displaying appointments for ${date ? format(date, 'PPP') : 'selected date'}.` });
  };

  const handleConfirmAppointment = (appointmentId: string) => {
    toast({ title: "Appointment Confirmed (Conceptual)", description: `Appointment ${appointmentId} marked as confirmed.`});
  };
  const handleCancelAppointment = (appointmentId: string) => {
    toast({ title: "Appointment Cancelled (Conceptual)", description: `Appointment ${appointmentId} marked as cancelled. Client notified.`});
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold font-headline flex items-center">
          <CalendarClock className="mr-3 h-8 w-8 text-primary" /> Bookings & Calendar
        </h1>
        <p className="text-muted-foreground">Manage your appointments, availability, and client bookings.</p>
      </header>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>My Calendar</CardTitle>
            </CardHeader>
            <CardContent className="flex justify-center">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={handleDateSelect}
                className="rounded-md border p-0" 
                // Conceptual: Add event indicators here later if desired
              />
            </CardContent>
             <CardFooter>
                 <Button variant="outline" className="w-full" onClick={() => toast({title:"Manage Availability (Conceptual)", description:"Opening settings for working hours, buffer times, holidays."})} disabled>
                    <Settings className="mr-2 h-4 w-4"/> Manage Availability
                </Button>
             </CardFooter>
          </Card>
        </div>

        <div className="md:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Appointments for {selectedDate ? format(selectedDate, 'PPP') : 'Today'}</CardTitle>
              <CardDescription>Review and manage your scheduled appointments for the selected date.</CardDescription>
            </CardHeader>
            <CardContent>
              {/* Conceptual: List of appointments for the selected date */}
              {mockAppointments.filter(a => selectedDate && format(a.date, 'yyyy-MM-dd') === format(selectedDate, 'yyyy-MM-dd')).length > 0 ? (
                <Table>
                    <TableHeader><TableRow><TableHead>Time</TableHead><TableHead>Client</TableHead><TableHead>Service</TableHead><TableHead>Status</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
                    <TableBody>
                        {mockAppointments.filter(a => selectedDate && format(a.date, 'yyyy-MM-dd') === format(selectedDate, 'yyyy-MM-dd')).map(appt => (
                            <TableRow key={appt.id}>
                                <TableCell>{format(appt.date, 'p')}</TableCell>
                                <TableCell>{appt.clientName}</TableCell>
                                <TableCell>{appt.service}</TableCell>
                                <TableCell><Badge variant={appt.status === 'Confirmed' ? 'default' : 'secondary'} className={appt.status === 'Confirmed' ? 'bg-green-500 text-white' : ''}>{appt.status}</Badge></TableCell>
                                <TableCell className="text-right space-x-1">
                                    <Button variant="ghost" size="icon" onClick={() => toast({title: `Viewing ${appt.id}`})}><Eye className="h-4 w-4"/></Button>
                                    {appt.status === 'Pending Client Confirmation' && <Button variant="ghost" size="icon" onClick={() => handleConfirmAppointment(appt.id)} className="text-green-600"><CheckCircle className="h-4 w-4"/></Button>}
                                    {appt.status !== 'Cancelled' && <Button variant="ghost" size="icon" onClick={() => handleCancelAppointment(appt.id)} className="text-destructive"><XCircle className="h-4 w-4"/></Button>}
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
              ) : (
                <p className="text-muted-foreground text-center py-8">No appointments scheduled for this date.</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      <Card className="bg-yellow-50 border-yellow-200 text-yellow-800">
        <CardHeader>
          <CardTitle className="flex items-center"><AlertTriangle className="mr-2 h-5 w-5"/> Integration Note</CardTitle>
        </CardHeader>
        <CardContent className="text-sm">
          <p>Conceptual: Integrate with Google Calendar for two-way sync of your availability and appointments. Set up your Khidmatik calendar preferences in <Button variant="link" size="sm" className="p-0 h-auto text-yellow-800 hover:text-yellow-900" onClick={() => toast({title:"Navigate to Settings (Conceptual)", description:"Going to Integrations tab in Settings."})} disabled>Settings &gt; Integrations</Button>.</p>
        </CardContent>
      </Card>
    </div>
  );
}
