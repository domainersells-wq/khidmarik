
'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { MessagesSquare, Send, Archive, Search, Filter, Bell, Settings2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';

// Mock Data
const mockConversations = [
    { id: 'conv1', clientName: 'Amina B.', lastMessage: "Thanks for the quick response!", timestamp: "2h ago", unread: true, service: "Project Alpha" },
    { id: 'conv2', clientName: 'Karim L.', lastMessage: "Can we schedule a follow-up call?", timestamp: "1 day ago", unread: false, service: "Consulting Session" },
    { id: 'conv3', clientName: 'Yasmine D.', lastMessage: "Payment sent. Please confirm.", timestamp: "3 days ago", unread: false, service: "Digital Audit" },
];

export function ProviderCommunicationSection() {
  const { toast } = useToast();

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold font-headline flex items-center">
          <MessagesSquare className="mr-3 h-8 w-8 text-primary" /> Client Communication
        </h1>
        <p className="text-muted-foreground">Manage messages, track conversations, and stay connected with your clients.</p>
      </header>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Conversation List */}
        <Card className="md:col-span-1">
          <CardHeader>
            <CardTitle>My Conversations</CardTitle>
            <div className="flex gap-1 mt-1">
                <Input placeholder="Search messages..." className="h-8" disabled/>
                <Button variant="ghost" size="icon" disabled><Filter className="h-4 w-4"/></Button>
            </div>
          </CardHeader>
          <CardContent className="max-h-[500px] overflow-y-auto p-2 space-y-2">
            {mockConversations.map(conv => (
              <div key={conv.id} className={`p-3 rounded-md cursor-pointer hover:bg-muted/70 ${conv.unread ? 'bg-primary/10 border border-primary/30' : 'bg-muted/30'}`} onClick={() => toast({title:`Opening chat with ${conv.clientName}`})}>
                <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                        <Avatar className="h-8 w-8"><AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${conv.clientName}`} /><AvatarFallback>{conv.clientName.substring(0,1)}</AvatarFallback></Avatar>
                        <span className="font-semibold text-sm">{conv.clientName}</span>
                    </div>
                    {conv.unread && <Badge variant="destructive" className="h-5 px-1.5 text-xs">New</Badge>}
                </div>
                <p className="text-xs text-muted-foreground truncate mt-1">{conv.lastMessage}</p>
                <p className="text-xs text-muted-foreground/80 mt-0.5">{conv.timestamp} - {conv.service}</p>
              </div>  
            ))}
            {mockConversations.length === 0 && <p className="text-sm text-muted-foreground text-center py-4">No active conversations.</p>}
          </CardContent>
        </Card>

        {/* Chat Window (Conceptual) */}
        <Card className="md:col-span-2 flex flex-col">
          <CardHeader className="flex flex-row justify-between items-center border-b">
            <div>
                <CardTitle>Chat with Amina B. (Project Alpha)</CardTitle>
                <CardDescription>Real-time messaging with your client.</CardDescription>
            </div>
            <Button variant="ghost" size="icon" disabled><Archive className="h-5 w-5"/></Button>
          </CardHeader>
          <CardContent className="flex-grow overflow-y-auto p-4 space-y-3 bg-background">
            {/* Mock messages */}
            <div className="flex justify-end"><div className="bg-primary text-primary-foreground p-2 rounded-lg max-w-[70%] text-sm">Hello Amina, just checking in on Project Alpha.</div></div>
            <div className="flex justify-start"><div className="bg-muted p-2 rounded-lg max-w-[70%] text-sm">Hi! Thanks for the quick response! Everything looks great so far.</div></div>
            <div className="text-center text-xs text-muted-foreground">--- Today ---</div>
             <div className="flex justify-end"><div className="bg-primary text-primary-foreground p-2 rounded-lg max-w-[70%] text-sm">Excellent! Let me know if you have any questions.</div></div>
          </CardContent>
          <CardFooter className="border-t p-3">
            <div className="flex w-full items-center gap-2">
              <Textarea placeholder="Type your message..." className="flex-grow resize-none h-10 min-h-[40px]" disabled/>
              <Button size="icon" disabled><Send className="h-5 w-5"/></Button>
            </div>
          </CardFooter>
        </Card>
      </div>

      <Card>
        <CardHeader>
            <CardTitle className="flex items-center"><Bell className="mr-2 h-5 w-5 text-primary"/>Notification Settings</CardTitle>
            <CardDescription>Manage how you receive alerts for new messages and client interactions.</CardDescription>
        </CardHeader>
        <CardContent>
            <p className="text-sm text-muted-foreground">Conceptual: Options for instant notifications, email summaries, and SMS alerts for urgent messages would be configured here (likely in main account settings).</p>
             <Button variant="outline" className="mt-2" onClick={() => toast({title:"Navigate to Settings (Conceptual)"})} disabled>
                <Settings2 className="mr-2 h-4 w-4"/> Go to Notification Settings
            </Button>
        </CardContent>
      </Card>
    </div>
  );
}
