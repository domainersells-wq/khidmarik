
'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { DollarSign, FileText, Download, Landmark, TrendingUp, AlertCircle, CreditCard, ExternalLink } from 'lucide-react'; // Added CreditCard
import { useToast } from '@/hooks/use-toast';
import Image from 'next/image'; // Added Image for chart placeholders

// Mock Data
const mockTransactions = [
  { id: 'txn_001', date: '2024-07-10', description: 'Payment for Project #PROJ002 (Leila A.)', type: 'Service Payment', amount: 15000, status: 'Paid', invoiceId: 'INV001' },
  { id: 'txn_002', date: '2024-07-05', description: 'Platform Commission (Project #PROJ002)', type: 'Commission', amount: -1500, status: 'Deducted', invoiceId: 'INV001' },
  { id: 'txn_003', date: '2024-06-28', description: 'Withdrawal Request', type: 'Payout', amount: -12000, status: 'Pending', invoiceId: 'WD001' },
  { id: 'txn_004', date: '2024-06-15', description: 'Payment for Project #PROJ001 (Omar K.) - Deposit', type: 'Service Payment', amount: 25000, status: 'Paid', invoiceId: 'INV002' },
  { id: 'txn_005', date: '2024-06-10', description: 'Platform Commission (Project #PROJ001)', type: 'Commission', amount: -2500, status: 'Deducted', invoiceId: 'INV002' },
];

const mockEarningsSummary = {
    totalEarned: 150000,
    pendingPayout: 12000,
    platformFees: 8000,
    lastPayoutDate: '2024-06-20',
};

export function ProviderEarningsSection() {
  const { toast } = useToast();

  const handleGenerateInvoice = (orderId: string) => {
    toast({ title: "Invoice Generated (Conceptual)", description: `PDF Invoice for ${orderId} would be downloaded.` });
  };
  
  const handleRequestWithdrawal = () => {
     toast({ title: "Withdrawal Request (Conceptual)", description: `This would open a modal to enter amount and select payout method.`});
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold font-headline flex items-center">
          <DollarSign className="mr-3 h-8 w-8 text-primary" /> Earnings & Payouts
        </h1>
        <p className="text-muted-foreground">Track your earnings, manage invoices, and request withdrawals.</p>
      </header>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Total Earned (All Time)</CardTitle></CardHeader>
          <CardContent><div className="text-2xl font-bold">{mockEarningsSummary.totalEarned.toLocaleString()} DA</div></CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Pending Payout</CardTitle></CardHeader>
          <CardContent><div className="text-2xl font-bold">{mockEarningsSummary.pendingPayout.toLocaleString()} DA</div></CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Platform Fees (Month)</CardTitle></CardHeader>
          <CardContent><div className="text-2xl font-bold">{mockEarningsSummary.platformFees.toLocaleString()} DA</div></CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Last Payout</CardTitle></CardHeader>
          <CardContent><div className="text-xl font-semibold">{mockEarningsSummary.lastPayoutDate}</div></CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
            <CardTitle className="flex items-center"><TrendingUp className="mr-2 h-5 w-5 text-primary"/>Earnings Report</CardTitle>
            <CardDescription>Visualize your daily and monthly earnings. (Conceptual Charts)</CardDescription>
        </CardHeader>
        <CardContent className="grid md:grid-cols-2 gap-4">
            <div className="h-[250px] flex items-center justify-center bg-muted/30 rounded-md">
                <Image src="https://placehold.co/400x250.png" alt="Daily Earnings Chart" width={400} height={250} data-ai-hint="line chart earnings" className="opacity-70"/>
            </div>
            <div className="h-[250px] flex items-center justify-center bg-muted/30 rounded-md">
                <Image src="https://placehold.co/400x250.png" alt="Monthly Earnings Chart" width={400} height={250} data-ai-hint="bar chart earnings" className="opacity-70"/>
            </div>
        </CardContent>
         <CardFooter>
            <Button variant="outline" disabled><Download className="mr-2 h-4 w-4"/> Export Earnings Data</Button>
        </CardFooter>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><FileText className="mr-2 h-5 w-5 text-primary"/>Transaction History & Invoices</CardTitle>
          <CardDescription>View all payments, commissions, and generate invoices.</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Type</TableHead>
                <TableHead className="text-right">Amount (DA)</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Invoice</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mockTransactions.map(txn => (
                <TableRow key={txn.id}>
                  <TableCell>{txn.date}</TableCell>
                  <TableCell className="font-medium">{txn.description}</TableCell>
                  <TableCell><Badge variant={txn.type === 'Service Payment' ? 'outline' : txn.type === 'Commission' ? 'secondary' : 'default'} className={txn.type === 'Payout' ? 'bg-blue-500 text-white' : ''}>{txn.type}</Badge></TableCell>
                  <TableCell className={`text-right ${txn.amount < 0 ? 'text-destructive' : 'text-green-600'}`}>{txn.amount.toLocaleString()}</TableCell>
                  <TableCell><Badge variant={txn.status === 'Paid' || txn.status === 'Deducted' ? 'default' : 'secondary'} className={txn.status === 'Paid' || txn.status === 'Deducted' ? 'bg-green-500 text-white' : ''}>{txn.status}</Badge></TableCell>
                  <TableCell className="text-right">
                    {txn.type === 'Service Payment' && <Button variant="ghost" size="icon" onClick={() => handleGenerateInvoice(txn.invoiceId)}><Download className="h-4 w-4"/></Button>}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
            <CardTitle className="flex items-center"><Landmark className="mr-2 h-5 w-5 text-primary"/>Withdrawal System</CardTitle>
            <CardDescription>Request payouts to your bank account or other supported methods.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
            <p className="text-sm text-muted-foreground">Current Payout Method: <strong>Bank Transfer - BNA ending in ****1234</strong> (Conceptual)</p>
            <Button onClick={handleRequestWithdrawal} className="w-full sm:w-auto" disabled><DollarSign className="mr-2 h-4 w-4"/>Request New Withdrawal</Button>
            <Button variant="outline" className="w-full sm:w-auto" onClick={() => toast({title:"Manage Payout Methods (Conceptual)", description:"Add/edit bank accounts or PayPal (when available)."}) } disabled>
                <CreditCard className="mr-2 h-4 w-4"/> Manage Payout Methods
            </Button>
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-md text-blue-700 text-xs flex items-start gap-2 mt-2">
                <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
                <span>
                    Platform commissions are automatically calculated and deducted before payouts. Standard payout processing time is 3-5 business days.
                </span>
            </div>
        </CardContent>
      </Card>

    </div>
  );
}
