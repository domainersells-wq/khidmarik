
'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Megaphone, Ticket, Percent, Users, PlusCircle, PackagePlus, CalendarDays, Settings2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useState } from 'react';

export function ProviderMarketingSection() {
  const { toast } = useToast();
  const [couponCode, setCouponCode] = useState('');
  const [discountType, setDiscountType] = useState('percentage');
  const [discountValue, setDiscountValue] = useState('');

  const handleCreateCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    toast({ title: "Coupon Created (Conceptual)", description: `Coupon "${couponCode}" with ${discountValue}${discountType === 'percentage' ? '%' : ' DA'} off created.`});
    setCouponCode('');
    setDiscountValue('');
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold font-headline flex items-center">
          <Megaphone className="mr-3 h-8 w-8 text-primary" /> Marketing & Promotions
        </h1>
        <p className="text-muted-foreground">Boost your visibility and attract more clients with promotional tools.</p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><Ticket className="mr-2 h-5 w-5 text-primary"/> Discount Coupons & Promo Codes</CardTitle>
          <CardDescription>Create and manage discount codes for your services or service bundles.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleCreateCoupon} className="space-y-4 p-4 border rounded-md bg-muted/30">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="couponCode">Coupon Code</Label>
                <Input id="couponCode" value={couponCode} onChange={e => setCouponCode(e.target.value.toUpperCase())} placeholder="e.g., WELCOME10" disabled/>
              </div>
              <div>
                <Label htmlFor="discountType">Discount Type</Label>
                <Select value={discountType} onValueChange={setDiscountType} disabled>
                  <SelectTrigger id="discountType"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="percentage">Percentage (%)</SelectItem>
                    <SelectItem value="fixed">Fixed Amount (DA)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="discountValue">Value / Amount</Label>
                <Input id="discountValue" type="number" value={discountValue} onChange={e => setDiscountValue(e.target.value)} placeholder="e.g., 10 or 500" disabled/>
              </div>
            </div>
            {/* Conceptual: More options like usage limits, expiry dates, applicable services */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                <div>
                    <Label htmlFor="couponExpiry">Expiry Date (Optional)</Label>
                    <Input id="couponExpiry" type="date" disabled/>
                </div>
                 <div>
                    <Label htmlFor="couponUsageLimit">Usage Limit (Optional)</Label>
                    <Input id="couponUsageLimit" type="number" placeholder="e.g., 100 (0 for unlimited)" disabled/>
                </div>
            </div>
            <Button type="submit" className="w-full md:w-auto" disabled><PlusCircle className="mr-2 h-4 w-4" /> Create Coupon</Button>
          </form>
          <div className="mt-4">
            <h4 className="font-semibold mb-2">Existing Coupons (Conceptual)</h4>
            <p className="text-sm text-muted-foreground">A list of active and past coupons with edit/delete options would appear here.</p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><PackagePlus className="mr-2 h-5 w-5 text-primary"/> Discounted Service Packages / Bundles</CardTitle>
          <CardDescription>Create special offers by bundling multiple services at a discounted rate.</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            Conceptual: Tools to select multiple existing services, define a bundle price, and describe the offer.
            You would manage these bundles within the "Service Management" section.
          </p>
        </CardContent>
        <CardFooter>
            <Button variant="outline" onClick={() => toast({title:"Navigate to Service Management (Conceptual)", description:"Manage bundles under each service or a dedicated bundles tab."})} disabled>
                <Settings2 className="mr-2 h-4 w-4"/> Manage Service Bundles
            </Button>
        </CardFooter>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><Users className="mr-2 h-5 w-5 text-primary"/> Client Targeting (Conceptual)</CardTitle>
          <CardDescription>Future: Tools to run targeted promotions to specific client segments (e.g., new clients, past clients).</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            This feature is planned and would allow for more personalized marketing efforts.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
