
'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { ClipboardList, Filter, Eye, CheckCircle, XCircle, RotateCcw, Send } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// Mock Data
const mockProjects = [
  { id: 'proj001', clientName: 'Omar K.', serviceName: 'Full Website Redesign', startDate: '2024-06-15', deadline: '2024-08-15', status: 'In Progress', paymentStatus: 'Partially Paid' },
  { id: 'proj002', clientName: 'Leila A.', serviceName: 'Emergency Plumbing Fix', startDate: '2024-07-10', deadline: '2024-07-10', status: 'Completed', paymentStatus: 'Paid' },
  { id: 'proj003', clientName: 'Yasmine S.', serviceName: 'Monthly SEO Consulting', startDate: '2024-07-01', deadline: 'Ongoing', status: 'In Progress', paymentStatus: 'Awaiting Payment' },
  { id: 'proj004', clientName: 'Ali B.', serviceName: 'Logo & Branding Package', startDate: '2024-05-20', deadline: '2024-06-30', status: 'Awaiting Client Feedback', paymentStatus: 'Paid' },
  { id: 'proj005', clientName: 'Sarah M.', serviceName: 'Kitchen Renovation', startDate: '2024-08-01', deadline: '2024-09-30', status: 'Scheduled', paymentStatus: 'Deposit Paid' },
];

export function ProviderProjectManagementSection() {
  const { toast } = useToast();

  const handleUpdateStatus = (projectId: string, newStatus: string) => {
    toast({ title: "Status Updated (Conceptual)", description: `Project ${projectId} status changed to ${newStatus}.` });
  };

  const getStatusBadgeVariant = (status: string) => {
    if (status === 'Completed' || status === 'Paid') return 'default'; // Green like
    if (status === 'In Progress' || status === 'Partially Paid') return 'secondary'; // Yellow like
    if (status === 'Rejected' || status === 'Failed') return 'destructive';
    return 'outline';
  };


  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold font-headline flex items-center">
          <ClipboardList className="mr-3 h-8 w-8 text-primary" /> Projects & Orders Management
        </h1>
        <p className="text-muted-foreground">Track ongoing services, client projects, and order statuses.</p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle>Current Projects/Orders</CardTitle>
          <CardDescription>Manage the progress and status of your client engagements.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-2 mb-4">
            <Input placeholder="Search by Client or Service Name..." className="max-w-sm" disabled/>
            <Select disabled>
              <SelectTrigger className="w-full sm:w-[180px]">
                <Filter className="mr-2 h-4 w-4"/>
                <SelectValue placeholder="Filter by Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="in_progress">In Progress</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
                <SelectItem value="awaiting_client">Awaiting Client</SelectItem>
                <SelectItem value="scheduled">Scheduled</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Project/Order ID</TableHead>
                <TableHead>Client</TableHead>
                <TableHead>Service</TableHead>
                <TableHead>Deadline</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Payment</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mockProjects.map(project => (
                <TableRow key={project.id}>
                  <TableCell className="font-medium">{project.id}</TableCell>
                  <TableCell>{project.clientName}</TableCell>
                  <TableCell>{project.serviceName}</TableCell>
                  <TableCell>{project.deadline}</TableCell>
                  <TableCell>
                    <Badge variant={getStatusBadgeVariant(project.status)} className={project.status === "Completed" ? "bg-green-500 text-white" : project.status === "In Progress" ? "bg-blue-500 text-white" : ""}>
                        {project.status}
                    </Badge>
                  </TableCell>
                   <TableCell>
                    <Badge variant={getStatusBadgeVariant(project.paymentStatus)} className={project.paymentStatus === "Paid" ? "bg-green-500 text-white" : ""}>
                        {project.paymentStatus}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" onClick={() => toast({title: "View Details (Conceptual)"})}><Eye className="h-4 w-4"/></Button>
                    {project.status === 'In Progress' && <Button variant="ghost" size="icon" onClick={() => handleUpdateStatus(project.id, 'Completed')} className="text-green-600"><CheckCircle className="h-4 w-4"/></Button>}
                    {project.status === 'Awaiting Client Feedback' && <Button variant="ghost" size="icon" onClick={() => toast({title: "Send Reminder (Conceptual)"})} className="text-blue-600"><Send className="h-4 w-4"/></Button>}
                  </TableCell>
                </TableRow>
              ))}
              {mockProjects.length === 0 && (
                <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-4">No active projects or orders.</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Key Actions (Conceptual)</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Button variant="outline" disabled><CheckCircle className="mr-2 h-4 w-4"/> Mark as Completed</Button>
            <Button variant="outline" disabled><RotateCcw className="mr-2 h-4 w-4"/> Request Revision from Client</Button>
            <Button variant="outline" disabled><XCircle className="mr-2 h-4 w-4"/> Cancel/Reject Order</Button>
            <Button variant="outline" disabled><Send className="mr-2 h-4 w-4"/> Send Update to Client</Button>
        </CardContent>
      </Card>

    </div>
  );
}
