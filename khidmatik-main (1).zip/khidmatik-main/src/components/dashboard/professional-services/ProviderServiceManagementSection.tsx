
'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Briefcase, PlusCircle, Edit3, Trash2, ImageUp, Video, FileText as FileTextIcon, PackagePlus, CalendarDays, DollarSign, Settings2, Eye, ListFilter } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useState } from 'react';

// Mock Data (Conceptual)
const mockServices = [
    { id: 'svc1', name: 'Emergency Plumbing Repair', category: 'Manual Labor', price: '10,000 DA (starting)', status: 'Active', mediaCount: 2, bundles: 0 },
    { id: 'svc2', name: 'Custom Logo Design Package', category: 'Digital Service', price: '35,000 DA', status: 'Active', mediaCount: 5, bundles: 1 },
    { id: 'svc3', name: 'Business Strategy Consultation', category: 'Consulting', price: '50,000 DA / session', status: 'Draft', mediaCount: 0, bundles: 0 },
];
const serviceCategories = ['Digital Service', 'Manual Labor', 'Consulting', 'Training', 'Artistic Creation'];

export function ProviderServiceManagementSection() {
  const { toast } = useToast();
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingService, setEditingService] = useState<any | null>(null);

  const openForm = (service: any | null = null) => {
    setEditingService(service);
    setIsFormOpen(true);
  };

  const handleSubmitService = (e: React.FormEvent) => {
    e.preventDefault();
    toast({ title: `Service ${editingService ? 'Updated' : 'Created'} (Conceptual)`, description: "Service details saved."});
    setIsFormOpen(false);
  };

  const handleDeleteService = (serviceId: string) => {
    toast({ title: 'Service Deleted (Conceptual)', description: `Service ${serviceId} has been removed.`});
  };

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-center">
        <div>
            <h1 className="text-3xl font-bold font-headline flex items-center">
                <Briefcase className="mr-3 h-8 w-8 text-primary" /> My Services
            </h1>
            <p className="text-muted-foreground">Add, edit, and manage the services you offer to clients.</p>
        </div>
        <Button onClick={() => openForm(null)}>
            <PlusCircle className="mr-2 h-4 w-4" /> Add New Service
        </Button>
      </header>

      <Card>
        <CardHeader>
            <CardTitle>Your Service Listings</CardTitle>
            <CardDescription>Overview of your currently offered services.</CardDescription>
        </CardHeader>
        <CardContent>
            <div className="flex items-center gap-2 mb-4">
                <Input placeholder="Search services..." className="max-w-sm" />
                <Button variant="outline"><ListFilter className="mr-2 h-4 w-4"/>Filter</Button>
            </div>
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Service Name</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Base Price</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {mockServices.map(service => (
                        <TableRow key={service.id}>
                            <TableCell className="font-medium">{service.name}</TableCell>
                            <TableCell>{service.category}</TableCell>
                            <TableCell>{service.price}</TableCell>
                            <TableCell><Badge variant={service.status === 'Active' ? 'default' : 'secondary'} className={service.status === 'Active' ? 'bg-green-500 text-white' : ''}>{service.status}</Badge></TableCell>
                            <TableCell className="text-right">
                                <Button variant="ghost" size="icon" onClick={() => openForm(service)}><Edit3 className="h-4 w-4"/></Button>
                                <Button variant="ghost" size="icon" onClick={() => handleDeleteService(service.id)} className="text-destructive"><Trash2 className="h-4 w-4"/></Button>
                            </TableCell>
                        </TableRow>
                    ))}
                     {mockServices.length === 0 && (
                        <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-4">You haven't added any services yet.</TableCell></TableRow>
                    )}
                </TableBody>
            </Table>
        </CardContent>
      </Card>

      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] flex flex-col">
            <DialogHeader>
                <DialogTitle>{editingService ? 'Edit Service' : 'Add New Service'}</DialogTitle>
                <DialogDescription>Provide detailed information about the service you offer.</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmitService} className="space-y-4 overflow-y-auto p-1 flex-grow">
                <div><Label htmlFor="serviceNameForm">Service Name / Title *</Label><Input id="serviceNameForm" defaultValue={editingService?.name} placeholder="e.g., Advanced Plumbing Solutions, Custom Web Design" /></div>
                <div><Label htmlFor="serviceDescriptionForm">Detailed Description *</Label><Textarea id="serviceDescriptionForm" defaultValue={editingService?.description} placeholder="Describe what the service includes, benefits, process, etc." rows={4} /></div>
                <div>
                    <Label htmlFor="serviceCategoryForm">Service Category *</Label>
                    <Select defaultValue={editingService?.category} >
                        <SelectTrigger id="serviceCategoryForm"><SelectValue placeholder="Select a category..." /></SelectTrigger>
                        <SelectContent>{serviceCategories.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}</SelectContent>
                    </Select>
                </div>
                
                <Card className="p-3 bg-muted/30">
                    <h4 className="font-semibold text-sm mb-2 flex items-center"><DollarSign className="mr-1 h-4 w-4"/>Pricing Options *</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div><Label htmlFor="basePriceForm">Base Price (DA)</Label><Input id="basePriceForm" type="number" placeholder="e.g., 10000" defaultValue={editingService?.price?.match(/\d+/)?.[0]} /></div>
                        <div><Label htmlFor="priceUnitForm">Price Unit (Optional)</Label><Input id="priceUnitForm" placeholder="e.g., per hour, per project, per session" /></div>
                    </div>
                    <Button variant="link" size="sm" className="p-0 h-auto mt-2" onClick={() => toast({title:"Customize Pricing (Conceptual)", description:"Advanced options for tiered pricing, add-ons, etc."})} >+ Add Customizable Pricing Options</Button>
                </Card>

                <Card className="p-3 bg-muted/30">
                    <h4 className="font-semibold text-sm mb-2 flex items-center"><CalendarDays className="mr-1 h-4 w-4"/>Delivery & Schedule</h4>
                     <div><Label htmlFor="deliveryTimeForm">Estimated Delivery Time / Duration</Label><Input id="deliveryTimeForm" placeholder="e.g., 3-5 business days, 2 weeks, 1 hour session" /></div>
                    <Button variant="link" size="sm" className="p-0 h-auto mt-2" onClick={() => toast({title:"Delivery Schedule (Conceptual)", description:"Define working hours, buffer times, specific availability."})} >+ Set Delivery Schedule Options</Button>
                </Card>
                
                <Card className="p-3 bg-muted/30">
                    <h4 className="font-semibold text-sm mb-2">Media (Images, Videos, PDFs)</h4>
                    <div className="space-y-2">
                        <Button type="button" variant="outline" className="w-full justify-start" ><ImageUp className="mr-2 h-4 w-4"/> Upload Images (max 5)</Button>
                        <Button type="button" variant="outline" className="w-full justify-start" ><Video className="mr-2 h-4 w-4"/> Add Video Link (YouTube, Vimeo)</Button>
                        <Button type="button" variant="outline" className="w-full justify-start" ><FileTextIcon className="mr-2 h-4 w-4"/> Upload PDF Samples/Brochures</Button>
                    </div>
                </Card>
                
                <Card className="p-3 bg-muted/30">
                    <h4 className="font-semibold text-sm mb-2 flex items-center"><PackagePlus className="mr-1 h-4 w-4"/>Service Bundles / Packages</h4>
                    <p className="text-xs text-muted-foreground mb-2">Offer combined services at a special price.</p>
                    <Button type="button" variant="outline" className="w-full" ><PlusCircle className="mr-2 h-4 w-4"/> Create Service Bundle</Button>
                </Card>

            </form>
            <DialogFooter className="pt-4 border-t mt-2">
                <DialogClose asChild><Button type="button" variant="outline">Cancel</Button></DialogClose>
                <Button type="submit" onClick={handleSubmitService}>Save Service</Button>
            </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
