
'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Settings, Shield, Bell, Activity, Download, Trash2, Link2, AlertCircle, KeyRound } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Separator } from '@/components/ui/separator';

export function ProviderSettingsSection() {
  const { toast } = useToast();

  const handleGenericToggle = (featureName: string, enabled: boolean) => {
    toast({ title: `${featureName} ${enabled ? 'Enabled' : 'Disabled'} (Conceptual)` });
  };

  const handleGenericAction = (actionName: string, description?: string) => {
     toast({ title: `${actionName} (Conceptual)`, description: description || `This would ${actionName.toLowerCase()}.` });
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold font-headline flex items-center">
          <Settings className="mr-3 h-8 w-8 text-primary" /> Account Settings & Integrations
        </h1>
        <p className="text-muted-foreground">Manage your account security, data, notifications, and third-party integrations.</p>
      </header>

      {/* Security Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><Shield className="mr-2 h-5 w-5 text-primary"/>Security</CardTitle>
          <CardDescription>Manage your account security settings.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-3 border rounded-md">
            <div>
                <Label htmlFor="twoFactorAuth" className="font-medium">Two-Factor Authentication (2FA)</Label>
                <p className="text-xs text-muted-foreground">Enhance your account security by requiring a second form of verification.</p>
            </div>
            <Switch id="twoFactorAuth" onCheckedChange={(checked) => handleGenericToggle('2FA', checked)} />
          </div>
          <Button variant="outline" onClick={() => handleGenericAction("Change Password")} ><KeyRound className="mr-2 h-4 w-4"/>Change Password</Button>
        </CardContent>
      </Card>

      {/* Notification Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><Bell className="mr-2 h-5 w-5 text-primary"/>Notification Preferences</CardTitle>
          <CardDescription>Choose how you receive alerts for new messages, bookings, and platform updates.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
            <div className="flex items-center justify-between p-3 border rounded-md"><Label htmlFor="emailNotifs">Email Notifications for Bookings</Label><Switch id="emailNotifs" defaultChecked onCheckedChange={(checked) => handleGenericToggle('Email Notifications for Bookings', checked)} /></div>
            <div className="flex items-center justify-between p-3 border rounded-md"><Label htmlFor="smsNotifs">SMS Alerts for Urgent Matters</Label><Switch id="smsNotifs" onCheckedChange={(checked) => handleGenericToggle('SMS Alerts', checked)} /></div>
            <div className="flex items-center justify-between p-3 border rounded-md"><Label htmlFor="newMsgNotifs">In-App Notification for New Messages</Label><Switch id="newMsgNotifs" defaultChecked onCheckedChange={(checked) => handleGenericToggle('In-App New Message Notifications', checked)} /></div>
        </CardContent>
        <CardFooter>
             <Button onClick={() => handleGenericAction("Save Notification Settings")} >Save Notification Preferences</Button>
        </CardFooter>
      </Card>

      {/* Activity Log */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><Activity className="mr-2 h-5 w-5 text-primary"/>Activity Log</CardTitle>
          <CardDescription>Review recent activity on your account, such as logins and important changes.</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">Conceptual: A list of recent activities like logins from new devices, profile edits, service updates, etc., would be displayed here.</p>
        </CardContent>
         <CardFooter>
            <Button variant="outline" onClick={() => handleGenericAction("View Full Activity Log")} >View Full Activity Log</Button>
        </CardFooter>
      </Card>
      
      {/* Data Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><Download className="mr-2 h-5 w-5 text-primary"/>Data Management</CardTitle>
          <CardDescription>Download your data or request account deletion.</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col sm:flex-row gap-3">
          <Button variant="outline" className="flex-1" onClick={() => handleGenericAction("Download My Data", "A ZIP file containing your profile information, service listings, and communication history would be prepared for download.")} >
            <Download className="mr-2 h-4 w-4"/> Download My Data
          </Button>
          <Button variant="destructive" className="flex-1" onClick={() => handleGenericAction("Request Account Deletion", "This would initiate the account deletion process. This action is irreversible.")} >
            <Trash2 className="mr-2 h-4 w-4"/> Delete My Account
          </Button>
        </CardContent>
      </Card>
      
      {/* Third-Party Integrations */}
       <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><Link2 className="mr-2 h-5 w-5 text-primary"/>Third-Party Integrations</CardTitle>
          <CardDescription>Connect Khidmatik with other tools you use.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
            <div className="flex items-center justify-between p-3 border rounded-md">
                <Label htmlFor="googleCalendar">Google Calendar Sync (for schedule syncing)</Label>
                <Button variant="outline" size="sm" onClick={() => handleGenericAction("Connect Google Calendar")}>Connect</Button>
            </div>
             <div className="flex items-center justify-between p-3 border rounded-md">
                <Label htmlFor="canva">Canva (for professional content uploads)</Label>
                <Button variant="outline" size="sm" onClick={() => handleGenericAction("Connect Canva")}>Connect</Button>
            </div>
             <div className="flex items-center justify-between p-3 border rounded-md">
                <Label htmlFor="linkedin">LinkedIn Profile (for profile enhancement)</Label>
                <Button variant="outline" size="sm" onClick={() => handleGenericAction("Connect LinkedIn")}>Connect</Button>
            </div>
             <div className="flex items-center justify-between p-3 border rounded-md">
                <Label htmlFor="behance">Behance Profile (for portfolio enhancement)</Label>
                <Button variant="outline" size="sm" onClick={() => handleGenericAction("Connect Behance")}>Connect</Button>
            </div>
        </CardContent>
      </Card>

       {/* Terms & Policy Acceptance */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><AlertCircle className="mr-2 h-5 w-5 text-primary"/>Terms & Policies</CardTitle>
          <CardDescription>Review and accept platform terms and privacy policy.</CardDescription>
        </CardHeader>
        <CardContent>
            <p className="text-sm text-muted-foreground mb-3">
                Conceptual: You have accepted the Khidmatik Platform Terms of Service and Privacy Policy.
                If updates occur, you'll be prompted to review and accept them here before continuing to publish services.
            </p>
            <Button variant="link" size="sm" className="p-0 h-auto" onClick={() => toast({title: "View Terms (Conceptual)"})}>View Terms of Service</Button> <br/>
            <Button variant="link" size="sm" className="p-0 h-auto" onClick={() => toast({title: "View Privacy Policy (Conceptual)"})}>View Privacy Policy</Button>
        </CardContent>
      </Card>

    </div>
  );
}
