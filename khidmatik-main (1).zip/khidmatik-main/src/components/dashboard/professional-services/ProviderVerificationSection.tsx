
'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { UserCheck, ShieldCheck, FileUp, Award, Loader2, Info, BadgeCheck } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useState } from 'react';
import type { VerifiedBadge } from '@/types'; // Assuming VerifiedBadge type exists
import { Badge } from '@/components/ui/badge'; // Added missing import

// Mock data for current verification status & available badges
const mockVerificationStatus = {
  identity: 'Approved', // 'Pending', 'Approved', 'Rejected', 'Requires Action'
  commercialLicense: 'Not Applicable', // or 'Pending', 'Approved', 'Rejected'
  qualifications: 'Pending',
};

const mockAvailableBadges: VerifiedBadge[] = [
  { name: "ID Verified", icon: ShieldCheck, description: "Identity documents successfully verified." },
  { name: "Business Registered", icon: ShieldCheck, description: "Commercial registration confirmed (if applicable)." },
  { name: "Qualifications Certified", icon: Award, description: "Professional qualifications and certifications validated." },
  { name: "Khidmatik Pro", icon: BadgeCheck, description: "Top-rated and highly trusted professional on the platform." },
];


export function ProviderVerificationSection() {
  const { toast } = useToast();
  const [isUploadingId, setIsUploadingId] = useState(false);
  const [isUploadingLicense, setIsUploadingLicense] = useState(false);
  const [isUploadingQuals, setIsUploadingQuals] = useState(false);

  const handleFileUpload = async (fileType: string, setIsUploadingState: React.Dispatch<React.SetStateAction<boolean>>) => {
    setIsUploadingState(true);
    // Simulate file upload
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsUploadingState(false);
    toast({
      title: `${fileType} Submitted (Conceptual)`,
      description: `Your ${fileType.toLowerCase()} has been submitted for review. You'll be notified of the status.`,
    });
    // Update mockVerificationStatus conceptually here for demo if needed
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold font-headline flex items-center">
          <UserCheck className="mr-3 h-8 w-8 text-primary" /> Verification & Badges
        </h1>
        <p className="text-muted-foreground">Manage your identity, business, and qualification verifications to build trust and unlock platform features.</p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><ShieldCheck className="mr-2 h-5 w-5 text-primary"/> Verification Status</CardTitle>
          <CardDescription>Keep your verification documents up-to-date.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Identity Verification */}
          <div className="p-4 border rounded-md bg-muted/50">
            <div className="flex justify-between items-center mb-2">
              <h4 className="font-semibold">Identity Verification (National ID / Passport)</h4>
              <Badge variant={mockVerificationStatus.identity === 'Approved' ? 'default' : 'secondary'} className={mockVerificationStatus.identity === 'Approved' ? 'bg-green-500 text-white' : ''}>
                {mockVerificationStatus.identity}
              </Badge>
            </div>
            {mockVerificationStatus.identity !== 'Approved' && (
              <>
                <Label htmlFor="idUpload">Upload National ID/Passport (PDF, JPG - Max 5MB)</Label>
                <Input id="idUpload" type="file" accept=".pdf,.jpg,.jpeg" className="mt-1" disabled={isUploadingId}/>
                <Button 
                  onClick={() => handleFileUpload('ID Document', setIsUploadingId)} 
                  className="mt-2" 
                  disabled={isUploadingId}
                >
                  {isUploadingId ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <FileUp className="mr-2 h-4 w-4" />}
                  {isUploadingId ? 'Uploading...' : 'Submit ID Document'}
                </Button>
              </>
            )}
          </div>

          {/* Commercial License Verification */}
          <div className="p-4 border rounded-md bg-muted/50">
            <div className="flex justify-between items-center mb-2">
              <h4 className="font-semibold">Commercial License / Registration (If applicable)</h4>
               <Badge variant={mockVerificationStatus.commercialLicense === 'Approved' ? 'default' : mockVerificationStatus.commercialLicense === 'Not Applicable' ? 'outline' : 'secondary'} className={mockVerificationStatus.commercialLicense === 'Approved' ? 'bg-green-500 text-white' : ''}>
                {mockVerificationStatus.commercialLicense}
              </Badge>
            </div>
            {mockVerificationStatus.commercialLicense !== 'Approved' && mockVerificationStatus.commercialLicense !== 'Not Applicable' && (
              <>
                <Label htmlFor="licenseUpload">Upload Commercial License (PDF, JPG - Max 5MB)</Label>
                <Input id="licenseUpload" type="file" accept=".pdf,.jpg,.jpeg" className="mt-1" disabled={isUploadingLicense}/>
                <Button 
                  onClick={() => handleFileUpload('Commercial License', setIsUploadingLicense)} 
                  className="mt-2" 
                  disabled={isUploadingLicense}
                >
                  {isUploadingLicense ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <FileUp className="mr-2 h-4 w-4" />}
                  {isUploadingLicense ? 'Uploading...' : 'Submit License'}
                </Button>
              </>
            )}
             {mockVerificationStatus.commercialLicense === 'Not Applicable' && (
                 <p className="text-xs text-muted-foreground">Not required for your professional category.</p>
             )}
          </div>
          
           {/* Qualifications Verification */}
          <div className="p-4 border rounded-md bg-muted/50">
            <div className="flex justify-between items-center mb-2">
              <h4 className="font-semibold">Professional Qualifications/Certificates</h4>
               <Badge variant={mockVerificationStatus.qualifications === 'Approved' ? 'default' : 'secondary'} className={mockVerificationStatus.qualifications === 'Approved' ? 'bg-green-500 text-white' : ''}>
                {mockVerificationStatus.qualifications}
              </Badge>
            </div>
            {mockVerificationStatus.qualifications !== 'Approved' && (
              <>
                <Label htmlFor="qualsUpload">Upload Diplomas/Certificates (PDF, JPG - Max 5MB per file)</Label>
                <Input id="qualsUpload" type="file" accept=".pdf,.jpg,.jpeg" className="mt-1" multiple disabled={isUploadingQuals}/>
                <Button 
                  onClick={() => handleFileUpload('Qualifications', setIsUploadingQuals)} 
                  className="mt-2" 
                  disabled={isUploadingQuals}
                >
                  {isUploadingQuals ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <FileUp className="mr-2 h-4 w-4" />}
                  {isUploadingQuals ? 'Uploading...' : 'Submit Qualifications'}
                </Button>
              </>
            )}
          </div>

        </CardContent>
        <CardFooter>
            <div className="flex items-start space-x-2 p-3 bg-blue-50 border border-blue-200 rounded-md text-blue-700 text-xs">
                <Info className="h-4 w-4 mt-0.5 shrink-0 text-blue-700" />
                <p>Verification helps build trust with clients and may unlock additional platform features or higher visibility. Submitted documents are reviewed by our team. This process can take 24-48 hours.</p>
            </div>
        </CardFooter>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><Award className="mr-2 h-5 w-5 text-primary"/> My Earned Badges</CardTitle>
          <CardDescription>Badges displayed on your profile to highlight your credibility and achievements.</CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {mockAvailableBadges.map(badge => {
            const BadgeIcon = badge.icon || Award;
            // Conceptual: Check if user has earned this badge
            const hasBadge = (badge.name === "ID Verified" && mockVerificationStatus.identity === 'Approved') ||
                             (badge.name === "Business Registered" && mockVerificationStatus.commercialLicense === 'Approved') ||
                             (badge.name === "Qualifications Certified" && mockVerificationStatus.qualifications === 'Approved') ||
                             (badge.name === "Khidmatik Pro"); // Khidmatik Pro is conceptual, always shown for demo
            return (
              <div key={badge.name} className={`p-3 border rounded-md flex items-start gap-3 ${hasBadge ? 'bg-green-50 border-green-200' : 'bg-muted/30 opacity-60'}`}>
                <BadgeIcon className={`h-6 w-6 mt-1 ${hasBadge ? 'text-green-600' : 'text-muted-foreground'}`} />
                <div>
                  <h5 className={`font-semibold ${hasBadge ? 'text-green-700' : 'text-muted-foreground'}`}>{badge.name}</h5>
                  <p className="text-xs text-muted-foreground">{badge.description}</p>
                  {!hasBadge && <p className="text-xs text-amber-600 mt-1">Not yet earned. Complete relevant verification steps.</p>}
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}

