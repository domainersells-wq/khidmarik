
'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { MessageSquareWarning, Search, ListFilter, FilePlus2, LifeBuoy, BookOpen, Video, MessageCircle } from 'lucide-react'; // Updated icons
import { mockSupportTickets } from '@/data/mock'; // Assuming this contains provider-relevant tickets
import { formatDistanceToNow } from 'date-fns';
import { useToast } from '@/hooks/use-toast';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export function SupportResolutionSection() {
  const { toast } = useToast();

  const handleViewTicket = (ticketNumber: string) => {
    toast({ title: 'View My Ticket (Conceptual)', description: `Details for your ticket ${ticketNumber} would open.` });
  };

  const handleSubmitTicket = (e: React.FormEvent) => {
    e.preventDefault();
    toast({ title: 'Support Ticket Submitted (Conceptual)', description: 'Your request has been sent. Our team will get back to you soon.'});
    // Reset form fields here
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold font-headline flex items-center"><LifeBuoy className="mr-3 h-8 w-8 text-primary" />Help & Support Center</h1>
        <p className="text-muted-foreground">Get help, find answers, and manage your support requests.</p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><FilePlus2 className="mr-2 h-5 w-5"/>Submit a New Support Request</CardTitle>
          <CardDescription>Need help with the platform or have an issue? Let us know.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmitTicket} className="space-y-4">
            <div>
                <Label htmlFor="ticket-subject">Subject</Label>
                <Input id="ticket-subject" placeholder="e.g., Issue with payment withdrawal, Question about service listing" disabled/>
            </div>
            <div>
                <Label htmlFor="ticket-category">Category</Label>
                <Select disabled>
                    <SelectTrigger id="ticket-category"><SelectValue placeholder="Select issue category..." /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="technical">Technical Issue</SelectItem>
                        <SelectItem value="billing">Billing/Payment</SelectItem>
                        <SelectItem value="listing">Service Listing</SelectItem>
                        <SelectItem value="account">Account Help</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                </Select>
            </div>
            <div>
                <Label htmlFor="ticket-description">Describe your issue</Label>
                <Textarea id="ticket-description" placeholder="Please provide as much detail as possible..." rows={5} disabled/>
            </div>
            <Button type="submit" disabled>Submit Ticket</Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><ListFilter className="mr-2 h-5 w-5"/>My Support Tickets</CardTitle>
          <CardDescription>Track the status of your submitted support requests.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2 mb-4">
            <Input placeholder="Search my tickets..." className="max-w-xs" disabled/>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Ticket ID</TableHead>
                <TableHead>Subject</TableHead>
                <TableHead>Last Update</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mockSupportTickets.slice(0,2).map((ticket) => ( // Assuming mockSupportTickets can be filtered by provider
                <TableRow key={ticket.id}>
                  <TableCell className="font-medium">{ticket.ticketNumber}</TableCell>
                  <TableCell className="truncate max-w-xs">{ticket.issueSummary}</TableCell>
                  <TableCell>{formatDistanceToNow(new Date(ticket.lastUpdate), { addSuffix: true })}</TableCell>
                  <TableCell><Badge variant={ticket.status === 'Open' ? 'default' : 'secondary'}>{ticket.status}</Badge></TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm" onClick={() => handleViewTicket(ticket.ticketNumber)} disabled>View/Reply</Button>
                  </TableCell>
                </TableRow>
              ))}
               {mockSupportTickets.length === 0 && (
                 <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-4">You have no active support tickets.</TableCell></TableRow>
               )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
            <CardTitle className="flex items-center"><BookOpen className="mr-2 h-5 w-5"/>Knowledge Base & FAQs</CardTitle>
            <CardDescription>Find answers to common questions and learn how to use platform features.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
            <Input placeholder="Search FAQs and tutorials..." className="mb-3" disabled/>
            <Button variant="outline" className="w-full justify-start" disabled><BookOpen className="mr-2 h-4 w-4"/> Browse All FAQs</Button>
            <Button variant="outline" className="w-full justify-start" disabled><Video className="mr-2 h-4 w-4"/> Watch Video Tutorials</Button>
        </CardContent>
        <CardFooter>
            <p className="text-xs text-muted-foreground">Live chat support coming soon for Pro members.</p>
        </CardFooter>
      </Card>
    </div>
  );
}
