
'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { LineChart, Users, Package, ShoppingCart, BarChartHorizontalBig, AlertCircle, DollarSign as DollarSignIcon, Globe, TrendingUp, TrendingDown, BarChart2, PieChart, Map as MapIcon, Table as TableIcon, Percent } from 'lucide-react';
import Image from 'next/image';
import type { TopContentItem } from '@/types';
import { mockTopContent } from '@/data/mock';
import { ConversionFunnelChart } from './ConversionFunnelChart';
import { GeographicDistributionChart } from './GeographicDistributionChart';

export function AnalyticsSection() {
  const mockTopPages = mockTopContent; 

  return (
    <div className="space-y-8">
      <header className="mb-6">
        <CardTitle className="text-2xl font-headline flex items-center">
          <LineChart className="mr-3 h-6 w-6 text-primary" /> Sales & Traffic Analytics
        </CardTitle>
        <CardDescription>Turn your store data into actionable insights. Includes discount campaign reports.</CardDescription>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><BarChart2 className="mr-2 h-5 w-5 text-primary" /> Performance Overview</CardTitle>
          <div className="flex items-center gap-2 mt-2">
            <Button variant="outline" size="sm" disabled>Last Month</Button>
            <Button variant="ghost" size="sm" disabled>Last 6 Months</Button>
            <Button variant="ghost" size="sm" disabled>Last Year</Button>
          </div>
        </CardHeader>
        <CardContent>
           <div className="h-[300px] flex items-center justify-center bg-muted/30 rounded-md">
              <Image src="https://placehold.co/600x300.png" alt="Main Performance Chart Placeholder" width={600} height={300} data-ai-hint="bar line chart performance" className="opacity-50"/>
            </div>
            <p className="text-xs text-muted-foreground mt-2 text-center">Conceptual: Daily/Weekly/Monthly Revenue (Bars) and Store/Product Page Views (Line).</p>
        </CardContent>
      </Card>
      
      <div className="grid md:grid-cols-2 gap-6">
        
        <ConversionFunnelChart />

        <GeographicDistributionChart />
        
      </div>

      <Card className="md:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center"><TableIcon className="mr-2 h-5 w-5 text-primary"/> Top Selling Products</CardTitle>
              <Button variant="link" size="sm" className="text-xs" disabled>View All Products</Button>
          </CardHeader>
          <CardContent>
              <Table>
                  <TableHeader>
                      <TableRow>
                          <TableHead>Product Name</TableHead>
                          <TableHead className="text-right">Units Sold</TableHead>
                          <TableHead className="text-right">Revenue (DA)</TableHead>
                      </TableRow>
                  </TableHeader>
                  <TableBody>
                      {mockTopContent.slice(0,3).map((item, index) => ( // Assuming mockTopContent has sales data
                      <TableRow key={index}>
                          <TableCell className="font-medium text-sm truncate w-1/2" title={item.name}>{item.name}</TableCell>
                          <TableCell className="text-right text-sm">{(item.views / 10).toFixed(0)}</TableCell> {/* Mock sales */}
                          <TableCell className="text-right text-sm">{(item.views * 50).toLocaleString()}</TableCell> {/* Mock revenue */}
                      </TableRow>
                      ))}
                  </TableBody>
              </Table>
          </CardContent>
      </Card>
      
       <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><Users className="mr-2 h-5 w-5 text-primary"/> Customer Analysis</CardTitle>
          <CardDescription>Insights into customer behavior and value.</CardDescription>
        </CardHeader>
        <CardContent>
            <p className="text-sm text-muted-foreground">Conceptual: Reports on customer lifetime value, order frequency, and segmentation.</p>
            <Button variant="outline" className="mt-2" disabled>View Detailed Customer Reports</Button>
        </CardContent>
      </Card>
      
       <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><Percent className="mr-2 h-5 w-5 text-primary"/> Discount Campaign Reports</CardTitle>
          <CardDescription>Track the performance of your promotional campaigns and discount codes, including UTM tracking.</CardDescription>
        </CardHeader>
        <CardContent>
            <p className="text-sm text-muted-foreground">Conceptual: Table showing coupon usage, revenue generated per campaign, and conversion rates from UTM-tracked links.</p>
            <Button variant="outline" className="mt-2" disabled>View Campaign Performance</Button>
        </CardContent>
      </Card>


       <p className="text-sm text-muted-foreground text-center">
            More advanced reporting features, custom date ranges, and export options coming soon.
        </p>
    </div>
  );
}

    