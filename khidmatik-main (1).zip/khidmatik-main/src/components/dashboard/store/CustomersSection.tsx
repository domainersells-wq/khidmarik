
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, Search, Filter, UserPlus, Eye, Edit, MessageSquare, Star, Tag, Gift, HelpCircle, CheckCircle, Settings } from 'lucide-react'; // Added Settings
import { useToast } from '@/hooks/use-toast';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';

const mockCustomers = [
  { id: 'cust1', name: 'Amine Douba', email: 'amine.d@example.dz', registrationDate: '2024-01-15', totalOrders: 5, totalSpent: 12500, group: 'VIP', loyaltyPoints: 500, lastReviewDate: '2024-07-10', lastReviewRating: 5 },
  { id: 'cust2', name: 'Fatima Chergui', email: 'f.chergui@example.dz', registrationDate: '2024-03-22', totalOrders: 2, totalSpent: 3200, group: 'New', loyaltyPoints: 80 },
  { id: 'cust3', name: 'Yacine Khelifi', email: 'yacine.k@example.dz', registrationDate: '2023-11-05', totalOrders: 12, totalSpent: 28000, group: 'Regular', loyaltyPoints: 1200, lastReviewDate: '2024-06-01', lastReviewRating: 4 },
];

export function CustomersSection() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');

  const filteredCustomers = mockCustomers.filter(customer =>
    customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleViewCustomer = (customerId: string) => {
    toast({ title: "View Customer (Conceptual)", description: `Details for customer ${customerId} (order history, favorites, support tickets, CRM notes) would be shown.` });
  };
  const handleEditCustomer = (customerId: string) => {
    toast({ title: "Edit Customer (Conceptual)", description: `Editing form for customer ${customerId} (tags, notes) would appear.` });
  };
  const handleApproveReview = (reviewId: string) => {
    toast({ title: "Review Approved (Conceptual)", description: `Review ${reviewId} published.` });
  };
  const handleAnswerQuestion = (questionId: string) => {
    toast({ title: "Question Answered (Conceptual)", description: `Response to question ${questionId} published.` });
  };


  return (
    <Card className="shadow-lg border">
      <CardHeader>
        <CardTitle className="text-2xl font-headline flex items-center">
          <Users className="mr-3 h-6 w-6 text-primary" /> Customer Management & Reviews
        </CardTitle>
        <CardDescription>View customer data, order history, manage groups, reviews, and product Q&A.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex flex-col sm:flex-row gap-4 items-center">
          <div className="relative flex-1 w-full sm:w-auto">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search by Name or Email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8 sm:w-full md:w-[300px] lg:w-[400px]"
            />
          </div>
          <Button variant="outline" disabled className="w-full sm:w-auto">
            <Filter className="mr-2 h-4 w-4" /> Filter by Group (e.g., VIP)
          </Button>
          <Button variant="outline" disabled className="w-full sm:w-auto">
            <UserPlus className="mr-2 h-4 w-4" /> Add Customer Manually
          </Button>
        </div>

        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Orders</TableHead>
                <TableHead className="text-right">Total Spent (DA)</TableHead>
                <TableHead className="text-center">Loyalty Pts</TableHead>
                <TableHead>Group</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredCustomers.map((customer) => (
                <TableRow key={customer.id}>
                  <TableCell className="font-medium">{customer.name}</TableCell>
                  <TableCell>{customer.email}</TableCell>
                  <TableCell className="text-center">{customer.totalOrders}</TableCell>
                  <TableCell className="text-right">{customer.totalSpent.toLocaleString()}</TableCell>
                  <TableCell className="text-center">{customer.loyaltyPoints || 0}</TableCell>
                  <TableCell><Badge variant={customer.group === 'VIP' ? 'default' : 'secondary'} className={customer.group === 'VIP' ? 'bg-primary' : ''}>{customer.group}</Badge></TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" onClick={() => handleViewCustomer(customer.id)}>
                      <Eye className="h-4 w-4" /><span className="sr-only">View</span>
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleEditCustomer(customer.id)}>
                      <Edit className="h-4 w-4" /><span className="sr-only">Edit</span>
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <Separator />
        <div className="grid md:grid-cols-2 gap-6">
            <Card className="bg-muted/30">
                <CardHeader>
                    <CardTitle className="text-lg flex items-center"><Star className="mr-2 h-5 w-5 text-primary"/>Product Reviews & Ratings</CardTitle>
                    <CardDescription>Moderate customer reviews and manage Q&A.</CardDescription>
                </CardHeader>
                <CardContent>
                    <p className="text-sm text-muted-foreground mb-2">Conceptual: List of pending reviews for approval. Product Q&A section with seller responses.</p>
                    <div className="space-y-2">
                        <div className="p-2 border rounded-md">
                            <p className="text-xs font-medium">"Great product!" - Ali B. (5 stars) for "Ceramic Mug"</p>
                            <Button size="sm" variant="outline" className="mt-1 text-xs" onClick={() => handleApproveReview('rev_xyz')}><CheckCircle className="mr-1 h-3 w-3"/>Approve</Button>
                        </div>
                        <div className="p-2 border rounded-md">
                            <p className="text-xs font-medium">Question: "Is this compatible with X?" for "Leather Wallet"</p>
                            <Button size="sm" variant="outline" className="mt-1 text-xs" onClick={() => handleAnswerQuestion('q_abc')}><MessageSquare className="mr-1 h-3 w-3"/>Answer</Button>
                        </div>
                    </div>
                </CardContent>
            </Card>
            <Card className="bg-muted/30">
                <CardHeader>
                    <CardTitle className="text-lg flex items-center"><Gift className="mr-2 h-5 w-5 text-primary"/>Loyalty Program</CardTitle>
                    <CardDescription>Manage customer loyalty points and rewards.</CardDescription>
                </CardHeader>
                <CardContent>
                     <p className="text-sm text-muted-foreground mb-2">Conceptual: Configure points earning rules and redemption options.</p>
                     <Button variant="outline" disabled><Settings className="mr-2 h-4 w-4"/>Configure Loyalty Program</Button>
                </CardContent>
            </Card>
        </div>
      </CardContent>
    </Card>
  );
}
