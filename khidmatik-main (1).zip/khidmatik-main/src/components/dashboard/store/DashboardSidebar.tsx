
'use client';

import Link from 'next/link';
import { usePathname, useSearchParams } from 'next/navigation';
import { cn } from '@/lib/utils';
import { Button, buttonVariants } from '@/components/ui/button';
import {
  LayoutDashboard,
  ShoppingCart,
  Package,
  Users,
  LineChart,
  Settings,
  Megaphone,
  ChevronLeft,
  Store,
  DollarSign, // For Financials
  Sparkles, // For AI Assistant
} from 'lucide-react';
import { AppLogo } from '@/components/layout/AppLogo';

interface DashboardSidebarProps {
  onLinkClick?: () => void; // Optional callback for mobile sidebar to close on link click
}

const navItems = [
  { href: 'overview', label: 'Overview', icon: LayoutDashboard },
  { href: 'orders', label: 'Orders & Returns', icon: ShoppingCart },
  { href: 'products', label: 'Products & Inventory', icon: Package },
  { href: 'customers', label: 'Customers & Reviews', icon: Users },
  { href: 'marketing', label: 'Marketing & Promotions', icon: Megaphone },
  { href: 'financials', label: 'Financials & Payouts', icon: DollarSign },
  { href: 'ai-assistant', label: 'AI Seller Assistant', icon: Sparkles },
  { href: 'analytics', label: 'Analytics & Reports', icon: LineChart },
  { href: 'settings', label: 'Store Settings & Config', icon: Settings },
];

export function DashboardSidebar({ onLinkClick }: DashboardSidebarProps) {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const currentSection = searchParams.get('section') || 'overview';

  return (
    <aside className="fixed inset-y-0 left-0 z-10 flex h-full w-64 flex-col border-r bg-card text-card-foreground shadow-md">
      <div className="flex h-16 items-center border-b px-6">
        <Link href="/dashboard/store" className="flex items-center gap-2 font-semibold" onClick={onLinkClick}>
          <AppLogo className="h-7 w-7 text-primary" />
          <span className="text-lg">Store Dashboard</span>
        </Link>
      </div>
      <nav className="flex-1 overflow-auto py-4 px-4 text-sm font-medium">
        <ul className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentSection === item.href;
            return (
              <li key={item.href}>
                <Link
                  href={`/dashboard/store?section=${item.href}`}
                  className={cn(
                    buttonVariants({ variant: isActive ? 'default' : 'ghost', size: 'default' }),
                    'w-full justify-start',
                    isActive && 'bg-primary text-primary-foreground hover:bg-primary/90 hover:text-primary-foreground'
                  )}
                  onClick={onLinkClick}
                >
                  <Icon className="mr-3 h-5 w-5" />
                  {item.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
      <div className="mt-auto border-t p-4">
        <Button variant="outline" className="w-full justify-start" asChild>
          <Link href="/">
            <ChevronLeft className="mr-2 h-4 w-4" /> Back to Main Site
          </Link>
        </Button>
      </div>
    </aside>
  );
}
