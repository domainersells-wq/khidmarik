
'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { DollarSign, FileText, Download, Landmark, TrendingUp, AlertCircle, CreditCard, ExternalLink, Filter, CalendarDays, LineChart, BarChart2, Printer } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import Image from 'next/image';
import { Input } from '@/components/ui/input';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';


// Mock Data
const mockStoreTransactions = [
  { id: 'stxn_001', date: '2024-07-15', description: 'Sale of "Artisan Ceramic Mug" (Order #ORD1001)', type: 'Sale', amount: 2500, status: 'Paid', invoiceId: 'INV_S_001' },
  { id: 'stxn_002', date: '2024-07-14', description: 'Platform Commission (Order #ORD1001)', type: 'Commission', amount: -250, status: 'Deducted', invoiceId: 'INV_S_001' },
  { id: 'stxn_003', date: '2024-07-10', description: 'Sale of "Handmade Leather Wallet" (Order #ORD1002)', type: 'Sale', amount: 1800, status: 'Pending (COD)', invoiceId: 'INV_S_002' },
  { id: 'stxn_004', date: '2024-07-05', description: 'Withdrawal Request', type: 'Payout', amount: -5000, status: 'Processing', invoiceId: 'WDR_001' },
];

const mockStoreEarningsSummary = {
    totalRevenueMonth: 120500.75,
    pendingPayouts: 15200.00,
    platformCommissionsMonth: 12050.08,
    lastPayoutDate: '2024-07-01',
};

export function FinancialsSection() {
  const { toast } = useToast();

  const handleGenerateInvoice = (orderId: string) => {
    toast({ title: "Invoice Generated (Conceptual)", description: `PDF Invoice for ${orderId} would be downloaded.` });
  };
  
  const handleRequestWithdrawal = () => {
     toast({ title: "Withdrawal Request (Conceptual)", description: `This would open a modal to enter amount and select payout method (bank, PayPal when available).`});
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold font-headline flex items-center">
          <DollarSign className="mr-3 h-8 w-8 text-primary" /> Store Financials & Payouts
        </h1>
        <p className="text-muted-foreground">Track your store's earnings, manage invoices, and request withdrawals.</p>
      </header>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Total Revenue (Month)</CardTitle></CardHeader>
          <CardContent><div className="text-2xl font-bold">{mockStoreEarningsSummary.totalRevenueMonth.toLocaleString()} DA</div><p className="text-xs text-green-500">+5.2% vs last month</p></CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Pending Payouts</CardTitle></CardHeader>
          <CardContent><div className="text-2xl font-bold">{mockStoreEarningsSummary.pendingPayouts.toLocaleString()} DA</div></CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Platform Commissions (Month)</CardTitle></CardHeader>
          <CardContent><div className="text-2xl font-bold">{mockStoreEarningsSummary.platformCommissionsMonth.toLocaleString()} DA</div></CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium">Last Payout Date</CardTitle></CardHeader>
          <CardContent><div className="text-xl font-semibold">{mockStoreEarningsSummary.lastPayoutDate}</div></CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
            <CardTitle className="flex items-center"><BarChart2 className="mr-2 h-5 w-5 text-primary"/>Revenue Reports</CardTitle>
            <CardDescription>Visualize your daily and monthly sales revenue. (Conceptual Charts)</CardDescription>
        </CardHeader>
        <CardContent className="grid md:grid-cols-2 gap-4">
            <div className="h-[250px] flex items-center justify-center bg-muted/30 rounded-md">
                <Image src="https://placehold.co/400x250.png" alt="Daily Revenue Chart" width={400} height={250} data-ai-hint="line chart revenue" className="opacity-70"/>
            </div>
            <div className="h-[250px] flex items-center justify-center bg-muted/30 rounded-md">
                <Image src="https://placehold.co/400x250.png" alt="Monthly Revenue Chart" width={400} height={250} data-ai-hint="bar chart revenue" className="opacity-70"/>
            </div>
        </CardContent>
         <CardFooter className="pt-4 flex justify-between items-center">
            <div className="flex gap-2">
                <Button variant="outline" size="sm" disabled><CalendarDays className="mr-2 h-4 w-4"/>Date Range</Button>
            </div>
            <Button variant="outline" size="sm" disabled><Download className="mr-2 h-4 w-4"/>Export Revenue Data</Button>
        </CardFooter>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><FileText className="mr-2 h-5 w-5 text-primary"/>Transaction History & Invoices</CardTitle>
          <CardDescription>View all sales, commissions, and generate invoices.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-2 mb-4">
            <Input placeholder="Search by Order ID or Invoice #" className="max-w-xs"/>
            <Select disabled>
                <SelectTrigger className="w-full sm:w-[180px]"><Filter className="mr-2 h-4 w-4"/><SelectValue placeholder="Filter by Type"/></SelectTrigger>
                <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="sale">Sale</SelectItem>
                    <SelectItem value="commission">Commission</SelectItem>
                    <SelectItem value="payout">Payout</SelectItem>
                </SelectContent>
            </Select>
            <Button variant="outline" disabled><CalendarDays className="mr-2 h-4 w-4"/>Date Range</Button>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Type</TableHead>
                <TableHead className="text-right">Amount (DA)</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Invoice</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mockStoreTransactions.map(txn => (
                <TableRow key={txn.id}>
                  <TableCell>{txn.date}</TableCell>
                  <TableCell className="font-medium">{txn.description}</TableCell>
                  <TableCell><Badge variant={txn.type === 'Sale' ? 'outline' : txn.type === 'Commission' ? 'secondary' : 'default'} className={txn.type === 'Payout' ? 'bg-blue-500 text-white' : ''}>{txn.type}</Badge></TableCell>
                  <TableCell className={`text-right ${txn.amount < 0 ? 'text-destructive' : 'text-green-600'}`}>{txn.amount.toFixed(2)}</TableCell>
                  <TableCell><Badge variant={txn.status === 'Paid' || txn.status === 'Deducted' ? 'default' : 'secondary'} className={(txn.status === 'Paid' || txn.status === 'Deducted') ? 'bg-green-500 text-white' : txn.status === 'Pending (COD)' ? 'bg-yellow-400 text-yellow-900' : ''}>{txn.status}</Badge></TableCell>
                  <TableCell className="text-right">
                    {txn.type === 'Sale' && <Button variant="ghost" size="icon" onClick={() => handleGenerateInvoice(txn.invoiceId)}><Printer className="h-4 w-4"/></Button>}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
            <CardTitle className="flex items-center"><Landmark className="mr-2 h-5 w-5 text-primary"/>Withdrawal System</CardTitle>
            <CardDescription>Request payouts to your bank account or other supported methods.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
            <p className="text-sm text-muted-foreground">Available for Withdrawal: <strong>{(mockStoreEarningsSummary.totalRevenueMonth - mockStoreEarningsSummary.platformCommissionsMonth - mockStoreEarningsSummary.pendingPayouts).toLocaleString()} DA</strong> (Conceptual)</p>
            <p className="text-sm text-muted-foreground">Current Payout Method: <strong>Bank Transfer - BNA ending in ****5678</strong> (Conceptual)</p>
            <Button onClick={handleRequestWithdrawal} className="w-full sm:w-auto"><DollarSign className="mr-2 h-4 w-4"/>Request New Withdrawal</Button>
            <Button variant="outline" className="w-full sm:w-auto" onClick={() => toast({title:"Manage Payout Methods (Conceptual)", description:"Add/edit bank accounts or PayPal (when available)."}) }>
                <CreditCard className="mr-2 h-4 w-4"/> Manage Payout Methods
            </Button>
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-md text-blue-700 text-xs flex items-start gap-2 mt-2">
                <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
                <span>
                    Platform commissions are automatically calculated and deducted before payouts are processed. Standard payout processing time is 3-5 business days after request.
                </span>
            </div>
        </CardContent>
      </Card>
    </div>
  );
}
