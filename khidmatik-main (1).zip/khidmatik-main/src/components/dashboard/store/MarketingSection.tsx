
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Megaphone, Ticket, Image as ImageIcon, SearchCheck, PlusCircle, List, Settings, Mail, Bell, Activity } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Separator } from '@/components/ui/separator';

export function MarketingSection() {
  const { toast } = useToast();
  const [couponCode, setCouponCode] = useState('');
  const [discountType, setDiscountType] = useState<'percentage' | 'fixed' | 'free_shipping'>('percentage');
  const [discountValue, setDiscountValue] = useState('');

  const handleCreateCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    toast({ title: "Coupon Created (Conceptual)", description: `Coupon "${couponCode}" with ${discountType} of ${discountValue} created. Discount campaign reports would track usage.`});
  };

  return (
    <div className="space-y-8">
      <header className="mb-6">
        <CardTitle className="text-2xl font-headline flex items-center">
          <Megaphone className="mr-3 h-6 w-6 text-primary" /> Marketing, Promotions & Automation
        </CardTitle>
        <CardDescription>Tools to boost sales, attract customers, and automate marketing tasks.</CardDescription>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><Ticket className="mr-2 h-5 w-5" /> Discount Coupons & Promotions</CardTitle>
          <CardDescription>Create and manage promotional discount codes, time-limited offers, and flash sales.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleCreateCoupon} className="space-y-4 p-4 border rounded-md bg-muted/30">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="couponCode">Coupon Code</Label>
                <Input id="couponCode" value={couponCode} onChange={e => setCouponCode(e.target.value.toUpperCase())} placeholder="e.g., SUMMER20" />
              </div>
              <div>
                <Label htmlFor="discountType">Discount Type</Label>
                <Select value={discountType} onValueChange={val => setDiscountType(val as any)}>
                  <SelectTrigger id="discountType"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="percentage">Percentage (%)</SelectItem>
                    <SelectItem value="fixed">Fixed Amount (DA)</SelectItem>
                    <SelectItem value="free_shipping">Free Shipping</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="discountValue">Value / Amount</Label>
                <Input id="discountValue" type="number" value={discountValue} onChange={e => setDiscountValue(e.target.value)} placeholder="e.g., 20 or 500" disabled={discountType === 'free_shipping'}/>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <Label htmlFor="promoStartDate">Promotion Start Date (Conceptual)</Label>
                    <Input id="promoStartDate" type="date" disabled />
                </div>
                <div>
                    <Label htmlFor="promoEndDate">Promotion End Date (Conceptual)</Label>
                    <Input id="promoEndDate" type="date" disabled />
                </div>
            </div>
            <Button type="submit" className="w-full md:w-auto"><PlusCircle className="mr-2 h-4 w-4" /> Create Coupon/Promotion</Button>
          </form>
          <div className="mt-4">
            <h4 className="font-semibold mb-2">Existing Promotions (Conceptual)</h4>
            <p className="text-sm text-muted-foreground">A list of active and past promotions with performance metrics (usage, UTM tracking) would appear here.</p>
            <Button variant="outline" className="mt-2" disabled><List className="mr-2 h-4 w-4"/> View All Promotions</Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><ImageIcon className="mr-2 h-5 w-5" /> Manage Banners</CardTitle>
          <CardDescription>Control promotional images on your store's homepage.</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">Conceptual: Interface to upload, reorder, and set links for homepage banners.</p>
          <Button variant="outline" className="mt-3" disabled><ImageIcon className="mr-2 h-4 w-4"/> Upload New Banner</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><SearchCheck className="mr-2 h-5 w-5" /> Search Engine Optimization (SEO)</CardTitle>
          <CardDescription>Improve your store's visibility on search engines like Google.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-muted-foreground">
            Conceptual: Tools to edit global SEO settings (store title, meta description) and specific SEO fields for each product and category page.
          </p>
          <Button variant="outline" className="mt-3" disabled><Settings className="mr-2 h-4 w-4"/> Configure SEO Settings</Button>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><Activity className="mr-2 h-5 w-5" /> Marketing Automation</CardTitle>
          <CardDescription>Set up automated messages and alerts to engage customers.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
            <div className="p-3 border rounded-md bg-muted/50">
                <Label htmlFor="abandonedCartEmail" className="flex items-center justify-between">
                    <span>Abandoned Cart Reminder Emails</span> <Button size="sm" variant="ghost" disabled>Configure</Button>
                </Label>
                <p className="text-xs text-muted-foreground">Automatically send emails to customers who leave items in their cart.</p>
            </div>
            <div className="p-3 border rounded-md bg-muted/50">
                <Label htmlFor="postPurchaseMessage" className="flex items-center justify-between">
                    <span>Post-Purchase Follow-up Messages</span> <Button size="sm" variant="ghost" disabled>Configure</Button>
                </Label>
                <p className="text-xs text-muted-foreground">Send thank you messages or ask for reviews after a purchase.</p>
            </div>
            <div className="p-3 border rounded-md bg-muted/50">
                <Label htmlFor="restockAlerts" className="flex items-center justify-between">
                    <span>Restocked Item Alerts</span> <Button size="sm" variant="ghost" disabled>Configure</Button>
                </Label>
                <p className="text-xs text-muted-foreground">Notify customers when a previously out-of-stock item they were interested in is back.</p>
            </div>
        </CardContent>
      </Card>
    </div>
  );
}
