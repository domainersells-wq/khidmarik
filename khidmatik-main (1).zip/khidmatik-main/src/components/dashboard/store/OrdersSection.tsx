
'use client';

import { useState } from 'react';
import Image from 'next/image'; 
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { FileText, Filter, Search, Truck, MoreHorizontal, Printer, CheckCircle, XCircle, Hourglass, ShoppingCart, PlusCircle, RotateCcw, CreditCard } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useToast } from '@/hooks/use-toast';
import { Separator } from '@/components/ui/separator';

const mockOrders = [
  { id: 'ORD1001', customerName: 'Ali Benomar', customerEmail: 'ali.b@example.dz', customerPhone: '0550123456', shippingAddress: '12 Rue de la Liberte, Alger Centre', paymentType: 'Credit Card', date: '2024-07-15', total: 2500, status: 'processing', items: 3, productName: 'Artisan Ceramic Mug', productImageUrl: 'https://placehold.co/40x40.png?text=Mug', returnStatus: 'none' },
  { id: 'ORD1002', customerName: 'Fatima Zohra', customerEmail: 'fatima.z@example.dz', customerPhone: '0661987654', shippingAddress: 'Cite 200 Logements, Oran', paymentType: 'Cash on Delivery', date: '2024-07-14', total: 1800, status: 'shipped', items: 1, productName: 'Handmade Leather Wallet', productImageUrl: 'https://placehold.co/40x40.png?text=Wallet', returnStatus: 'requested' },
  { id: 'ORD1003', customerName: 'Karim Salah', customerEmail: 'karim.s@example.dz', customerPhone: '0770112233', shippingAddress: 'Villa 5, Hydra, Alger', paymentType: 'Khidmatik Wallet', date: '2024-07-14', total: 5200, status: 'completed', items: 5, productName: 'Spicy Harissa Paste', productImageUrl: 'https://placehold.co/40x40.png?text=Harissa', returnStatus: 'approved' },
  { id: 'ORD1004', customerName: 'Lydia Ait', customerEmail: 'lydia.a@example.dz', customerPhone: '0555667788', shippingAddress: 'BP 15, Sidi Bel Abbes', paymentType: 'Credit Card', date: '2024-07-13', total: 950, status: 'cancelled', items: 2, productName: 'Organic Olive Oil', productImageUrl: 'https://placehold.co/40x40.png?text=Oil', returnStatus: 'none' },
  { id: 'ORD1005', customerName: 'Mehdi Cherif', customerEmail: 'mehdi.c@example.dz', customerPhone: '0660554433', shippingAddress: 'Cité des Jardins, Constantine', paymentType: 'Paypal (Conceptual)', date: '2024-07-16', total: 3100, status: 'processing', items: 2, productName: 'Khidmatik Supporter T-Shirt', productImageUrl: 'https://placehold.co/40x40.png?text=Tee', returnStatus: 'rejected' },
];

type OrderStatus = 'all' | 'processing' | 'shipped' | 'completed' | 'cancelled' | 'awaiting_payment';
type ReturnStatusFilter = 'all' | 'none' | 'requested' | 'approved' | 'rejected' | 'refunded';


export function OrdersSection() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<OrderStatus>('all');
  const [returnFilter, setReturnFilter] = useState<ReturnStatusFilter>('all');


  const filteredOrders = mockOrders.filter(order => {
    const matchesSearch = order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          order.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          (order.customerEmail && order.customerEmail.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
    const matchesReturn = returnFilter === 'all' || order.returnStatus === returnFilter;
    return matchesSearch && matchesStatus && matchesReturn;
  });

  const handlePrintInvoice = (orderId: string) => {
    toast({ title: "Print Invoice (Conceptual)", description: `Invoice for order ${orderId} would be generated.` });
  };
  const handlePrintShippingLabel = (orderId: string) => {
    toast({ title: "Print Shipping Label (Conceptual)", description: `Label for order ${orderId} would be generated. Conceptual integration with shipping carriers.` });
  };
  const handleChangeStatus = (orderId: string, newStatus: string) => {
    let description = `Order ${orderId} status updated to ${newStatus}.`;
    if (newStatus === 'completed') {
        description += ' You and the customer have both been notified.';
    } else if (newStatus === 'shipped') {
        description += ' The customer has been notified with tracking details.';
    } else {
        description += ' Customer notified of the change.';
    }
    
    toast({ 
        title: "Status Changed (Conceptual)", 
        description: description 
    });
  };
  const handleManageReturn = (orderId: string) => {
    toast({ title: "Manage Return (Conceptual)", description: `Opening return details for order ${orderId}. Options to approve/reject, process refund (auto for digital).` });
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'processing': return 'secondary';
      case 'shipped': return 'default'; 
      case 'completed': return 'outline'; 
      case 'cancelled': return 'destructive';
      case 'awaiting_payment': return 'outline'; // Yellowish
      default: return 'secondary';
    }
  };
   const getStatusIcon = (status: string) => {
    switch (status) {
      case 'processing': return <Hourglass className="h-3.5 w-3.5" />;
      case 'shipped': return <Truck className="h-3.5 w-3.5" />;
      case 'completed': return <CheckCircle className="h-3.5 w-3.5" />;
      case 'cancelled': return <XCircle className="h-3.5 w-3.5" />;
      case 'awaiting_payment': return <CreditCard className="h-3.5 w-3.5" />;
      default: return <Hourglass className="h-3.5 w-3.5" />;
    }
  };


  return (
    <Card className="shadow-lg border">
      <CardHeader className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
            <CardTitle className="text-2xl font-headline flex items-center">
            <ShoppingCart className="mr-3 h-6 w-6 text-primary" /> Orders & Returns Management
            </CardTitle>
            <CardDescription>View, process, track customer orders, and manage returns/refunds.</CardDescription>
        </div>
        <Button onClick={() => toast({title: "Create Order (Conceptual)", description:"Modal for manual order creation would open."})} className="mt-4 md:mt-0">
            <PlusCircle className="mr-2 h-4 w-4"/> Create New Order
        </Button>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex flex-col sm:flex-row gap-4 items-center">
          <div className="relative flex-1 w-full sm:w-auto">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search by Order ID, Customer Name, Email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8 sm:w-full md:w-[300px] lg:w-[400px]"
            />
          </div>
          <Select value={statusFilter} onValueChange={(value) => setStatusFilter(value as OrderStatus)}>
            <SelectTrigger className="w-full sm:w-[180px]">
              <Filter className="mr-2 h-4 w-4 text-muted-foreground" />
              <SelectValue placeholder="Filter by Order Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Order Statuses</SelectItem>
              <SelectItem value="awaiting_payment">Awaiting Payment</SelectItem>
              <SelectItem value="processing">Processing</SelectItem>
              <SelectItem value="shipped">Shipped</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="cancelled">Cancelled</SelectItem>
            </SelectContent>
          </Select>
           <Select value={returnFilter} onValueChange={(value) => setReturnFilter(value as ReturnStatusFilter)}>
            <SelectTrigger className="w-full sm:w-[180px]">
              <RotateCcw className="mr-2 h-4 w-4 text-muted-foreground" />
              <SelectValue placeholder="Filter by Return Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Return Statuses</SelectItem>
              <SelectItem value="none">No Return</SelectItem>
              <SelectItem value="requested">Requested</SelectItem>
              <SelectItem value="approved">Approved</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
              <SelectItem value="refunded">Refunded</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={() => toast({title: "Export Orders (Conceptual)", description: "CSV/Excel export functionality."})} className="w-full sm:w-auto">
            Export Orders
          </Button>
        </div>

        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Order ID</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Product</TableHead>
                <TableHead>Customer</TableHead>
                <TableHead>Payment</TableHead>
                <TableHead className="text-right">Total (DA)</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Return</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredOrders.length > 0 ? filteredOrders.map((order) => (
                <TableRow key={order.id}>
                  <TableCell className="font-medium">{order.id}</TableCell>
                  <TableCell>{order.date}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                        <Image src={order.productImageUrl || 'https://placehold.co/40x40.png'} alt={order.productName || 'Product'} width={32} height={32} className="rounded-sm object-cover" data-ai-hint="product image small" />
                        <span className="text-xs truncate w-24" title={order.productName}>{order.productName || 'N/A'} ({order.items})</span>
                    </div>
                  </TableCell>
                  <TableCell>{order.customerName}</TableCell>
                  <TableCell className="text-xs">{order.paymentType || 'N/A'}</TableCell>
                  <TableCell className="text-right">{order.total.toLocaleString()}</TableCell>
                  <TableCell>
                    <Badge variant={getStatusBadgeVariant(order.status)} className="flex items-center gap-1.5 capitalize">
                        {getStatusIcon(order.status)}
                        {order.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                     <Badge variant={order.returnStatus === 'none' ? 'outline' : order.returnStatus === 'approved' || order.returnStatus === 'refunded' ? 'default' : 'secondary'} 
                            className={`capitalize text-xs ${order.returnStatus === 'approved' || order.returnStatus === 'refunded' ? 'bg-green-500 text-white' : order.returnStatus === 'requested' ? 'bg-yellow-400 text-yellow-900' : '' }`}>
                        {order.returnStatus.replace('_', ' ')}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button aria-haspopup="true" size="icon" variant="ghost">
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">Toggle menu</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Order Actions</DropdownMenuLabel>
                        <DropdownMenuItem onClick={() => toast({title: `Viewing details for ${order.id}`})}>View Order Details</DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuLabel>Change Status</DropdownMenuLabel>
                        {['processing', 'shipped', 'completed', 'cancelled'].map(status => (
                           <DropdownMenuItem key={status} onClick={() => handleChangeStatus(order.id, status)} disabled={order.status === status}>
                             Mark as {status.charAt(0).toUpperCase() + status.slice(1)}
                           </DropdownMenuItem>
                        ))}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => handlePrintInvoice(order.id)}>
                            <Printer className="mr-2 h-4 w-4"/> Print Invoice
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handlePrintShippingLabel(order.id)}>
                            <Truck className="mr-2 h-4 w-4"/> Print Shipping Label
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleManageReturn(order.id)} disabled={order.returnStatus === 'none'}>
                            <RotateCcw className="mr-2 h-4 w-4"/> Manage Return
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              )) : (
                 <TableRow>
                    <TableCell colSpan={9} className="h-24 text-center">
                        No orders found matching your criteria.
                    </TableCell>
                 </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
        <div className="flex justify-center items-center space-x-2 pt-4">
            <Button variant="outline" size="sm" disabled>Previous</Button>
            <span className="text-sm text-muted-foreground">Page 1 of 1 (Conceptual)</span>
            <Button variant="outline" size="sm" disabled>Next</Button>
        </div>
        <Separator className="my-4"/>
        <div>
            <h4 className="text-lg font-semibold mb-2">Order Management Notes:</h4>
            <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
                <li>Conceptual: Order fulfillment can be manual (update status here) or automatic (via API for digital goods).</li>
                <li>Conceptual: Integration with shipping carriers for real-time tracking updates.</li>
                <li>Conceptual: Return Center allows customers to submit requests with photos and reasons. Workflow for approval/rejection and auto-refund for digital items.</li>
                <li>Conceptual: PDF Invoicing generated automatically or on demand.</li>
            </ul>
        </div>
      </CardContent>
    </Card>
  );
}
