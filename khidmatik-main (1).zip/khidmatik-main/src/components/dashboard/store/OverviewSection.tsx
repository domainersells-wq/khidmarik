
'use client';

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button'; // Import Button if not already present
import { LineChart, Users, ShoppingCart, DollarSign as DollarSignIcon, Activity, Package, Eye, TrendingUp, TrendingDown, FileText, MessageSquare, Bell, GitPullRequest, CreditCard, CheckCircle as CheckCircleIcon } from 'lucide-react';
import Image from 'next/image';
import type { ActivityLogItem, TopSellingProductItem } from '@/types';
import { mockActivityLog, mockTopProducts } from '@/data/mock';
import { useToast } from '@/hooks/use-toast'; 
import { useRouter } from 'next/navigation'; // Added useRouter

import { CartesianGrid, Line, Tooltip, XAxis, YAxis, ResponsiveContainer } from 'recharts';
export function OverviewSection() { // Ensure this is the correct component export
  const { toast } = useToast(); 
  const router = useRouter(); // Initialized useRouter

  // Mock data for trends - in a real app, this would come from data fetching
  const revenueTrend = { percentage: 15.2, direction: 'up' as 'up' | 'down' };
  const ordersTrend = { percentage: 5, direction: 'up' as 'up' | 'down' };
  const newCustomersTrend = { percentage: 8, direction: 'up' as 'up' | 'down' };
  const completedDealsTrend = { percentage: 3, direction: 'up' as 'up' | 'down' };
  const bookedRevenueTrend = { percentage: 12, direction: 'up' as 'up' | 'down' };

  const handleQuickAction = (actionName: string, sectionSlug?: string, conceptualNavigation?: string) => {
    if (sectionSlug) {
      router.push(`/dashboard/store?section=${sectionSlug}`);
      toast({
        title: `Navigating to ${actionName}`,
        description: conceptualNavigation || `Opening the ${actionName.toLowerCase()} section.`,
      });
    } else {
      let description = `This would open the ${actionName.toLowerCase()} section or feature.`;
      if (conceptualNavigation) {
        description = `${conceptualNavigation} (Conceptual).`;
      }
      toast({
        title: `${actionName} Clicked (Conceptual)`,
        description: description,
      });
    }
  };

  // Placeholder data for the performance overview line chart
  const performanceData = [
    { name: 'Jan', uv: 400, pv: 240 },
    { name: 'Feb', uv: 300, pv: 139 },
    { name: 'Mar', uv: 200, pv: 980 },
    { name: 'Apr', uv: 278, pv: 390 },
    { name: 'May', uv: 189, pv: 480 },
  ];

  return (
    <div className="space-y-6">
      <header className="mb-4">
        <h1 className="text-3xl font-bold font-headline">Dashboard Overview</h1>
        <p className="text-muted-foreground">Your store's pulse: Key metrics and quick actions.</p>
      </header>

      {/* Quick Actions Bar */}
      <Card className="mb-6 shadow-sm">
        <CardHeader className="pb-2 pt-3">
          <CardTitle className="text-md font-medium">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => handleQuickAction('Invoices', 'orders', 'Order Management > Invoices')}>
            <FileText className="mr-2" /> Invoices
          </Button>
          <Button variant="outline" size="sm" onClick={() => handleQuickAction('Messages', 'customers', 'Customer Communication > Messages')}>
            <MessageSquare className="mr-2" /> Messages
          </Button>
          <Button variant="outline" size="sm" onClick={() => handleQuickAction('Notifications Panel', undefined, 'This would open a dedicated notifications panel')}>
            <Bell className="mr-2" /> Notifications
          </Button>
          <Button variant="outline" size="sm" onClick={() => handleQuickAction('Support Requests', undefined, 'This would open a section for customer support or product requests')}>
            <GitPullRequest className="mr-2" /> Requests
          </Button>
          <Button variant="outline" size="sm" onClick={() => handleQuickAction('Payment Settings', 'settings', 'Store Settings > Payment Configuration')}>
            <CreditCard className="mr-2" /> Payment
          </Button>
        </CardContent>
      </Card>

      {/* Main KPI Row (Total Revenue + 4 KPI Cards) */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
        {/* Prominent Total Revenue Card */}
        <Card className="lg:col-span-2 shadow-lg border-primary">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-semibold">Total Revenue (Month)</CardTitle>
            <DollarSignIcon className="h-6 w-6 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-primary">1,250,340 DA</div>
            <div className="flex items-center text-sm mt-1">
              {revenueTrend.direction === 'up' ? <TrendingUp className="h-4 w-4 mr-1 text-green-500" /> : <TrendingDown className="h-4 w-4 mr-1 text-red-500" />}
              <span className={revenueTrend.direction === 'up' ? 'text-green-500' : 'text-red-500'}>
                {revenueTrend.percentage}%
              </span>
              <span className="text-xs text-muted-foreground ml-1">from last month</span>
            </div>
            <div className="h-[50px] mt-2 flex items-center justify-center bg-muted/30 rounded-md">
               <Image src="https://placehold.co/200x50.png" alt="Revenue sparkline placeholder" width={200} height={50} data-ai-hint="sparkline chart revenue" className="opacity-60"/>
            </div>
          </CardContent>
        </Card>

        {/* KPI Cards */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center justify-between">
              Total Orders <ShoppingCart className="h-4 w-4 text-muted-foreground" />
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">78</div>
            <p className={`text-xs flex items-center ${ordersTrend.direction === 'up' ? 'text-green-500' : 'text-red-500'}`}>
              {ordersTrend.direction === 'up' ? <TrendingUp className="h-3 w-3 mr-1" /> : <TrendingDown className="h-3 w-3 mr-1" />}
              {ordersTrend.percentage}% vs last period
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center justify-between">
              New Customers <Users className="h-4 w-4 text-muted-foreground" />
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">32</div>
             <p className={`text-xs flex items-center ${newCustomersTrend.direction === 'up' ? 'text-green-500' : 'text-red-500'}`}>
              {newCustomersTrend.direction === 'up' ? <TrendingUp className="h-3 w-3 mr-1" /> : <TrendingDown className="h-3 w-3 mr-1" />}
              {newCustomersTrend.percentage}% vs last period
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center justify-between">
              Completed Deals <CheckCircleIcon className="h-4 w-4 text-muted-foreground" />
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">65</div>
            <p className={`text-xs flex items-center ${completedDealsTrend.direction === 'up' ? 'text-green-500' : 'text-red-500'}`}>
              {completedDealsTrend.direction === 'up' ? <TrendingUp className="h-3 w-3 mr-1" /> : <TrendingDown className="h-3 w-3 mr-1" />}
              {completedDealsTrend.percentage}% vs last period
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Performance Overview Chart */}
      <Card className="mt-6 shadow-sm">
        <CardHeader>
          <CardTitle>Performance Overview</CardTitle>
          <CardDescription>Monthly sales and visitor trends.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]"> {/* Adjust height as needed */}
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={performanceData}
                margin={{
                  top: 5, right: 30, left: 20, bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="uv" stroke="#8884d8" activeDot={{ r: 8 }} name="Visitors" />
                <Line type="monotone" dataKey="pv" stroke="#82ca9d" name="Sales" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>


      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-7 mt-6">
        <Card className="lg:col-span-4">
          <CardHeader>
            <CardTitle>Latest Activity</CardTitle>
            <CardDescription>Recent actions in your store.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 max-h-[300px] overflow-y-auto">
            {mockActivityLog.map((item) => {
              const Icon = item.type === 'new_order' ? ShoppingCart : item.type === 'customer_registration' ? Users : Package;
              return (
                <div key={item.id} className="flex items-start gap-3">
                  <div className="mt-1 flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                    <Icon className="h-4 w-4" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">{item.description}</p>
                    <p className="text-xs text-muted-foreground">{new Date(item.timestamp).toLocaleTimeString()}</p>
                  </div>
                </div>
              );
            })}
             <Button variant="link" size="sm" className="w-full mt-2 text-muted-foreground" onClick={() => handleQuickAction('Full Activity Log', undefined, 'This would navigate to a dedicated Activity Log Page')}>View All Activity</Button>
          </CardContent>
        </Card>
         <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Booked Revenue</span>
              <DollarSignIcon className="h-4 w-4 text-muted-foreground" />
            </CardTitle>
             <CardDescription>Conceptual representation of revenue from future bookings or unpaid completed orders.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">85,600 DA</div>
            <p className={`text-xs flex items-center ${bookedRevenueTrend.direction === 'up' ? 'text-green-500' : 'text-red-500'}`}>
                {bookedRevenueTrend.direction === 'up' ? <TrendingUp className="h-3 w-3 mr-1" /> : <TrendingDown className="h-3 w-3 mr-1" />}
                {bookedRevenueTrend.percentage}% vs last period
            </p>
             <div className="h-[150px] mt-2 flex items-center justify-center bg-muted/30 rounded-md">
               <Image src="https://placehold.co/300x150.png" alt="Booked revenue trend placeholder" width={300} height={150} data-ai-hint="line chart revenue" className="opacity-60"/>
            </div>
          </CardContent>
        </Card>
      </div>
      
    </div>
  );
}
