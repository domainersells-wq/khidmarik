
'use client';

import { useState } from 'react';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger, DialogClose } from '@/components/ui/dialog';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { PlusCircle, Edit, Trash2, Search, Filter, Package, AlertTriangle, Settings2, Tag, ImagePlus, ListVideo, ArrowUpDown, UploadCloud, Languages, Palette, DollarSign, CalendarDays, Info, Layers, PackageSearch, Download, Upload } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { ProductItem, ProductVariant, ProductVariantAttribute } from '@/types'; 
import { mockListings } from '@/data/mock'; 

const storeIdForDemo = mockListings.find(l => l.type === 'store' && (l as any).products)?.id || 'store1';
const mockProducts: ProductItem[] = (mockListings.find(l => l.id === storeIdForDemo) as any)?.products || [
  { id: 'prod101', slug:'sample-product-1', name: 'Artisan Ceramic Mug', baseImageUrl: 'https://placehold.co/50x50.png?text=Mug', variants: [{id: 'mug-std', attributes:[], price: 1200, stock: 25}], expiryDate: '2025-12-31' },
  { id: 'prod102', slug:'sample-product-2', name: 'Handmade Leather Wallet', baseImageUrl: 'https://placehold.co/50x50.png?text=Wallet', variants: [{id: 'wallet-std', attributes:[], price: 3500, stock: 8}], isMadeInAlgeria: true },
  { id: 'prod103', slug:'sample-product-3', name: 'Spicy Harissa Paste', baseImageUrl: 'https://placehold.co/50x50.png?text=Harissa', variants: [{id: 'harissa-std', attributes:[], price: 800, stock: 0}], expiryDate: '2024-09-30' },
];


export function ProductsSection() {
  const { toast } = useToast();
  const [products, setProducts] = useState<ProductItem[]>(mockProducts);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<ProductItem | null>(null);
  
  const [productName, setProductName] = useState('');
  const [productDesc, setProductDesc] = useState('');
  const [productPrice, setProductPrice] = useState('');
  const [productStock, setProductStock] = useState('');
  const [productCategory, setProductCategory] = useState(''); 
  const [productExpiry, setProductExpiry] = useState('');

  const openFormForNew = () => {
    setEditingProduct(null);
    setProductName(''); setProductDesc(''); setProductPrice(''); setProductStock(''); setProductCategory(''); setProductExpiry('');
    setIsFormOpen(true);
  };

  const openFormForEdit = (product: ProductItem) => {
    setEditingProduct(product);
    setProductName(product.name);
    setProductDesc(''); 
    setProductPrice(product.variants?.[0]?.price.toString() || '');
    setProductStock(product.variants?.[0]?.stock.toString() || '');
    setProductCategory(''); 
    setProductExpiry(product.expiryDate || '');
    setIsFormOpen(true);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({ title: "Product Saved (Conceptual)", description: `${editingProduct ? 'Updated' : 'Added'} ${productName}. Multi-language, media uploads, variants, bulk import/export, full inventory features (SKU, batch, multi-location) would be handled here with backend integration.` });
    setIsFormOpen(false);
  };

  const handleDeleteProduct = (productId: string) => {
    toast({ title: "Product Deleted (Conceptual)", description: `Product ID ${productId} removed.` });
  };


  return (
    <Card className="shadow-lg border">
      <CardHeader className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <CardTitle className="text-2xl font-headline flex items-center">
            <Package className="mr-3 h-6 w-6 text-primary" /> Products & Inventory
          </CardTitle>
          <CardDescription>Manage your product catalog, stock levels, pricing, and variants.</CardDescription>
        </div>
        <div className="flex gap-2 mt-4 md:mt-0">
            <Button variant="outline" disabled><Upload className="mr-2 h-4 w-4"/>Bulk Import</Button>
            <Button variant="outline" disabled><Download className="mr-2 h-4 w-4"/>Export Products</Button>
            <Button onClick={openFormForNew}>
                <PlusCircle className="mr-2 h-4 w-4" /> Add New Product
            </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex flex-col sm:flex-row gap-2">
            <Input placeholder="Search products by name or SKU..." className="flex-1"/>
            <Select disabled>
                <SelectTrigger className="w-full sm:w-[180px]">
                    <Filter className="mr-2 h-4 w-4 text-muted-foreground"/>
                    <SelectValue placeholder="Filter by Category" />
                </SelectTrigger>
                <SelectContent><SelectItem value="all">All Categories</SelectItem></SelectContent>
            </Select>
             <Button variant="outline" disabled><ArrowUpDown className="mr-2 h-4 w-4"/>Sort By</Button>
        </div>

        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[80px]">Image</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>SKU</TableHead>
                <TableHead className="text-right">Price (DA)</TableHead>
                <TableHead className="text-center">Stock</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {products.map((product) => (
                <TableRow key={product.id}>
                  <TableCell>
                    <Image src={product.baseImageUrl || 'https://placehold.co/50x50.png'} alt={product.name} width={50} height={50} className="rounded-md object-cover" data-ai-hint="product image"/>
                  </TableCell>
                  <TableCell className="font-medium">{product.name}</TableCell>
                  <TableCell className="text-muted-foreground">Main Category</TableCell>
                  <TableCell className="text-muted-foreground text-xs">{product.variants?.[0]?.sku || 'N/A'}</TableCell>
                  <TableCell className="text-right">{product.variants?.[0]?.price.toLocaleString() || 'N/A'}</TableCell>
                  <TableCell className="text-center">
                    {product.variants?.[0]?.stock}
                    {product.variants?.[0]?.stock !== undefined && product.variants?.[0]?.stock < 10 && product.variants?.[0]?.stock > 0 && 
                        <Badge variant="outline" className="ml-2 bg-yellow-100 text-yellow-700 border-yellow-300">Low</Badge>}
                    {product.variants?.[0]?.stock === 0 && <Badge variant="destructive" className="ml-2">Out</Badge>}
                  </TableCell>
                  <TableCell>
                    <Badge variant={product.variants?.[0]?.stock === 0 ? "secondary" : "default"} className={product.variants?.[0]?.stock !== 0 ? "bg-green-500 text-white" : ""}>
                      {product.variants?.[0]?.stock === 0 ? 'Inactive' : 'Active'}
                    </Badge>
                    {product.expiryDate && new Date(product.expiryDate) < new Date() &&
                        <Badge variant="destructive" className="ml-2 mt-1 sm:mt-0 sm:ml-1 block sm:inline-flex"><AlertTriangle className="h-3 w-3 mr-1"/>Expired</Badge>
                    }
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" onClick={() => openFormForEdit(product)}>
                      <Edit className="h-4 w-4" /><span className="sr-only">Edit</span>
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleDeleteProduct(product.id)} className="text-destructive hover:text-destructive/80">
                      <Trash2 className="h-4 w-4" /><span className="sr-only">Delete</span>
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <div className="grid md:grid-cols-2 gap-4 text-sm text-muted-foreground">
            <Card className="p-4 bg-muted/30">
                <h4 className="font-semibold text-foreground flex items-center"><PackageSearch className="h-4 w-4 mr-2"/>Inventory Management</h4>
                <p>Conceptual: View low stock alerts, manage SKUs, batch numbers, and track inventory across multiple locations (if applicable).</p>
                <Button variant="link" size="sm" className="p-0 h-auto mt-1" disabled>Configure Stock Alerts</Button>
            </Card>
            <Card className="p-4 bg-muted/30">
                <h4 className="font-semibold text-foreground flex items-center"><DollarSign className="h-4 w-4 mr-2"/>Flexible Pricing</h4>
                <p>Conceptual: Set quantity-based discounts, time-limited offers/flash sales, and schedule promotions.</p>
                <Button variant="link" size="sm" className="p-0 h-auto mt-1" disabled>Manage Pricing Rules</Button>
            </Card>
        </div>


        <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
          <DialogContent className="sm:max-w-2xl max-h-[90vh] flex flex-col">
            <DialogHeader>
              <DialogTitle>{editingProduct ? 'Edit Product' : 'Add New Product'}</DialogTitle>
              <DialogDescription>
                {editingProduct ? `Modify details for ${editingProduct.name}.` : 'Fill in the details for your new product.'}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleFormSubmit} className="space-y-4 overflow-y-auto p-1 flex-grow">
              <div>
                <Label htmlFor="productName">Product Name *</Label>
                <Input id="productName" value={productName} onChange={(e) => setProductName(e.target.value)} required />
              </div>
              <div>
                <Label htmlFor="productDesc">Description (Multi-language support conceptual)</Label>
                <Textarea id="productDesc" value={productDesc} onChange={(e) => setProductDesc(e.target.value)} rows={3}/>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="productPrice">Base Price (DA) *</Label>
                  <Input id="productPrice" type="number" value={productPrice} onChange={(e) => setProductPrice(e.target.value)} required />
                </div>
                <div>
                  <Label htmlFor="productStock">Base Stock Quantity *</Label>
                  <Input id="productStock" type="number" value={productStock} onChange={(e) => setProductStock(e.target.value)} required />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                    <Label htmlFor="productCategory">Category (Main)</Label>
                    <Input id="productCategory" value={productCategory} onChange={(e) => setProductCategory(e.target.value)} placeholder="e.g., Electronics, Apparel" />
                </div>
                <div>
                    <Label htmlFor="productSubCategory">Sub-category (Optional)</Label>
                    <Input id="productSubCategory" placeholder="e.g., Smartphones, T-Shirts" disabled/>
                </div>
              </div>
              <div>
                <Label htmlFor="productExpiry">Expiry Date (Optional)</Label>
                <Input id="productExpiry" type="date" value={productExpiry} onChange={(e) => setProductExpiry(e.target.value)} />
              </div>
              <Card className="p-3 bg-muted/30">
                <h4 className="font-semibold text-sm mb-2 flex items-center"><Layers className="h-4 w-4 mr-1"/>Variants (Color, Size, Style)</h4>
                <p className="text-xs text-muted-foreground mb-2">Define options for your product. Each variant can have its own SKU, price, stock, and images.</p>
                <Button type="button" variant="outline" className="w-full" disabled><Settings2 className="mr-2 h-4 w-4"/> Add/Edit Variants</Button>
              </Card>
               <Card className="p-3 bg-muted/30">
                <h4 className="font-semibold text-sm mb-2 flex items-center"><ImagePlus className="h-4 w-4 mr-1"/>Media Management</h4>
                <p className="text-xs text-muted-foreground mb-2">Upload images, videos, and PDF attachments for your product and its variants.</p>
                 <Button type="button" variant="outline" className="w-full" disabled><UploadCloud className="mr-2 h-4 w-4"/> Upload Media</Button>
              </Card>
               <Card className="p-3 bg-muted/30">
                 <h4 className="font-semibold text-sm mb-2 flex items-center"><Tag className="h-4 w-4 mr-1"/>Pricing & Promotions</h4>
                 <p className="text-xs text-muted-foreground mb-2">Set up quantity discounts, flash sales, or schedule promotions.</p>
                 <Button type="button" variant="outline" className="w-full" disabled><DollarSign className="mr-2 h-4 w-4"/>Configure Pricing Rules</Button>
               </Card>

              <DialogFooter className="pt-4 border-t mt-2">
                <DialogClose asChild><Button type="button" variant="outline">Cancel</Button></DialogClose>
                <Button type="submit">Save Product</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}
