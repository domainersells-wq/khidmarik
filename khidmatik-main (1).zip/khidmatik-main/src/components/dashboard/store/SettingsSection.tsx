
'use client';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { CreditCard, ShieldCheck, Store, Truck, Users, Image as ImageIcon, Palette, Languages, Globe, Users2, Lock, FileText, Download, Trash2, Share2, Bot, Cog } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Separator } from '@/components/ui/separator';

export function SettingsSection() {
  const { toast } = useToast();

  const handleSaveChanges = (section: string) => {
    toast({ title: `${section} Settings Saved (Conceptual)`, description: `Your ${section.toLowerCase()} settings have been updated.` });
  };

  return (
    <div className="space-y-8">
      <header className="mb-6">
        <CardTitle className="text-2xl font-headline flex items-center">
          <Cog className="mr-3 h-6 w-6 text-primary" /> Store Settings & Configuration
        </CardTitle>
        <CardDescription>Manage all aspects of your store's setup and integrations.</CardDescription>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><Store className="mr-2 h-5 w-5"/>Basic Store Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div><Label htmlFor="storeName">Store Name</Label><Input id="storeName" defaultValue="My Khidmatik Store" /></div>
          <div><Label htmlFor="storeDescription">Store Description</Label><Textarea id="storeDescription" defaultValue="Welcome to my awesome store on Khidmatik!" rows={3}/></div>
           <div>
            <Label>Store Logo & Banner (Conceptual)</Label>
            <div className="flex gap-2 mt-1">
                <Button variant="outline" disabled><ImageIcon className="mr-2 h-4 w-4"/> Upload Logo</Button>
                <Button variant="outline" disabled><ImageIcon className="mr-2 h-4 w-4"/> Upload Banner</Button>
            </div>
          </div>
          <Button onClick={() => handleSaveChanges("Basic Information")}>Save Basic Info</Button>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
            <CardTitle className="flex items-center"><Palette className="mr-2 h-5 w-5"/>Storefront Theme & Language</CardTitle>
            <CardDescription>Customize appearance, manage languages and currencies.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">Conceptual: Options to select themes, customize colors, fonts, and manage pop-ups.</p>
            <Button variant="outline" disabled>Customize Theme</Button>
            <Separator className="my-3"/>
            <div className="space-y-2">
                <Label>Multi-Language Support (Conceptual)</Label>
                <div className="flex items-center space-x-2"><Switch id="lang-ar" disabled/><Label htmlFor="lang-ar">Arabic</Label></div>
                <div className="flex items-center space-x-2"><Switch id="lang-fr" disabled/><Label htmlFor="lang-fr">French</Label></div>
                <div className="flex items-center space-x-2"><Switch id="lang-en" defaultChecked disabled/><Label htmlFor="lang-en">English</Label></div>
            </div>
             <Separator className="my-3"/>
            <div className="space-y-2">
                <Label>Multi-Currency Support (Conceptual)</Label>
                <p className="text-xs text-muted-foreground">Allow customers to see prices in other currencies (e.g., EUR, USD) with DZD as base.</p>
                <Button variant="outline" size="sm" disabled>Configure Currencies</Button>
            </div>
            <Button onClick={() => handleSaveChanges("Theme & Language")} disabled>Save Appearance</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><CreditCard className="mr-2 h-5 w-5"/> Payment Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between rounded-lg border p-3 shadow-sm">
            <div className="space-y-0.5">
              <Label htmlFor="cod-switch">Enable Cash on Delivery (COD)</Label>
            </div>
            <Switch id="cod-switch" defaultChecked disabled />
          </div>
          <div className="flex items-center justify-between rounded-lg border p-3 shadow-sm">
            <div className="space-y-0.5">
              <Label htmlFor="bank-transfer-switch">Enable Bank Transfer</Label>
            </div>
            <Switch id="bank-transfer-switch" disabled />
          </div>
          <p className="text-sm text-muted-foreground">
            Conceptual: Configure Khidmatik Escrow Wallet integration. Add other payment gateways (e.g., Edahabia, Stripe, PayPal, CMI) and manage payment status tracking/error handling.
          </p>
          <Button onClick={() => handleSaveChanges("Payment")} disabled>Save Payment Settings</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><Truck className="mr-2 h-5 w-5"/> Shipping Configuration</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div><Label htmlFor="defaultShippingCost">Default Shipping Cost (DA)</Label><Input id="defaultShippingCost" type="number" defaultValue="500" /></div>
          <div><Label htmlFor="freeShippingThreshold">Free Shipping Threshold (DA)</Label><Input id="freeShippingThreshold" type="number" placeholder="e.g., 10000 (0 for none)" /></div>
          <div><Label htmlFor="shippingZones">Delivery Zones / Notes (e.g., Wilayas, Postal Codes)</Label><Textarea id="shippingZones" placeholder="Define zones and weight/distance-based pricing notes..." rows={3}/></div>
          <div className="flex items-center space-x-2"><Switch id="instore-pickup" disabled/><Label htmlFor="instore-pickup">Enable In-Store Pickup</Label></div>
          <p className="text-sm text-muted-foreground">
            Conceptual: Integrate with shipping partners (Yalidine, etc.), set estimated delivery times, and manage local delivery.
          </p>
          <Button onClick={() => handleSaveChanges("Shipping")}>Save Shipping Settings</Button>
        </CardContent>
      </Card>
      
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
            <CardHeader><CardTitle className="flex items-center"><Users2 className="mr-2 h-5 w-5"/>Staff Roles & Permissions</CardTitle></CardHeader>
            <CardContent>
                <p className="text-sm text-muted-foreground mb-2">Conceptual: Add staff accounts (Admin, Support, Content Manager) with specific permissions. Track activity and sessions.</p>
                <Button variant="outline" disabled>Manage Staff Accounts</Button>
            </CardContent>
        </Card>
        <Card>
            <CardHeader><CardTitle className="flex items-center"><Lock className="mr-2 h-5 w-5"/>Privacy Tools</CardTitle></CardHeader>
            <CardContent>
                <p className="text-sm text-muted-foreground mb-2">Conceptual: Manage customer data export/deletion requests and consent logs for policies.</p>
                <Button variant="outline" disabled><Download className="mr-2 h-4 w-4"/>Export Customer Data</Button>
            </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader><CardTitle className="flex items-center"><Share2 className="mr-2 h-5 w-5"/>Third-Party Integrations</CardTitle></CardHeader>
        <CardContent>
            <p className="text-sm text-muted-foreground mb-3">Conceptual: Connect with Google Shopping, Facebook Catalog, WhatsApp, Zapier, Webhooks, etc.</p>
            <Button variant="outline" disabled>Manage Integrations</Button>
        </CardContent>
      </Card>
      
       <Card>
        <CardHeader><CardTitle className="flex items-center"><ShieldCheck className="mr-2 h-5 w-5"/> Store Policies & Legal</CardTitle></CardHeader>
        <CardContent className="space-y-4">
            <div><Label htmlFor="terms">Terms of Service</Label><Textarea id="terms" placeholder="Enter your store's terms of service..." rows={3} disabled/></div>
            <Button onClick={() => handleSaveChanges("Policies")} disabled>Save Policies</Button>
        </CardContent>
      </Card>
      
      <Card className="bg-amber-50 border-amber-200">
        <CardHeader><CardTitle className="flex items-center"><Store className="mr-2 h-5 w-5 text-amber-700"/>Multi-Vendor System (Optional Feature)</CardTitle></CardHeader>
        <CardContent>
            <p className="text-sm text-amber-800">Conceptual: If enabled, this section would allow management of multiple vendor accounts, link their products, track earnings, and set custom commissions.</p>
            <Button variant="outline" disabled className="border-amber-500 text-amber-700 hover:bg-amber-100 mt-2">Configure Multi-Vendor Settings</Button>
        </CardContent>
      </Card>
    </div>
  );
}
