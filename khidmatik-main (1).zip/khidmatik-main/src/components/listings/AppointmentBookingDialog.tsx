
'use client';

import { useState, useEffect, type FormEvent } from 'react';
import Image from 'next/image'; // Added Image
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Calendar } from '@/components/ui/calendar';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import type { Professional, AppointmentConfig, Appointment } from '@/types'; // Added Appointment
import { CalendarDays, User, StickyNote, Loader2, Info, TicketIcon, CheckCircle } from 'lucide-react'; // Added CheckCircle, TicketIcon
import { format, addDays, isBefore, startOfDay, isToday } from 'date-fns'; // Added isToday

interface AppointmentBookingDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  professional: Professional; 
  onAppointmentRequested?: (appointment: Appointment) => void; // Callback for profile page update
}

export function AppointmentBookingDialog({ isOpen, onOpenChange, professional, onAppointmentRequested }: AppointmentBookingDialogProps) {
  const { toast } = useToast();
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [patientName, setPatientName] = useState('');
  const [reasonForVisit, setReasonForVisit] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [lastRequestedAppointment, setLastRequestedAppointment] = useState<Appointment | null>(null);

  const appointmentConfig = professional.appointmentConfig;

  const handleAppointmentSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!selectedDate || !patientName.trim()) {
      toast({ title: "Missing Information", description: "Please select a date and enter the patient's name.", variant: "destructive" });
      return;
    }
    setIsSubmitting(true);
    await new Promise(resolve => setTimeout(resolve, 200)); 

    const reservationId = `APT-${professional.name.slice(0,3).toUpperCase().replace(/\s+/g, '')}-${Date.now().toString().slice(-5)}`;
    const newAppointment: Appointment = {
        reservationId,
        professionalId: professional.id,
        professionalName: professional.name,
        professionalCategory: professional.category,
        clinicLogoUrl: professional.clinicLogoUrl,
        date: selectedDate.toISOString(),
        patientName,
        reasonForVisit,
        status: 'pending_confirmation',
        notes: "Please arrive 10 mins early. Delays >15 mins may require rescheduling."
    };
    
    setLastRequestedAppointment(newAppointment);
    setShowConfirmation(true); // Show confirmation step

    // Conceptually, this would be saved to a backend and then updated in user's profile
    if (onAppointmentRequested) {
        onAppointmentRequested(newAppointment);
    }

    toast({
      title: "Appointment Request Submitted!",
      description: `Ref ID: ${newAppointment.reservationId}. We've sent your request for ${format(selectedDate, "PPP")} with ${professional.name}. You'll be contacted for confirmation.`,
      duration: 7000,
    });
    setIsSubmitting(false);
    // Don't close dialog immediately, show confirmation step
  };

  const handleCloseDialog = () => {
    onOpenChange(false);
    // Reset state fully after dialog transition
    setTimeout(() => {
        setSelectedDate(undefined);
        setPatientName('');
        setReasonForVisit('');
        setIsSubmitting(false);
        setShowConfirmation(false);
        setLastRequestedAppointment(null);
    }, 300);
  };

  const minBookingDate = appointmentConfig?.leadTimeDays
    ? addDays(startOfDay(new Date()), appointmentConfig.leadTimeDays)
    : startOfDay(new Date());
  
  const handleDownloadTicket = () => {
    toast({
        title: "Download Ticket (Conceptual)",
        description: `A PDF ticket for reservation ID ${lastRequestedAppointment?.reservationId} would be generated here.`,
        duration: 4000
    });
  };


  return (
    <Dialog open={isOpen} onOpenChange={handleCloseDialog}>
      <DialogContent className="sm:max-w-md">
        {!showConfirmation ? (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center">
                {professional.clinicLogoUrl && (
                    <Image src={professional.clinicLogoUrl} alt={`${professional.name} Logo`} width={32} height={32} className="mr-2 rounded-sm" />
                )}
                <CalendarDays className="mr-2 h-5 w-5 text-primary" />
                Book Appointment with {professional.name}
              </DialogTitle>
              <DialogDescription>
                Select a date and provide details. We'll confirm availability.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleAppointmentSubmit} className="space-y-4 py-2">
              <div>
                <Label htmlFor="patientName">Patient Name *</Label>
                <Input
                  id="patientName"
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  placeholder="Enter patient's full name"
                  required
                />
              </div>

              <div>
                <Label>Preferred Date *</Label>
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  className="rounded-md border p-0 mx-auto"
                  disabled={(date) => isBefore(date, minBookingDate) || isBefore(date, startOfDay(new Date())) }
                />
                {selectedDate && (
                    <p className="text-sm text-center mt-2 text-muted-foreground">
                        Selected: {format(selectedDate, "PPP")}
                    </p>
                )}
                {appointmentConfig && (
                    <p className="text-xs text-center mt-1 text-muted-foreground">
                        (Note: Bookings must be at least {appointmentConfig.leadTimeDays} day(s) in advance. Conceptual daily capacity: {appointmentConfig.dailyCapacity} slots.)
                    </p>
                )}
              </div>

              <div>
                <Label htmlFor="reasonForVisit">Reason for Visit (Optional)</Label>
                <Textarea
                  id="reasonForVisit"
                  value={reasonForVisit}
                  onChange={(e) => setReasonForVisit(e.target.value)}
                  placeholder="Briefly describe the reason (e.g., general check-up, specific symptom)"
                  rows={3}
                />
              </div>
              
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-md text-blue-700 text-sm flex items-start gap-2">
                  <Info className="h-5 w-5 mt-0.5 shrink-0" />
                  <div>
                      <span className="font-semibold">Confirmation:</span> This is a request. The professional's office will contact you to confirm the exact time and availability.
                      <br />
                      <span className="font-semibold mt-1 block">Punctuality:</span> Please arrive at least 10 minutes before your scheduled time. Delays of more than 15 minutes may lead to your appointment being rescheduled.
                  </div>
              </div>

              <DialogFooter className="pt-4">
                <DialogClose asChild>
                  <Button type="button" variant="outline">Cancel</Button>
                </DialogClose>
                <Button type="submit" disabled={isSubmitting || !selectedDate || !patientName.trim()}>
                  {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  Request Appointment
                </Button>
              </DialogFooter>
            </form>
          </>
        ) : lastRequestedAppointment && (
            <>
             <DialogHeader>
                <DialogTitle className="flex items-center text-green-600">
                    <CheckCircle className="mr-2 h-6 w-6" />
                    Appointment Request Sent!
                </DialogTitle>
            </DialogHeader>
            <div className="py-4 space-y-3 text-sm">
                <p>Your request details:</p>
                <ul className="list-disc list-inside pl-4 bg-muted/50 p-3 rounded-md">
                    <li><strong>Reservation ID:</strong> {lastRequestedAppointment.reservationId}</li>
                    <li><strong>Professional:</strong> {lastRequestedAppointment.professionalName}</li>
                    <li><strong>Date:</strong> {format(new Date(lastRequestedAppointment.date), "PPP")}</li>
                    <li><strong>Patient:</strong> {lastRequestedAppointment.patientName}</li>
                </ul>
                <p className="text-muted-foreground">You will receive a confirmation from the professional's office soon. Remember the punctuality policy.</p>
                <Button onClick={handleDownloadTicket} variant="outline" className="w-full mt-3">
                    <TicketIcon className="mr-2 h-4 w-4"/> Download Ticket (PDF - Conceptual)
                </Button>
            </div>
            <DialogFooter>
                <Button onClick={handleCloseDialog}>Close</Button>
            </DialogFooter>
            </>
        )}
      </DialogContent>
    </Dialog>
  );
}
