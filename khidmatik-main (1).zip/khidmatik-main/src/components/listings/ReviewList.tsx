
'use client';

import type { Review } from '@/types';
import { Star } from 'lucide-react';
import { format } from 'date-fns';

interface ReviewListProps {
  reviews: Review[];
}

export function ReviewList({ reviews }: ReviewListProps) {
  if (!reviews || reviews.length === 0) {
    return <p className="text-muted-foreground">No reviews yet. Be the first to leave a review!</p>;
  }

  return (
    <div className="space-y-6">
      {reviews.map((review) => (
        <div key={review.id} className="p-4 border rounded-lg">
          <div className="flex items-center justify-between">
            <h4 className="font-semibold">{review.author}</h4>
            <div className="flex items-center">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`h-5 w-5 ${i < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
                />
              ))}
            </div>
          </div>
          <p className="text-sm text-muted-foreground mt-1">{format(new Date(review.date), 'PPP')}</p>
          <p className="mt-2">{review.comment}</p>
        </div>
      ))}
    </div>
  );
}
