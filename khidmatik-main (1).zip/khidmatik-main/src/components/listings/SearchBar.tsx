
'use client';

import { useState, useEffect, type FormEvent } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { categories } from '@/data/mock';
import { Search, MapPin, ListFilter } from 'lucide-react';
import BookingCalendar from '@/components/ui/BookingCalendar';

const ALL_CATEGORIES_SENTINEL_VALUE = "_all_";

export function SearchBar() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const [keyword, setKeyword] = useState(searchParams.get('q') || '');
  const [category, setCategory] = useState(searchParams.get('category') || '');
  const [location, setLocation] = useState(searchParams.get('location') || '');
  const [type, setType] = useState(searchParams.get('type') || '');
  const [capacity, setCapacity] = useState(searchParams.get('capacity') || '');
  const [price, setPrice] = useState(searchParams.get('price') || '');
  const [date, setDate] = useState(searchParams.get('date') || '');


  useEffect(() => {
    setKeyword(searchParams.get('q') || '');
    setCategory(searchParams.get('category') || '');
    setLocation(searchParams.get('location') || '');
    setType(searchParams.get('type') || '');
    setCapacity(searchParams.get('capacity') || '');
    setPrice(searchParams.get('price') || '');
    setDate(searchParams.get('date') || '');
  }, [searchParams]);


  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (keyword) params.set('q', keyword);
    if (category) params.set('category', category); // category state is already '' or a slug
    if (location) params.set('location', location);
    if (type) params.set('type', type);
    if (capacity) params.set('capacity', capacity);
    if (price) params.set('price', price);
    if (date) params.set('date', date);
    router.push(`/listings?${params.toString()}`);
  };

  const handleCategoryChange = (selectedValue: string) => {
    if (selectedValue === ALL_CATEGORIES_SENTINEL_VALUE) {
      setCategory(''); // Set application state to empty string for "All Categories"
    } else {
      setCategory(selectedValue);
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-4 mb-8 bg-card rounded-lg shadow-md border"
      role="search"
      aria-label="Search for stores and professionals"
    >
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Keyword (e.g., pizza, plumber)"
          value={keyword}
          onChange={(e) => setKeyword(e.target.value)}
          className="pl-10"
          aria-label="Search keyword"
        />
      </div>

      <div className="relative">
         <ListFilter className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        <Select 
          value={category === '' ? ALL_CATEGORIES_SENTINEL_VALUE : category} 
          onValueChange={handleCategoryChange}
        >
          <SelectTrigger className="pl-10" aria-label="Select category">
            <SelectValue placeholder="All Categories" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL_CATEGORIES_SENTINEL_VALUE}>All Categories</SelectItem>
            {categories.map((cat) => (
              <SelectItem key={cat.id} value={cat.slug}>
                {cat.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      <div className="relative">
        <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Location (e.g., Springfield)"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          className="pl-10"
          aria-label="Search location"
        />
      </div>

      <div className="relative">
        <Input
          type="number"
          placeholder="Capacity (e.g., 100)"
          value={capacity}
          onChange={(e) => setCapacity(e.target.value)}
          className="pl-10"
          aria-label="Search capacity"
        />
      </div>

      <div className="relative">
        <Input
          type="number"
          placeholder="Price (e.g., 1000)"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
          className="pl-10"
          aria-label="Search price"
        />
      </div>

      <div className="relative">
        <BookingCalendar onSelect={(selectedDate) => setDate(selectedDate)} />
      </div>
      
      <Button type="submit" className="w-full lg:col-span-1 bg-primary hover:bg-primary/90 text-primary-foreground">
        <Search className="mr-2 h-4 w-4" /> Search
      </Button>
    </form>
  );
}
