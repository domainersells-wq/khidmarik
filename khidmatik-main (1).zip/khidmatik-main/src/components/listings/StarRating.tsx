import { Star, StarHalf, StarOff } from 'lucide-react';
import type { LucideProps } from 'lucide-react';

interface StarRatingProps {
  rating: number;
  totalStars?: number;
  size?: number;
  className?: string;
  iconProps?: Omit<LucideProps, 'size' | 'className'>;
}

export function StarRating({
  rating,
  totalStars = 5,
  size = 20,
  className = 'text-accent',
  iconProps = {},
}: StarRatingProps) {
  const fullStars = Math.floor(rating);
  const halfStar = rating % 1 >= 0.5;
  const emptyStars = totalStars - fullStars - (halfStar ? 1 : 0);

  return (
    <div className={`flex items-center ${className}`} aria-label={`Rating: ${rating} out of ${totalStars} stars`}>
      {[...Array(fullStars)].map((_, i) => (
        <Star key={`full-${i}`} fill="currentColor" size={size} {...iconProps} />
      ))}
      {halfStar && <StarHalf key="half" fill="currentColor" size={size} {...iconProps} />}
      {[...Array(emptyStars)].map((_, i) => (
        <Star key={`empty-${i}`} size={size} {...iconProps} />
      ))}
      {rating === 0 && [...Array(totalStars)].map((_, i) => (
        <StarOff key={`off-${i}`} size={size} {...iconProps} />
      ))}
    </div>
  );
}
