
'use client';

import { useState, type FormEvent, useEffect } from 'react';
import { DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useToast } from "@/hooks/use-toast";
import { CreditCard, Landmark, FileText, Building, PackageCheck, AlertCircle } from 'lucide-react'; // Added AlertCircle
import type { TopUpTransaction } from '@/types';

interface TopUpDialogProps {
  currentBalance: number;
  onClose: () => void;
  onTopUpSuccess: (newTransaction: TopUpTransaction) => void;
}

type TopUpStep = 'enterAmount' | 'selectMethod' | 'paymentInstructions' | 'confirmCompletion';
type PaymentMethod = 'ccp' | 'bank' | 'edahabia' | 'other_online';

interface CompanyAccountDetails {
    ccp: { name: string; accountNumber: string; key: string; address: string; };
    bank: { name: string; bankName: string; rib: string; swift: string; };
}

const mockCompanyAccounts: CompanyAccountDetails = {
    ccp: { name: "Khidmatik SARL", accountNumber: "1234567890", key: "12", address: "BP 1000, Sidi Bel Abbès Principal" },
    bank: { name: "Khidmatik SARL", bankName: "Banque Nationale d'Algérie (BNA)", rib: "001 00123 012345678901 23", swift: "BNAADZALXXX" }
};

export function TopUpDialog({ currentBalance, onClose, onTopUpSuccess }: TopUpDialogProps) {
  const { toast } = useToast();
  const [step, setStep] = useState<TopUpStep>('enterAmount');
  const [amount, setAmount] = useState<string>('');
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod | ''>('');
  const [generatedTransactionCode, setGeneratedTransactionCode] = useState('');

  const handleAmountSubmit = () => {
    if (parseFloat(amount) <= 0 || isNaN(parseFloat(amount))) {
      toast({ title: "Invalid Amount", description: "Please enter a valid positive amount.", variant: "destructive" });
      return;
    }
    setStep('selectMethod');
  };

  const handleMethodSelect = (method: PaymentMethod) => {
    setSelectedMethod(method);
    if (method === 'ccp' || method === 'bank') {
      setGeneratedTransactionCode(`REF-KH-${Date.now().toString().slice(-6)}`);
      setStep('paymentInstructions');
    } else {
      // For "Coming Soon" methods
      toast({ title: "Coming Soon!", description: `Payment via ${method} is not yet available. Please select another method.`, variant: "default" });
    }
  };

  const handleConfirmTransfer = () => {
    if (!selectedMethod || !generatedTransactionCode || !amount) return;

    const newTransaction: TopUpTransaction = {
      id: `tu-${Date.now()}`,
      userId: 'currentUser', // Placeholder
      amount: parseFloat(amount),
      method: selectedMethod as 'ccp' | 'bank', // Cast as these are the only ones that reach here
      status: 'pending-review',
      transactionCode: generatedTransactionCode,
      createdAt: new Date().toISOString(),
    };
    onTopUpSuccess(newTransaction);
    toast({
      title: "Top-up Request Submitted",
      description: `Your request for ${parseFloat(amount).toFixed(2)} DA via ${selectedMethod.toUpperCase()} (Ref: ${generatedTransactionCode}) is pending review.`,
      duration: 7000,
    });
    onClose();
  };

  // Reset state when dialog is closed externally or finishes
  useEffect(() => {
    if (!DialogContent) { // Crude check if dialog is not open (dialog state managed by parent)
      setStep('enterAmount');
      setAmount('');
      setSelectedMethod('');
      setGeneratedTransactionCode('');
    }
  }, [DialogClose]); // Assuming DialogClose might signify closure - better if parent controls open state

  return (
    <DialogContent className="sm:max-w-md">
      <DialogHeader>
        <DialogTitle className="text-xl font-headline">
          {step === 'enterAmount' && 'Top Up Your Wallet Balance'}
          {step === 'selectMethod' && 'Select Payment Method'}
          {step === 'paymentInstructions' && `Instructions for ${selectedMethod?.toUpperCase()} Transfer`}
          {step === 'confirmCompletion' && 'Confirm Your Transfer'}
        </DialogTitle>
        <DialogDescription>
          Current Balance: {currentBalance.toFixed(2)} DA.
          {step === 'enterAmount' && ' How much would you like to add?'}
          {step === 'selectMethod' && ' Choose how you want to top up.'}
          {step === 'paymentInstructions' && ' Please make the transfer using the details below.'}
          {step === 'confirmCompletion' && ' Have you completed the transfer with the provided reference code?'}
        </DialogDescription>
      </DialogHeader>

      <div className="py-4 space-y-4">
        {step === 'enterAmount' && (
          <div>
            <Label htmlFor="topup-amount">Amount (DA)</Label>
            <Input
              id="topup-amount"
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="e.g., 2000"
              min="100" // Example minimum
            />
          </div>
        )}

        {step === 'selectMethod' && (
          <RadioGroup value={selectedMethod} onValueChange={(value) => handleMethodSelect(value as PaymentMethod)} className="space-y-3">
            <Label htmlFor="method-ccp" className="flex items-center p-3 border rounded-md cursor-pointer hover:bg-muted/50 has-[:checked]:ring-2 has-[:checked]:ring-primary has-[:checked]:border-primary">
              <RadioGroupItem value="ccp" id="method-ccp" className="mr-3" />
              <FileText className="mr-2 h-5 w-5 text-primary" /> Postal Transfer (CCP)
            </Label>
            <Label htmlFor="method-bank" className="flex items-center p-3 border rounded-md cursor-pointer hover:bg-muted/50 has-[:checked]:ring-2 has-[:checked]:ring-primary has-[:checked]:border-primary">
              <RadioGroupItem value="bank" id="method-bank" className="mr-3" />
              <Landmark className="mr-2 h-5 w-5 text-primary" /> Bank Transfer
            </Label>
            <Label htmlFor="method-edahabia" className="flex items-center p-3 border rounded-md cursor-not-allowed opacity-50">
              <RadioGroupItem value="edahabia" id="method-edahabia" className="mr-3" disabled />
              <CreditCard className="mr-2 h-5 w-5 text-muted-foreground" /> Edahabia / CIB Card <span className="ml-auto text-xs text-muted-foreground">(Coming Soon)</span>
            </Label>
             <Label htmlFor="method-other" className="flex items-center p-3 border rounded-md cursor-not-allowed opacity-50">
              <RadioGroupItem value="other_online" id="method-other" className="mr-3" disabled />
              <PackageCheck className="mr-2 h-5 w-5 text-muted-foreground" /> Other Online Methods <span className="ml-auto text-xs text-muted-foreground">(Coming Soon)</span>
            </Label>
          </RadioGroup>
        )}

        {step === 'paymentInstructions' && selectedMethod && (generatedTransactionCode) && (
          <div className="space-y-4 p-4 border rounded-md bg-muted/30">
            <p className="font-semibold text-center text-lg">
              Unique Transaction Code: <strong className="text-primary">{generatedTransactionCode}</strong>
            </p>
            <p className="text-sm text-destructive text-center font-medium">
              <AlertCircle className="inline h-4 w-4 mr-1" /> IMPORTANT: You MUST include this code in the 'description', 'memo', or 'motif' field of your transfer.
            </p>
            <div className="text-sm">
              <h4 className="font-semibold mb-1">
                {selectedMethod === 'ccp' ? 'CCP Account Details:' : 'Bank Account Details:'}
              </h4>
              {selectedMethod === 'ccp' ? (
                <>
                  <p><strong>Account Name:</strong> {mockCompanyAccounts.ccp.name}</p>
                  <p><strong>CCP Number:</strong> {mockCompanyAccounts.ccp.accountNumber} <strong>Key:</strong> {mockCompanyAccounts.ccp.key}</p>
                  <p><strong>Address:</strong> {mockCompanyAccounts.ccp.address}</p>
                </>
              ) : (
                 <>
                  <p><strong>Beneficiary Name:</strong> {mockCompanyAccounts.bank.name}</p>
                  <p><strong>Bank Name:</strong> {mockCompanyAccounts.bank.bankName}</p>
                  <p><strong>RIB / Account Number:</strong> {mockCompanyAccounts.bank.rib}</p>
                  <p><strong>SWIFT/BIC:</strong> {mockCompanyAccounts.bank.swift}</p>
                </>
              )}
            </div>
            <p className="text-xs text-muted-foreground">
              After completing the transfer, please return to this dialog and confirm.
            </p>
             <Button onClick={() => setStep('confirmCompletion')} className="w-full mt-2">
                Proceed to Confirmation
            </Button>
          </div>
        )}
        
        {step === 'confirmCompletion' && (
            <div className="space-y-3 text-center">
                <p className="text-md">Have you completed the {selectedMethod?.toUpperCase()} transfer for <strong>{parseFloat(amount).toFixed(2)} DA</strong> with the reference code <strong>{generatedTransactionCode}</strong> in the memo/description?</p>
                <p className="text-sm text-muted-foreground">
                    (Optional: You can upload a photo of your payment receipt on the next screen for faster processing - feature coming soon).
                </p>
            </div>
        )}
      </div>

      <DialogFooter className="sm:justify-between gap-2">
        <DialogClose asChild>
          <Button type="button" variant="outline" onClick={onClose}>
            Cancel
          </Button>
        </DialogClose>
        {step === 'enterAmount' && (
          <Button type="button" onClick={handleAmountSubmit} disabled={!amount || parseFloat(amount) <=0}>Next</Button>
        )}
        {/* Select Method step implies selection then auto-proceed or specific action, no explicit "Next" button needed usually */}
         {step === 'paymentInstructions' && (
             <Button type="button" variant="secondary" onClick={() => setStep('selectMethod')}>Back to Methods</Button>
         )}
        {step === 'confirmCompletion' && (
            <>
                <Button type="button" variant="secondary" onClick={() => setStep('paymentInstructions')}>Back to Instructions</Button>
                <Button type="button" onClick={handleConfirmTransfer} className="bg-green-600 hover:bg-green-700 text-white">
                    I Have Completed The Transfer
                </Button>
            </>
        )}
      </DialogFooter>
    </DialogContent>
  );
}
      