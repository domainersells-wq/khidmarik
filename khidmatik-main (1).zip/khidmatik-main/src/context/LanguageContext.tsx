
'use client';

import type { Language, LanguageContextType } from '@/types';
import React, { createContext, useState, useContext, useEffect, type ReactNode } from 'react';

// Basic translations store
const translations: Record<Language, Record<string, string>> = {
  en: {
    stores: 'Stores',
    services: 'Services',
    digital: 'Digital',
    marketplace: 'Marketplace',
    profileMenu: 'Profile Menu',
    myAccount: 'My Account',
    profile: 'Profile',
    dashboards: 'Dashboards',
    myStoreDashboard: 'My Store Dashboard',
    servicesAdminPanel: 'Services Admin Panel',
    platformSuperAdmin: 'Platform Super Admin',
    logOut: 'Log Out',
    notifications: 'Notifications',
    recentActivityAlertsUpdates: 'Recent activity, alerts, and updates.',
    viewAllNotifications: 'View All Notifications',
    selectLanguage: 'Select Language',
    english: 'English',
    arabic: 'العربية (Arabic)',
    french: 'Français (French)',
    logIn: 'Log In',
    register: 'Register',
    welcomeToKhidmatik: 'Welcome to Khidmatik',
    welcomeSubtitle: 'Your Super-App for Algérie! Discover stores, services, parts, and more.',
    browseByCategory: 'Browse by Category',
    viewAllListings: 'View All Categories & Listings',
    featuredListings: 'Featured Listings',
    madeInAlgeria: 'Proudly Made in Algérie',
    exploreAllLocal: 'Explore All Local Products',
    areYouBusinessOwner: 'Are you a Business Owner or Professional?',
    joinKhidmatikToday: 'Join Khidmatik today and reach more customers in your area.',
    listYourBusiness: 'List Your Business or Service',
    footerRights: 'Khidmatik. All rights reserved.',
    footerSlogan: 'Connecting communities in Algérie, one click at a time.',
    appRoadmap: 'App Roadmap',
    servicePoint: 'Service Point',
  },
  ar: {
    stores: 'المتاجر',
    services: 'الخدمات',
    digital: 'رقمي',
    marketplace: 'السوق',
    profileMenu: 'قائمة الملف الشخصي',
    myAccount: 'حسابي',
    profile: 'الملف الشخصي',
    dashboards: 'لوحات التحكم',
    myStoreDashboard: 'لوحة تحكم متجري',
    servicesAdminPanel: 'لوحة إدارة الخدمات',
    platformSuperAdmin: 'مشرف المنصة العام',
    logOut: 'تسجيل الخروج',
    notifications: 'الإشعارات',
    recentActivityAlertsUpdates: 'الأنشطة الأخيرة، التنبيهات والتحديثات.',
    viewAllNotifications: 'عرض جميع الإشعارات',
    selectLanguage: 'اختر اللغة',
    english: 'English (الإنجليزية)',
    arabic: 'العربية',
    french: 'Français (الفرنسية)',
    logIn: 'تسجيل الدخول',
    register: 'تسجيل',
    welcomeToKhidmatik: 'مرحباً بكم في خدمتك',
    welcomeSubtitle: 'تطبيقك الخارق للجزائر! اكتشف المتاجر، الخدمات، قطع الغيار، والمزيد.',
    browseByCategory: 'تصفح حسب الفئة',
    viewAllListings: 'عرض جميع الفئات والقوائم',
    featuredListings: 'قوائم مميزة',
    madeInAlgeria: 'صنع بفخر في الجزائر',
    exploreAllLocal: 'اكتشف جميع المنتجات المحلية',
    areYouBusinessOwner: 'هل أنت صاحب عمل أو محترف؟',
    joinKhidmatikToday: 'انضم إلى خدمتك اليوم وقم بالوصول إلى المزيد من العملاء في منطقتك.',
    listYourBusiness: 'أدرج عملك أو خدمتك',
    footerRights: 'خدمتك. جميع الحقوق محفوظة.',
    footerSlogan: 'ربط المجتمعات في الجزائر، بنقرة واحدة في كل مرة.',
    appRoadmap: 'خارطة طريق التطبيق',
    servicePoint: 'نقطة الخدمة',
  },
  fr: {
    stores: 'Magasins',
    services: 'Services',
    digital: 'Numérique',
    marketplace: 'Marché',
    profileMenu: 'Menu Profil',
    myAccount: 'Mon Compte',
    profile: 'Profil',
    dashboards: 'Tableaux de Bord',
    myStoreDashboard: 'Tableau de Bord Magasin',
    servicesAdminPanel: 'Admin Services',
    platformSuperAdmin: 'Super Admin Plateforme',
    logOut: 'Déconnexion',
    notifications: 'Notifications',
    recentActivityAlertsUpdates: 'Activité récente, alertes et mises à jour.',
    viewAllNotifications: 'Voir toutes les notifications',
    selectLanguage: 'Choisir la langue',
    english: 'English (Anglais)',
    arabic: 'العربية (Arabe)',
    french: 'Français',
    logIn: 'Se Connecter',
    register: 'S\'inscrire',
    welcomeToKhidmatik: 'Bienvenue à Khidmatik',
    welcomeSubtitle: 'Votre Super-App pour l\'Algérie ! Découvrez magasins, services, pièces détachées, et plus encore.',
    browseByCategory: 'Parcourir par catégorie',
    viewAllListings: 'Voir toutes les catégories et annonces',
    featuredListings: 'Annonces en Vedette',
    madeInAlgeria: 'Fièrement Fabriqué en Algérie',
    exploreAllLocal: 'Explorer Tous les Produits Locaux',
    areYouBusinessOwner: 'Êtes-vous Propriétaire d\'Entreprise ou Professionnel ?',
    joinKhidmatikToday: 'Rejoignez Khidmatik aujourd\'hui et atteignez plus de clients dans votre région.',
    listYourBusiness: 'Inscrire Votre Entreprise ou Service',
    footerRights: 'Khidmatik. Tous droits réservés.',
    footerSlogan: 'Connecter les communautés en Algérie, un clic à la fois.',
    appRoadmap: 'Feuille de Route',
    servicePoint: 'Point de Service',
  },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider = ({ children }: { children: ReactNode }) => {
  const [language, setLanguageState] = useState<Language>('en'); // Default to English

  useEffect(() => {
    const storedLanguage = typeof window !== 'undefined' ? localStorage.getItem('khidmatik-lang') as Language | null : null;
    if (storedLanguage && ['en', 'ar', 'fr'].includes(storedLanguage)) {
      setLanguageState(storedLanguage);
      document.documentElement.lang = storedLanguage;
      document.documentElement.dir = storedLanguage === 'ar' ? 'rtl' : 'ltr';
    } else {
      document.documentElement.lang = 'en';
      document.documentElement.dir = 'ltr';
    }
  }, []);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    if (typeof window !== 'undefined') {
      localStorage.setItem('khidmatik-lang', lang);
    }
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  };

  const translate = (key: string, defaultText: string): string => {
    return translations[language]?.[key] || defaultText;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, translate }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

    