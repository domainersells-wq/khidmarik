
'use client'; // This will be used by client components

import type { ConversionFunnelData, GeographicOrderData } from '@/types';

// --- CONCEPTUAL FIREBASE ANALYTICS MOCK ---
// In a real app, this would import from the Firebase SDK
// import { getAnalytics, logEvent as firebaseLogEvent } from "firebase/analytics";

/**
 * Conceptually logs an event to Firebase Analytics.
 * In this mock, it just logs to the console.
 * @param eventName The name of the event to log.
 * @param eventParams Optional parameters for the event.
 */
export function logEvent(eventName: string, eventParams?: { [key: string]: any }) {
  console.log(`[Firebase Analytics Mock] Event logged: ${eventName}`, eventParams || '');
  // Real implementation:
  // const analytics = getAnalytics();
  // firebaseLogEvent(analytics, eventName, eventParams);
}

/**
 * Conceptually retrieves conversion funnel data from Firebase Analytics or Firestore.
 * This is a mock function that simulates an async data fetch.
 * @param devMode - If true, returns dummy data. Otherwise, simulates an empty or error state.
 * @returns A promise that resolves to an array of conversion funnel data.
 */
export async function getConversionFunnelData(devMode: boolean = false): Promise<ConversionFunnelData[]> {
  console.log(`[Firebase Mock] Fetching conversion funnel data (devMode: ${devMode})`);

  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 800));

  if (devMode) {
    console.log('[Firebase Mock] Returning dummy data for devMode.');
    return [
      { step: 'Visited', count: 150, fill: '#8884d8' },
      { step: 'Signed Up', count: 50, fill: '#83a6ed' },
      { step: 'Purchased', count: 10, fill: '#82ca9d' },
    ];
  }

  // Simulate real-world scenarios
  const scenario = Math.random();
  if (scenario < 0.6) { // 60% chance of no data yet
    console.log('[Firebase Mock] Simulating empty data.');
    return [];
  } else { // 40% chance of an error
    console.warn('[Firebase Mock] Simulating a fetch error.');
    throw new Error('Failed to fetch conversion funnel data. Check Firebase security rules or API configuration.');
  }
}

/**
 * Conceptually retrieves order data aggregated by Wilaya from a database.
 * This is a mock function that simulates an async data fetch.
 * @param devMode - If true, returns dummy data. Otherwise, simulates an empty or error state.
 * @param timePeriod - A conceptual filter for the data fetch.
 * @returns A promise that resolves to an array of geographic order data.
 */
export async function getOrdersPerWilaya(devMode: boolean = false, timePeriod: 'day' | 'week' | 'month' = 'month'): Promise<GeographicOrderData[]> {
  console.log(`[Firebase Mock] Fetching orders per Wilaya (devMode: ${devMode}, period: ${timePeriod})`);

  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 800));

  if (devMode) {
    console.log('[Firebase Mock] Returning dummy geographic data for devMode.');
    // Adjust data slightly based on time period for visual feedback
    const multiplier = timePeriod === 'day' ? 0.1 : timePeriod === 'week' ? 0.5 : 1;
    return [
      { wilaya: "Algiers", count: Math.round(120 * multiplier), total: 320000 * multiplier },
      { wilaya: "Oran", count: Math.round(85 * multiplier), total: 195000 * multiplier },
      { wilaya: "Sétif", count: Math.round(60 * multiplier), total: 145000 * multiplier },
      { wilaya: "Tizi Ouzou", count: Math.round(45 * multiplier), total: 98000 * multiplier },
      { wilaya: "Constantine", count: Math.round(77 * multiplier), total: 180000 * multiplier },
      { wilaya: "S.B. Abbès", count: Math.round(30 * multiplier), total: 75000 * multiplier },
    ];
  }

  // Simulate real-world scenarios
  const scenario = Math.random();
  if (scenario < 0.6) { // 60% chance of no data yet
    console.log('[Firebase Mock] Simulating empty geographic data.');
    return [];
  } else { // 40% chance of an error
    console.warn('[Firebase Mock] Simulating a geographic fetch error.');
    throw new Error('Failed to fetch geographic sales data. Check Firestore rules or Cloud Function logs.');
  }
}

    